"""
Kalash Enterprises - Customer Registration & Google Sheets / Excel Synchronization Module
Tracks registered customer details [Name, Number, Email] recorded by date.
Restricted exclusively to Company Portal viewing and downloading.
Estd. 2011, Shop Number 3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan, India, Pincode: 324001
"""

import os
import csv
import io
import re
from datetime import datetime
import database

# Paths for Excel / Google Sheet data files
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
CSV_FILE_PATH = os.path.join(DATA_DIR, 'kalash_customers_google_sheet.csv')
XLSX_FILE_PATH = os.path.join(DATA_DIR, 'kalash_customers_google_sheet.xlsx')

GOOGLE_SHEET_WEBHOOK_URL = os.environ.get('GOOGLE_SHEET_WEBHOOK_URL', '')

HEADERS = [
    'Date & Time',
    'Customer Name',
    'Mobile Number',
    'Email Address',
    'Verification Method',
    'Account Status',
    'Login Count',
    'Last Active Date',
    'Kota Hub Center'
]

def ensure_data_directory():
    os.makedirs(DATA_DIR, exist_ok=True)

def normalize_phone(phone: str) -> str:
    if not phone:
        return ""
    digits = re.sub(r'\D', '', str(phone))
    if len(digits) > 10 and digits.startswith('91'):
        digits = digits[2:]
    elif len(digits) > 10 and digits.startswith('0'):
        digits = digits[1:]
    return digits[-10:] if len(digits) >= 10 else digits

def record_registered_customer(name: str, phone: str, email: str, auth_provider: str = "SMS Gateway OTP") -> dict:
    """
    Records customer details [Name, Number, Email] in:
    1. MySQL/SQLite database table `registered_customers`
    2. Local Google Sheets / Excel master spreadsheet (`.csv` and `.xlsx`)
    3. Live cloud Google Sheet (if webhook configured)
    """
    ensure_data_directory()
    clean_name = (name or "").strip() or "Valued Customer"
    clean_phone = normalize_phone(phone)
    formatted_phone = f"+91 {clean_phone}" if clean_phone else ""
    clean_email = (email or "").strip().lower()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    conn = database.get_db()
    cursor = conn.cursor()

    # Check if customer already exists by phone or email
    cursor.execute("""
    SELECT id, name, phone, email, login_count, registration_date 
    FROM registered_customers 
    WHERE phone = ? OR (email != '' AND email = ?)
    LIMIT 1
    """, (clean_phone, clean_email))
    existing = cursor.fetchone()

    if existing:
        customer_id = existing['id']
        new_count = (existing['login_count'] or 1) + 1
        reg_date = existing['registration_date']
        if isinstance(reg_date, datetime):
            reg_date_str = reg_date.strftime('%Y-%m-%d %H:%M:%S')
        else:
            reg_date_str = str(reg_date)[:19] if reg_date else now_str

        cursor.execute("""
        UPDATE registered_customers 
        SET name = ?, email = ?, last_login = ?, login_count = ?, auth_provider = ?
        WHERE id = ?
        """, (clean_name, clean_email, now_str, new_count, auth_provider, customer_id))
    else:
        cursor.execute("""
        INSERT INTO registered_customers (
            name, phone, email, auth_provider, registration_date, last_login, login_count, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            clean_name, clean_phone, clean_email, auth_provider,
            now_str, now_str, 1, 'Active'
        ))
        customer_id = cursor.lastrowid
        reg_date_str = now_str
        new_count = 1

    conn.commit()
    conn.close()

    # Re-sync Excel & CSV files
    sync_full_sheet_files()

    # Optional Live Google Sheet Webhook Sync
    if GOOGLE_SHEET_WEBHOOK_URL:
        try:
            import requests
            requests.post(GOOGLE_SHEET_WEBHOOK_URL, json={
                'date': now_str,
                'name': clean_name,
                'phone': formatted_phone,
                'email': clean_email,
                'provider': auth_provider,
                'status': 'Active'
            }, timeout=3)
        except Exception as ex:
            print(f"[GOOGLE SHEETS SYNC WARNING] Webhook post: {ex}")

    return {
        "id": customer_id,
        "name": clean_name,
        "phone": formatted_phone,
        "email": clean_email,
        "auth_provider": auth_provider,
        "registration_date": reg_date_str,
        "last_login": now_str,
        "login_count": new_count
    }

def get_all_registered_customers(search_query: str = None) -> list:
    """Retrieves all registered customer records sorted by registration date."""
    conn = database.get_db()
    cursor = conn.cursor()

    if search_query:
        param = f"%{search_query.strip()}%"
        cursor.execute("""
        SELECT * FROM registered_customers 
        WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?
        ORDER BY registration_date DESC, id DESC
        """, (param, param, param))
    else:
        cursor.execute("""
        SELECT * FROM registered_customers 
        ORDER BY registration_date DESC, id DESC
        """)

    rows = cursor.fetchall()
    conn.close()

    customers = []
    for r in rows:
        reg_date = r['registration_date']
        reg_str = reg_date.strftime('%Y-%m-%d %H:%M') if isinstance(reg_date, datetime) else str(reg_date)[:16]
        last_date = r['last_login']
        last_str = last_date.strftime('%Y-%m-%d %H:%M') if isinstance(last_date, datetime) else str(last_date)[:16]
        clean_p = r['phone']
        display_phone = f"+91 {clean_p}" if clean_p and not clean_p.startswith('+') else clean_p

        customers.append({
            'id': r['id'],
            'name': r['name'],
            'phone': display_phone,
            'raw_phone': clean_p,
            'email': r['email'],
            'auth_provider': r['auth_provider'],
            'registration_date': reg_str,
            'last_login': last_str,
            'login_count': r['login_count'],
            'status': r['status'] or 'Active'
        })
    return customers

def sync_full_sheet_files():
    """Regenerates the master CSV and XLSX files containing all customer records."""
    ensure_data_directory()
    customers = get_all_registered_customers()

    # 1. Write CSV
    with open(CSV_FILE_PATH, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(HEADERS)
        for c in customers:
            writer.writerow([
                c['registration_date'],
                c['name'],
                c['phone'],
                c['email'],
                c['auth_provider'],
                c['status'],
                c['login_count'],
                c['last_login'],
                'Kota Central Wholesale Hub (Rajasthan)'
            ])

    # 2. Write XLSX via openpyxl
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Registered Customers"
        ws.views.sheetView[0].showGridLines = True

        # Header formatting (Google Sheets Emerald theme)
        header_fill = PatternFill(start_color="107C41", end_color="107C41", fill_type="solid")
        header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
        thin_border = Border(
            left=Side(style='thin', color='E0E0E0'),
            right=Side(style='thin', color='E0E0E0'),
            top=Side(style='thin', color='E0E0E0'),
            bottom=Side(style='thin', color='E0E0E0')
        )

        ws.append(HEADERS)
        for col_num in range(1, len(HEADERS) + 1):
            cell = ws.cell(row=1, column=col_num)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

        # Rows
        for r_idx, c in enumerate(customers, start=2):
            row_data = [
                c['registration_date'],
                c['name'],
                c['phone'],
                c['email'],
                c['auth_provider'],
                c['status'],
                c['login_count'],
                c['last_login'],
                'Kota Central Wholesale Hub (Rajasthan)'
            ]
            ws.append(row_data)
            row_fill = PatternFill(start_color="F9FAF8" if r_idx % 2 == 0 else "FFFFFF", fill_type="solid")
            for col_idx in range(1, len(row_data) + 1):
                cell = ws.cell(row=r_idx, column=col_idx)
                cell.font = Font(name="Segoe UI", size=10)
                cell.border = thin_border
                cell.fill = row_fill
                if col_idx in (1, 3, 6, 7, 8):
                    cell.alignment = Alignment(horizontal="center")

        # Auto-fit column widths
        for col in ws.columns:
            max_len = max(len(str(cell.value or '')) for cell in col)
            col_letter = get_column_letter(col[0].column)
            ws.column_dimensions[col_letter].width = max(max_len + 4, 12)

        wb.save(XLSX_FILE_PATH)
    except Exception as ex:
        print(f"[EXCEL GENERATION NOTICE] {ex}")

def generate_csv_export() -> str:
    """Returns the full CSV content for Company Portal download."""
    sync_full_sheet_files()
    if os.path.exists(CSV_FILE_PATH):
        with open(CSV_FILE_PATH, 'r', encoding='utf-8') as f:
            return f.read()
    
    # Fallback to string builder
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(HEADERS)
    for c in get_all_registered_customers():
        writer.writerow([
            c['registration_date'],
            c['name'],
            c['phone'],
            c['email'],
            c['auth_provider'],
            c['status'],
            c['login_count'],
            c['last_login'],
            'Kota Central Wholesale Hub (Rajasthan)'
        ])
    return output.getvalue()

def generate_excel_export_bytes() -> bytes:
    """Returns the full XLSX binary content for Company Portal download."""
    sync_full_sheet_files()
    if os.path.exists(XLSX_FILE_PATH):
        with open(XLSX_FILE_PATH, 'rb') as f:
            return f.read()
    return generate_csv_export().encode('utf-8')

def seed_initial_customers_if_empty():
    """Seeds initial customer profiles from orders and demo accounts if registered_customers is empty."""
    conn = database.get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM registered_customers")
    count = cursor.fetchone()[0]
    conn.close()

    if count == 0:
        demo_customers = [
            ("Dr Miit Sehgal", "8107183725", "dr.miit.sehgal@gmail.com", "Google Account Verified"),
            ("Pooja Sehgal", "9414156789", "pooja.sehgal@gmail.com", "SMS Gateway OTP"),
            ("Rajesh Sharma", "9829012345", "rajesh.sharma.kota@gmail.com", "SMS Gateway OTP"),
            ("Aarav Mehta", "9820011223", "aarav.mehta@gmail.com", "Google Account Verified"),
            ("Vikram Singhania", "9820054321", "vikram.singhania@rajasthanpalace.in", "SMS Gateway OTP")
        ]
        for name, phone, email, provider in demo_customers:
            record_registered_customer(name, phone, email, provider)
