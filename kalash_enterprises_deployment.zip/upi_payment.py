"""
Kalash Enterprises - Dynamic UPI QR Code & WhatsApp Payment Integration
Option 1: Dynamic UPI QR Code Generator
Option 2: WhatsApp Cloud API Interactive Payment Flow
"""

import base64
import io
import urllib.parse
import os
import qrcode
import requests

# Default Configuration for Kalash Enterprises Owner
DEFAULT_OWNER_VPA = os.environ.get("OWNER_UPI_VPA", "8107183725@upi")
DEFAULT_BUSINESS_NAME = "Kalash Enterprises"
DEFAULT_OWNER_PHONE = "918107183725"

def generate_upi_payment_qr(
    vpa: str = DEFAULT_OWNER_VPA,
    business_name: str = DEFAULT_BUSINESS_NAME,
    order_id: str = "KLSH-INSTANT",
    amount: float = 0.0,
    save_path: str | None = None,
) -> dict:
    """
    Generates a dynamic UPI payment QR code locked to a specific order total.
    Compatible with WhatsApp Pay, Google Pay, PhonePe, Paytm, and BHIM.

    :param vpa: WhatsApp/Merchant UPI ID (e.g. '8107183725@upi')
    :param business_name: Registered merchant/business name
    :param order_id: Unique website order reference ID
    :param amount: Final payable amount in INR
    :param save_path: Optional file path to save the PNG directly
    :return: Dict containing the raw URI, base64-encoded QR image, and metadata
    """
    safe_amount = max(0.0, float(amount))
    clean_order_id = str(order_id).replace(" ", "_")

    # 1. Format and URL-encode the standard UPI payload
    query_params = {
        "pa": vpa,
        "pn": business_name,
        "am": f"{safe_amount:.2f}",
        "cu": "INR",
        "tn": f"Order_{clean_order_id}",
    }
    encoded_query = urllib.parse.urlencode(query_params)
    upi_uri = f"upi://pay?{encoded_query}"

    # 2. Render the QR code image
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=2,
    )
    qr.add_data(upi_uri)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")

    # 3. Save to file if path is provided
    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        img.save(save_path)

    # 4. Convert image to Base64 (ready to embed in an <img> tag in HTML)
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    base64_data = base64.b64encode(buffer.getvalue()).decode("utf-8")
    data_uri = f"data:image/png;base64,{base64_data}"

    return {
        "upi_uri": upi_uri,
        "base64_image": data_uri,
        "vpa": vpa,
        "business_name": business_name,
        "order_id": order_id,
        "amount": safe_amount,
    }


def send_whatsapp_order_details(
    access_token: str,
    phone_number_id: str,
    customer_phone: str,
    order_id: str,
    total_amount: float,
    cart_items: list[dict],
) -> dict:
    """
    Dispatches a WhatsApp Cloud API interactive message containing pre-filled
    order details and payment intent.

    :param access_token: Permanent System User Token from Meta Business Manager
    :param phone_number_id: Sender Phone Number ID from WhatsApp Cloud API dashboard
    :param customer_phone: Customer mobile number with country code (e.g. '919876543210')
    :param order_id: Unique order reference identifier
    :param total_amount: Total cart value in INR (e.g. 499.00)
    :param cart_items: List of line items with item-level values
    """
    if not access_token or not phone_number_id:
        return {
            "status": "skipped",
            "message": "Meta Cloud API credentials not configured. Using direct WhatsApp Chat & UPI QR flow."
        }

    url = f"https://graph.facebook.com/v20.0/{phone_number_id}/messages"

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    # Meta requires the amount to be passed as an integer scaled by the offset.
    # For INR (offset = 100), 499.00 INR becomes 49900.
    formatted_items = []
    for item in cart_items:
        formatted_items.append({
            "retailer_id": str(item.get("sku", item.get("product_id", "ITEM"))),
            "name": str(item.get("name", "Kitchenware Product")),
            "amount": {
                "value": int(round(float(item.get("price", item.get("unit_price", 0))) * 100)),
                "offset": 100,
            },
            "quantity": int(item.get("quantity", 1)),
        })

    payload = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": customer_phone.strip().replace("+", ""),
        "type": "interactive",
        "interactive": {
            "type": "order_details",
            "header": {
                "type": "text",
                "text": "Order Confirmation | Kalash Enterprises",
            },
            "body": {
                "text": "Thank you for your order! Tap below to verify your items and complete payment directly via WhatsApp Pay.",
            },
            "footer": {
                "text": "Payments secured by Kalash Enterprises Owner Account",
            },
            "action": {
                "name": "review_and_pay",
                "parameters": {
                    "reference_id": str(order_id),
                    "type": "physical-goods",
                    "currency": "INR",
                    "total_amount": {
                        "value": int(round(float(total_amount) * 100)),
                        "offset": 100,
                    },
                    "order": {
                        "status": "pending",
                        "items": formatted_items,
                    },
                    "payment_settings": [
                        {
                            "type": "payment_gateway",
                        }
                    ],
                },
            },
        },
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        return response.json()
    except Exception as e:
        return {"status": "error", "message": str(e)}
