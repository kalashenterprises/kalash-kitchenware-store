import os
import glob

replacements = {
    "+91 8107183725": "+91 8107183725",
    "+91 8107183725": "+91 8107183725",
    "8107183725": "8107183725",
    "918107183725": "918107183725"
}

files_to_check = glob.glob("**/*.html", recursive=True) + glob.glob("**/*.py", recursive=True)

for file in files_to_check:
    if file.endswith("update_phone.py") or file.endswith("update_address.py") or file.endswith("update_text.py") or "kalash_enterprises" in file and "stitch" not in file:
        pass
    try:
        with open(file, "r", encoding="utf-8") as f:
            content = f.read()
        
        updated = False
        for old_text, new_text in replacements.items():
            if old_text in content:
                content = content.replace(old_text, new_text)
                updated = True
                
        if updated:
            with open(file, "w", encoding="utf-8") as f:
                f.write(content)
            print(f"Updated {file}")
    except Exception as e:
        print(f"Error processing {file}: {e}")
