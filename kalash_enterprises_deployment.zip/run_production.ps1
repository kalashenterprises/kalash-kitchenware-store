Write-Host "=========================================================================" -ForegroundColor Cyan
Write-Host "Starting Kalash Enterprises Production Server for www.kalashenterprises.co.in" -ForegroundColor Green
Write-Host "Running on Waitress Multi-Threaded Production WSGI Server" -ForegroundColor Yellow
Write-Host "=========================================================================" -ForegroundColor Cyan

$env:FLASK_ENV = "production"
$env:USE_MYSQL = "true"
$env:MYSQL_HOST = "127.0.0.1"
$env:MYSQL_PORT = "3306"
$env:MYSQL_USER = "root"
$env:MYSQL_PASSWORD = "Sehgal6897@"
$env:MYSQL_DB = "kalash_kitchenware"
$env:PORT = "5000"

& "C:\Users\Dr Miit Sehgal\AppData\Local\Programs\Python\Python312\python.exe" waitress_server.py
