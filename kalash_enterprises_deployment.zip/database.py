"""
Kalash Enterprises - Kitchenware & Utensils Store
Database Models & Backend Management (MySQL Primary + SQLite Fallback)
Estd. 2011, Shop Number3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan, India, Pincode: 324001
"""

import sqlite3
import json
import os
import re
from datetime import datetime

try:
    import pymysql
    import pymysql.err
    IntegrityError = (sqlite3.IntegrityError, pymysql.err.IntegrityError)
except ImportError:
    pymysql = None
    IntegrityError = (sqlite3.IntegrityError,)

# Configuration for MySQL database
MYSQL_HOST = os.environ.get('MYSQL_HOST', '127.0.0.1')
MYSQL_PORT = int(os.environ.get('MYSQL_PORT', 3306))
MYSQL_USER = os.environ.get('MYSQL_USER', 'root')
MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD', 'Sehgal6897@')
MYSQL_DB = os.environ.get('MYSQL_DB', 'kalash_kitchenware')
USE_MYSQL = os.environ.get('USE_MYSQL', 'true').lower() in ('true', '1', 'yes')

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'kalash_kitchenware.db')

class MySQLRow(dict):
    """
    Hybrid Row object providing both dict-like key access and tuple-like integer index access.
    Compatible with sqlite3.Row behavior so all existing templates and route handlers work seamlessly.
    """
    def __init__(self, cursor, row_tuple):
        super().__init__()
        self._tuple = row_tuple
        if cursor.description:
            for idx, desc in enumerate(cursor.description):
                self[desc[0]] = row_tuple[idx]

    def __getitem__(self, key):
        if isinstance(key, int):
            return self._tuple[key]
        return super().__getitem__(key)

class MySQLCursorWrapper:
    """
    Cursor wrapper adapting MySQL queries to standard DB-API parameter markers (? to %s),
    handling scalar MAX() to GREATEST(), and returning MySQLRow instances.
    """
    def __init__(self, raw_cursor):
        self._raw = raw_cursor

    @property
    def description(self):
        return self._raw.description

    @property
    def lastrowid(self):
        return self._raw.lastrowid

    @property
    def rowcount(self):
        return self._raw.rowcount

    def _translate_query(self, query):
        # 1. Translate INSERT OR REPLACE INTO -> REPLACE INTO for MySQL
        q = re.sub(r'\bINSERT\s+OR\s+REPLACE\s+INTO\b', 'REPLACE INTO', query, flags=re.IGNORECASE)
        # 2. Translate scalar MAX(0, expr) -> GREATEST(0, expr)
        q = re.sub(r'\bMAX\s*\(\s*0\s*,', 'GREATEST(0,', q, flags=re.IGNORECASE)
        # 3. Translate ? markers to %s
        q = q.replace('?', '%s')
        return q

    def execute(self, query, params=None):
        translated = self._translate_query(query)
        if params is None:
            return self._raw.execute(translated)
        if isinstance(params, dict):
            # Translate named parameters e.g. :slug -> %(slug)s
            translated = re.sub(r':([a-zA-Z0-9_]+)', r'%(\1)s', translated)
            return self._raw.execute(translated, params)
        # Convert list to tuple for PyMySQL if needed
        p = tuple(params) if isinstance(params, list) else params
        return self._raw.execute(translated, p)

    def fetchone(self):
        t = self._raw.fetchone()
        if t is None:
            return None
        return MySQLRow(self, t)

    def fetchall(self):
        rows = self._raw.fetchall()
        return [MySQLRow(self, r) for r in rows]

    def close(self):
        return self._raw.close()

    def __iter__(self):
        while True:
            r = self.fetchone()
            if r is None:
                break
            yield r

class MySQLConnectionWrapper:
    """
    Connection wrapper that provides cursor, commit, rollback, and close matching standard DB-API.
    """
    def __init__(self, raw_conn):
        self._conn = raw_conn
        self.row_factory = None

    def cursor(self):
        return MySQLCursorWrapper(self._conn.cursor())

    def commit(self):
        return self._conn.commit()

    def rollback(self):
        return self._conn.rollback()

    def close(self):
        return self._conn.close()

    def execute(self, query, params=None):
        cur = self.cursor()
        cur.execute(query, params)
        return cur

def get_db():
    """
    Connect to MySQL database as primary backend.
    If MySQL server is unreachable, gracefully fall back to local SQLite database.
    """
    if USE_MYSQL and pymysql is not None:
        try:
            raw_conn = pymysql.connect(
                host=MYSQL_HOST,
                port=MYSQL_PORT,
                user=MYSQL_USER,
                password=MYSQL_PASSWORD,
                database=MYSQL_DB,
                charset='utf8mb4',
                autocommit=True
            )
            return MySQLConnectionWrapper(raw_conn)
        except Exception:
            # Attempt to create database if it does not exist yet
            try:
                admin_conn = pymysql.connect(
                    host=MYSQL_HOST,
                    port=MYSQL_PORT,
                    user=MYSQL_USER,
                    password=MYSQL_PASSWORD,
                    charset='utf8mb4',
                    autocommit=True
                )
                ac = admin_conn.cursor()
                ac.execute(f"CREATE DATABASE IF NOT EXISTS `{MYSQL_DB}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
                admin_conn.close()
                raw_conn = pymysql.connect(
                    host=MYSQL_HOST,
                    port=MYSQL_PORT,
                    user=MYSQL_USER,
                    password=MYSQL_PASSWORD,
                    database=MYSQL_DB,
                    charset='utf8mb4',
                    autocommit=True
                )
                return MySQLConnectionWrapper(raw_conn)
            except Exception as ex:
                print(f"[DATABASE WARNING] Unable to connect to MySQL ({ex}). Falling back to SQLite.")

    # SQLite Fallback
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def is_mysql_active():
    """Returns True if the current get_db() returns a MySQL connection."""
    conn = get_db()
    active = isinstance(conn, MySQLConnectionWrapper)
    conn.close()
    return active

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    if isinstance(conn, MySQLConnectionWrapper):
        # MySQL Schema
        tables_ddl = [
            """
            CREATE TABLE IF NOT EXISTS categories (
                slug VARCHAR(100) PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                description TEXT,
                product_count INT DEFAULT 0,
                image_url TEXT
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """,
            """
            CREATE TABLE IF NOT EXISTS products (
                id INT AUTO_INCREMENT PRIMARY KEY,
                slug VARCHAR(255) UNIQUE,
                name VARCHAR(255) NOT NULL,
                category VARCHAR(100) NOT NULL,
                category_name VARCHAR(100) NOT NULL,
                material VARCHAR(100) NOT NULL,
                material_badge VARCHAR(100) NOT NULL,
                retail_price DOUBLE NOT NULL,
                mrp DOUBLE NOT NULL,
                discount_percent INT NOT NULL,
                stock INT NOT NULL,
                rating DOUBLE DEFAULT 4.9,
                review_count INT DEFAULT 0,
                units_sold INT DEFAULT 0,
                is_featured INT DEFAULT 0,
                is_bestseller INT DEFAULT 0,
                is_flash_deal INT DEFAULT 0,
                lead_description TEXT,
                detailed_description TEXT,
                specs JSON,
                variants JSON,
                image_url TEXT,
                gallery JSON,
                heat_sources VARCHAR(255),
                warranty VARCHAR(100) DEFAULT '10-Year Warranty'
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """,
            """
            CREATE TABLE IF NOT EXISTS orders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                order_number VARCHAR(100) UNIQUE NOT NULL,
                customer_name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL,
                phone VARCHAR(50) NOT NULL,
                address TEXT NOT NULL,
                city VARCHAR(100) NOT NULL,
                state VARCHAR(100) NOT NULL,
                pincode VARCHAR(20) NOT NULL,
                gstin VARCHAR(50),
                business_name VARCHAR(255),
                payment_method VARCHAR(100) NOT NULL,
                payment_status VARCHAR(100) NOT NULL,
                payment_id VARCHAR(100),
                subtotal DOUBLE NOT NULL,
                discount DOUBLE DEFAULT 0,
                shipping_fee DOUBLE DEFAULT 0,
                tax_amount DOUBLE NOT NULL,
                total_amount DOUBLE NOT NULL,
                order_status VARCHAR(100) NOT NULL,
                tracking_partner VARCHAR(100) DEFAULT 'BlueDart Express Air',
                tracking_awb VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expected_delivery VARCHAR(255)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """,
            """
            CREATE TABLE IF NOT EXISTS order_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                order_id INT NOT NULL,
                product_id INT NOT NULL,
                product_name VARCHAR(255) NOT NULL,
                variant_name VARCHAR(100),
                unit_price DOUBLE NOT NULL,
                quantity INT NOT NULL,
                subtotal DOUBLE NOT NULL,
                image_url TEXT,
                FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """,
            """
            CREATE TABLE IF NOT EXISTS b2b_inquiries (
                id INT AUTO_INCREMENT PRIMARY KEY,
                inquiry_number VARCHAR(100) UNIQUE,
                business_name VARCHAR(255) NOT NULL,
                contact_phone VARCHAR(50) NOT NULL,
                email VARCHAR(255),
                product_requirement TEXT NOT NULL,
                estimated_value DOUBLE NOT NULL,
                discount_tier VARCHAR(100),
                net_billing_price DOUBLE,
                status VARCHAR(100) DEFAULT 'New Inquiry',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """,
            """
            CREATE TABLE IF NOT EXISTS reviews (
                id INT AUTO_INCREMENT PRIMARY KEY,
                product_id INT NOT NULL,
                author_name VARCHAR(255) NOT NULL,
                location VARCHAR(100),
                user_type VARCHAR(100) DEFAULT 'Verified Buyer',
                rating INT NOT NULL,
                comment TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """,
            """
            CREATE TABLE IF NOT EXISTS newsletter_subscribers (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(255) UNIQUE NOT NULL,
                coupon_issued VARCHAR(50) DEFAULT 'UTSAV15',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """,
            """
            CREATE TABLE IF NOT EXISTS registered_customers (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                phone VARCHAR(50) NOT NULL,
                email VARCHAR(255) NOT NULL,
                auth_provider VARCHAR(100) DEFAULT 'SMS Gateway OTP',
                registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                login_count INT DEFAULT 1,
                status VARCHAR(50) DEFAULT 'Active',
                notes TEXT
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """,
            """
            CREATE TABLE IF NOT EXISTS sms_otp_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                phone VARCHAR(50) NOT NULL,
                otp_code VARCHAR(10) NOT NULL,
                gateway_provider VARCHAR(100) DEFAULT 'Fast2SMS Enterprise Gateway',
                gateway_message_id VARCHAR(100),
                status VARCHAR(50) DEFAULT 'DELIVERED',
                sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP NULL,
                verified_at TIMESTAMP NULL,
                carrier VARCHAR(50) DEFAULT 'Indian Telecom (TRAI DLT)',
                message_text TEXT
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        ]
        for ddl in tables_ddl:
            cursor.execute(ddl)
        conn.commit()

        # If MySQL tables are empty and SQLite DB exists, sync data directly
        cursor.execute("SELECT COUNT(*) FROM products")
        if cursor.fetchone()[0] == 0 and os.path.exists(DB_PATH):
            try:
                _sync_sqlite_to_mysql(cursor)
                conn.commit()
            except Exception as e:
                print(f"[MIGRATION WARNING] Auto-sync from SQLite encountered: {e}")
        conn.close()
        return

    # SQLite Schema (Fallback)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        slug TEXT UNIQUE,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        category_name TEXT NOT NULL,
        material TEXT NOT NULL,
        material_badge TEXT NOT NULL,
        retail_price REAL NOT NULL,
        mrp REAL NOT NULL,
        discount_percent INTEGER NOT NULL,
        stock INTEGER NOT NULL,
        rating REAL DEFAULT 4.9,
        review_count INTEGER DEFAULT 0,
        units_sold INTEGER DEFAULT 0,
        is_featured INTEGER DEFAULT 0,
        is_bestseller INTEGER DEFAULT 0,
        is_flash_deal INTEGER DEFAULT 0,
        lead_description TEXT,
        detailed_description TEXT,
        specs JSON,
        variants JSON,
        image_url TEXT,
        gallery JSON,
        heat_sources TEXT,
        warranty TEXT DEFAULT '10-Year Warranty'
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS categories (
        slug TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        product_count INTEGER DEFAULT 0,
        image_url TEXT
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_number TEXT UNIQUE NOT NULL,
        customer_name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        pincode TEXT NOT NULL,
        gstin TEXT,
        business_name TEXT,
        payment_method TEXT NOT NULL,
        payment_status TEXT NOT NULL,
        payment_id TEXT,
        subtotal REAL NOT NULL,
        discount REAL DEFAULT 0,
        shipping_fee REAL DEFAULT 0,
        tax_amount REAL NOT NULL,
        total_amount REAL NOT NULL,
        order_status TEXT NOT NULL,
        tracking_partner TEXT DEFAULT 'BlueDart Express Air',
        tracking_awb TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expected_delivery TEXT
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        variant_name TEXT,
        unit_price REAL NOT NULL,
        quantity INTEGER NOT NULL,
        subtotal REAL NOT NULL,
        image_url TEXT,
        FOREIGN KEY (order_id) REFERENCES orders (id)
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS b2b_inquiries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        inquiry_number TEXT UNIQUE,
        business_name TEXT NOT NULL,
        contact_phone TEXT NOT NULL,
        email TEXT,
        product_requirement TEXT NOT NULL,
        estimated_value REAL NOT NULL,
        discount_tier TEXT,
        net_billing_price REAL,
        status TEXT DEFAULT 'New Inquiry',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        author_name TEXT NOT NULL,
        location TEXT,
        user_type TEXT DEFAULT 'Verified Buyer',
        rating INTEGER NOT NULL,
        comment TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products (id)
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS newsletter_subscribers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        coupon_issued TEXT DEFAULT 'UTSAV15',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS registered_customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT NOT NULL,
        auth_provider TEXT DEFAULT 'SMS Gateway OTP',
        registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        login_count INTEGER DEFAULT 1,
        status TEXT DEFAULT 'Active',
        notes TEXT
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS sms_otp_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone TEXT NOT NULL,
        otp_code TEXT NOT NULL,
        gateway_provider TEXT DEFAULT 'Fast2SMS Enterprise Gateway',
        gateway_message_id TEXT,
        status TEXT DEFAULT 'DELIVERED',
        sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expires_at TIMESTAMP,
        verified_at TIMESTAMP,
        carrier TEXT DEFAULT 'Indian Telecom (TRAI DLT)',
        message_text TEXT
    )
    ''')

    conn.commit()
    conn.close()

def _sync_sqlite_to_mysql(mysql_cursor):
    """Synchronize rows from existing SQLite database into MySQL."""
    s_conn = sqlite3.connect(DB_PATH)
    s_conn.row_factory = sqlite3.Row
    s_cur = s_conn.cursor()

    # Categories
    s_cur.execute("SELECT * FROM categories")
    for r in s_cur.fetchall():
        mysql_cursor.execute(
            "REPLACE INTO categories (slug, name, description, product_count, image_url) VALUES (?, ?, ?, ?, ?)",
            (r['slug'], r['name'], r['description'], r['product_count'], r['image_url'])
        )

    # Products
    s_cur.execute("SELECT * FROM products")
    for r in s_cur.fetchall():
        mysql_cursor.execute("""
        REPLACE INTO products (
            id, slug, name, category, category_name, material, material_badge,
            retail_price, mrp, discount_percent, stock, rating, review_count,
            units_sold, is_featured, is_bestseller, is_flash_deal,
            lead_description, detailed_description, specs, variants,
            image_url, gallery, heat_sources, warranty
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            r['id'], r['slug'], r['name'], r['category'], r['category_name'], r['material'], r['material_badge'],
            r['retail_price'], r['mrp'], r['discount_percent'], r['stock'], r['rating'], r['review_count'],
            r['units_sold'], r['is_featured'], r['is_bestseller'], r['is_flash_deal'],
            r['lead_description'], r['detailed_description'], r['specs'], r['variants'],
            r['image_url'], r['gallery'], r['heat_sources'], r['warranty']
        ))

    # Orders
    s_cur.execute("SELECT * FROM orders")
    for r in s_cur.fetchall():
        mysql_cursor.execute("""
        REPLACE INTO orders (
            id, order_number, customer_name, email, phone, address, city, state, pincode,
            gstin, business_name, payment_method, payment_status, payment_id,
            subtotal, discount, shipping_fee, tax_amount, total_amount,
            order_status, tracking_partner, tracking_awb, created_at, expected_delivery
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            r['id'], r['order_number'], r['customer_name'], r['email'], r['phone'], r['address'], r['city'], r['state'], r['pincode'],
            r['gstin'], r['business_name'], r['payment_method'], r['payment_status'], r['payment_id'],
            r['subtotal'], r['discount'], r['shipping_fee'], r['tax_amount'], r['total_amount'],
            r['order_status'], r['tracking_partner'], r['tracking_awb'], r['created_at'], r['expected_delivery']
        ))

    # Order Items
    s_cur.execute("SELECT * FROM order_items")
    for r in s_cur.fetchall():
        mysql_cursor.execute("""
        REPLACE INTO order_items (
            id, order_id, product_id, product_name, variant_name, unit_price, quantity, subtotal, image_url
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            r['id'], r['order_id'], r['product_id'], r['product_name'], r['variant_name'],
            r['unit_price'], r['quantity'], r['subtotal'], r['image_url']
        ))

    # B2B Inquiries
    s_cur.execute("SELECT * FROM b2b_inquiries")
    for r in s_cur.fetchall():
        mysql_cursor.execute("""
        REPLACE INTO b2b_inquiries (
            id, inquiry_number, business_name, contact_phone, email, product_requirement,
            estimated_value, discount_tier, net_billing_price, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            r['id'], r['inquiry_number'], r['business_name'], r['contact_phone'], r['email'], r['product_requirement'],
            r['estimated_value'], r['discount_tier'], r['net_billing_price'], r['status'], r['created_at']
        ))

    # Reviews
    s_cur.execute("SELECT * FROM reviews")
    for r in s_cur.fetchall():
        mysql_cursor.execute("""
        REPLACE INTO reviews (
            id, product_id, author_name, location, user_type, rating, comment, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            r['id'], r['product_id'], r['author_name'], r['location'], r['user_type'],
            r['rating'], r['comment'], r['created_at']
        ))

    s_conn.close()


def seed_db():
    conn = get_db()
    cursor = conn.cursor()

    # Check if products already exist
    cursor.execute('SELECT COUNT(*) FROM products')
    if cursor.fetchone()[0] > 0:
        conn.close()
        return

    # Seed Categories (9 Official Store Menu Categories)
    categories = [
        ('stainless-steel', 'STAINLESS STEEL', 'Purity in Every Vessel • 100% Food-Grade Tri-Ply & Heavy Gauge SS 304 Utensils', 64, 'https://lh3.googleusercontent.com/aida-public/AB6AXuASzZcshcIU7MqiqI49QoHm7kOKPqI4c8OAa9P6MExd9Bg2lVvUxE3boge4huAKJbNh3Ur1oZC9WXX9wh3MTDKy1Fisw5DmAKHxAQPrFObSFSruLI4kMmYCmLsd9YqgBgO8F_MGGCwjk1XKTqYq_W_fqqoB6bTtehbqgusVx4kZTV_Foq0ADtUeThPini70dhmelwQitqtvmEfnvWrvEee6Z9KqfV8rFcjrRUWXpBU'),
        ('copper-wares', 'COPPER-WARES', 'Ayurvedic Wellness & Timeless Shine • Hand-Hammered Pure Tamba Vessels & Matkas', 38, 'https://lh3.googleusercontent.com/aida-public/AB6AXuBztyfZh39QlbIhfu65nXp-pEa43XTxszgmq8IxsdoDSLFVuaGJOPYbAtLUURbak9a_cUaJh_Lda6A_znjjpjF51krgwuE8QfO_eF95rJOEKY4lxV2MtPI-JF1MjUuBB6bcJFKwoyVmBN8guFcKYQOsGC30R1EkLMXFSXe9j_uOMDDdMvf09OdAJLRYU0BuSkAA_4Rhktd9rv2KGzmVMfTwnmTIg0y3vSguG5mr_g0'),
        ('brass-wares', 'BRASS-WARES', 'Golden Heritage for Royal Feasts • Heavy Handcrafted Pure Pital Cookware & Puja Sets', 42, 'https://lh3.googleusercontent.com/aida-public/AB6AXuBieIX04FQuptFpxDw3FMeBU88GrMZBhhQDpJ5kNlyMIhi9Wa3DiZcskKMjhNef-Btjl5io2nwhIaZyUtn0VzLHL8Nw_VxlUzzjDllpFSpGM1cq46j2UtUMr97oGTJiFFUDQXTOPou9chQ45-g0LuowWQoHjhQO0cRbzEHf3vLZJMszfnKzPhOBzVfq1i6umQ6_N6Q0YOQothHbvCcceBMdka_viHhdlng9b-jAsHQ'),
        ('heritage-kaansa-wares', 'HERITAGE- KAANSA WARES', 'Alkali-Balanced Dining Royalty • Ancient Vedic Bronze / Bell Metal Masterpieces', 26, 'https://lh3.googleusercontent.com/aida-public/AB6AXuBEWBGXPJGxIz772AzSFwgAQR-OGeScnxq4fW2uW-zgtBvxFRyvLDWOAObLnYiXrVRBZo0XQEnSW1N-PAdPFBLh-ZcXgrezhFVWAx4SY1GlAyMh_X4brJX8QoI5-6I1Af-bNyyf_LZLwahrGeax_qG_ANpjcKwUCo-Vjy6ra7VOOIWxeo8mBQ6PDZfmMCTIvNccf4DRPhSi5AjFINjxxM0YTmpHiSn8sywJCQhFAYc'),
        ('aluminium-cookwares', 'ALUMINIUM COOKWARES', 'Fast Uniform Heat & Industrial Strength • Heavy Commercial Patilas & Topes', 55, 'https://lh3.googleusercontent.com/aida-public/AB6AXuD8VZKL5zsMiNQdqA-_Ldl040Lh7HR1vkmvpjSYSDvwx0WYO4JpPbubplhYccVhXLK9K9EVmkfQRen6Z1lEktHwgIoZSmmoMnlISmaK5jHrdwjc00yEn3rRhVVRiSX_vwlwxrlFlAyT2b031oyrTftfHJJxrciA-xv6n3TDANpJW7M4Fc62SSHC_WGVn-dofP1nHWvldxFUGxWisrPgdIJEaimVl2zphJir0l1dAiM'),
        ('pressure-cookers', 'PRESSURE COOKERS', 'Lightning-Quick & ISI Certified Safety • Hard-Anodized & Stainless Outer/Inner Lid Cookers', 32, 'https://lh3.googleusercontent.com/aida-public/AB6AXuCDKfEDpnjYsqlja7ssbgmkGkwbji9vqizbAZHKu4JEKRVjUZTv_1ngp9mb_SCFV0VVSW9D-j1v0-LCddYnlvyb4XrZoCYOxAPvG9GeTVlVZIvjcR4o9FrN822nzJyW0zSIUKPzMSC8OGH1MvOwX4t4Sz2TxHLzg8T-AyBAxrN-XX00QwjBT1OR-UF2wt3BVwS5_0ruGnkCXHlonFonfB6DziPtfghYMZh5scV7g6Y'),
        ('gas-stoves', 'GAS STOVES', 'High-Efficiency Blue Flame Power • Toughened Shatter-Proof Glass & Heavy Brass Burners', 24, 'https://lh3.googleusercontent.com/aida-public/AB6AXuAq2MJPADRLzZkHKnw41o8owuctNUFj3B2_pUXGv3Lb7HT8cu6L_mPpoFYxlAAnCjOEOfBWs-SP_1KhkHN8f_sYntWxvfzZUh2vdGz9HOvZcKCryz4ryGq7e0ThKn_EbD3rGL2Qs38LXVs3tDy_RnI9EU5iznrZNfZ6nf3QJIkvOqCKzAREQJRuCghnRPz70i18ZxDmMe3whZ6h0FI-Hvpec_PEQtnlw5WIliAYaGI'),
        ('non-stick-cookwares', 'NON-STICK COOKWARES', 'Guilt-Free Zero-Oil Cooking • 5-Layer German Greblon Granite Scratch-Proof Tawas & Pans', 48, 'https://lh3.googleusercontent.com/aida-public/AB6AXuBNGSur6nFGrCqAmoCdcxdhiPPhMnEn10E_6pKIDZRNUej9doq9s5kErt1ioKD_PlPI0PRXJLqfcI6j-YLBpO65NxzdOKCRyiVAp9LWfUCJXWO_Gevo5Ylow2OgWrLhkrRHQWm_CaGqWrqiYC1vNxONXV6hj5Cl4euiCUVKxwQ0-8n-we8c6aP3gu_bXOLA5cxcfkj8GgReJJDKw9S4qdA3fzLdr8GIKQUkTQjqnwQ'),
        ('electrical-appliances', 'ELECTRICAL APPLIANCES', 'High-Torque Indian Kitchen Technology • 1000W Heavy Motor Mixer Grinders & Inductions', 29, 'https://lh3.googleusercontent.com/aida-public/AB6AXuBs0__Bt86UxHbTUcIa8pqZ2_zu8m-1f-e4l89pLVDvoLGMp-dtUav38htufKI-CLag0xthpUa51h6hSVI4noTMhMZTkae_lEX1rM0yW87IYxb6Aqc2dTVhva8aEPayBsDx4dysILKpWs4S8KgEqpUW8dBp8d21H0vdVr8VD3Qi-k2PayxjB0YcJo0XZiVDayxAgCcuX9Ry4c2vZ05-JabPl0MBLHm_W1KhNwMOtwA')
    ]

    for cat in categories:
        cursor.execute('''
        INSERT OR REPLACE INTO categories (slug, name, description, product_count, image_url)
        VALUES (?, ?, ?, ?, ?)
        ''', cat)

    # Seed Products
    products = [
        {
            'slug': 'signature-tri-ply-heavy-bottom-kadhai-28l',
            'name': 'Signature Tri-Ply Stainless Steel Heavy Kadhai 2.8L',
            'category': 'cookware-and-kadhai',
            'category_name': 'Cookware & Kadhai',
            'material': 'Stainless Steel 304 Tri-Ply',
            'material_badge': 'SS 304 TRI-PLY',
            'retail_price': 1499.0,
            'mrp': 2199.0,
            'discount_percent': 32,
            'stock': 14,
            'rating': 4.95,
            'review_count': 418,
            'units_sold': 1820,
            'is_featured': 1,
            'is_bestseller': 1,
            'is_flash_deal': 1,
            'lead_description': 'With Stay-Cool Cast Handles & Steam-Vented Heavy Toughened Glass Lid. Engineered for authentic deep frying, curries, and halwa.',
            'detailed_description': 'Heavy 2.8mm 3-layer body with inner 304 food-grade steel, rapid virgin aluminum core for 100% even heat dispersion, and magnetic 430 outer base. Perfect for gas flames and induction cooktops. Tempered steam lid and stay-cool cast handles included.',
            'specs': json.dumps({
                "Base Thickness": "2.8 mm Tri-Ply",
                "Inner Layer": "Food-grade SS 304 (18/8)",
                "Middle Layer": "Pure Virgin Aluminum Heat Core",
                "Outer Layer": "Magnetic SS 430 (Induction Ready)",
                "Capacity": "2.8 Litres (Diameter 24cm)",
                "Gross Weight": "1.62 kg (with Glass Lid)",
                "Certification": "BIS Certified IS 14756",
                "Warranty": "10-Year Bonding Warranty"
            }),
            'variants': json.dumps([
                {"size": "2.2 Litre (22cm)", "price": 1299, "mrp": 1899, "save": 600},
                {"size": "2.8 Litre (24cm) - Most Popular", "price": 1499, "mrp": 2199, "save": 700},
                {"size": "3.5 Litre (26cm)", "price": 1799, "mrp": 2599, "save": 800}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuASzZcshcIU7MqiqI49QoHm7kOKPqI4c8OAa9P6MExd9Bg2lVvUxE3boge4huAKJbNh3Ur1oZC9WXX9wh3MTDKy1Fisw5DmAKHxAQPrFObSFSruLI4kMmYCmLsd9YqgBgO8F_MGGCwjk1XKTqYq_W_fqqoB6bTtehbqgusVx4kZTV_Foq0ADtUeThPini70dhmelwQitqtvmEfnvWrvEee6Z9KqfV8rFcjrRUWXpBU',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuASzZcshcIU7MqiqI49QoHm7kOKPqI4c8OAa9P6MExd9Bg2lVvUxE3boge4huAKJbNh3Ur1oZC9WXX9wh3MTDKy1Fisw5DmAKHxAQPrFObSFSruLI4kMmYCmLsd9YqgBgO8F_MGGCwjk1XKTqYq_W_fqqoB6bTtehbqgusVx4kZTV_Foq0ADtUeThPini70dhmelwQitqtvmEfnvWrvEee6Z9KqfV8rFcjrRUWXpBU',
                'https://lh3.googleusercontent.com/aida-public/AB6AXuD14y4kZnCdf2Oe2TFprk70PgqVUxvEGgLdagYl16uhsm5Q2OEp8tEf7d38yzF8tX9jJ-ZWyPquJ3XZcPdzWEcvmp7MIjxAeOCYg1fUkRCxSW6GwL-vIhRjLXHN1CblPRRRx7AUhc-KuAjbZEEhS2R3pmW3_MWHgjk0QwYRWNmfOwPkT_ix1en2A2EG6kSKg3ToHJLjVQVzrFHjMgzB3KU1am6PNiCylGpKasw39JI',
                'https://lh3.googleusercontent.com/aida-public/AB6AXuBl3_qZnH2nm0vewHGSqGca2ySDM6G0dhvzsEcud7MZtmi1tqaO0uwiwEl2L2_j-7aG9Cv5KVTH4W-7-2CbWdXZBlZ2k7Mddb1lLkkKhjmvoVTpN9tyQjj8jdcsMbPIs3E3FefVgaPACRhDjq8myuTM2NT8zPdacuBicZ-CNfRx9yO0iZi37-WkOPZ8x4CIS9ZWquO087dhnGU51H1Cuc9AgzxIWNLkIy-y5Lh5L5w',
                'https://lh3.googleusercontent.com/aida-public/AB6AXuAPJmGO-jdJXI5e1EayfO6ajwBcEQOKvpK6JGCD0RNxyz0h8vWdqZTZMfppLDDtxjdPUqdfa_pbkYJo8KVEJYp0iun220lu9wvZmTtctijaK6r0O8MhgVAKza9qAhrv1F06fcet-Rh9p8hQB1F-NOxi_7Dj_ni0Vg_xF64ufRe76hjPznrjBPZK0ntr7w4ozOOIXqtm9m40JEBpiSlurq-iOvmIK3YQXAs7hhfleB0',
                'https://lh3.googleusercontent.com/aida-public/AB6AXuBYxYKTjwaaxTMAcbjlwm4rmCVyQ5L4u_hryP5IESKJFo9xet6sUZcejtEhTeIc5LjMHpoSyMkhiQV7n-D39n6lydULB9FHiEsc6gAilfxkIp7rsEPKOCj0Tk5FflLJlr0BEDyN_03_GZtHQIiteSmG5OvXqDnhjnBIcJo6eTGTQEsQPiLXl1kkSQYQxl-erxncAqRPFZB0nCaipjg10CytNlehiBbXj5K4AD67muQ'
            ]),
            'heat_sources': 'Induction, Gas, Ceramic, Halogen',
            'warranty': '10-Year Bonding & Handle Warranty'
        },
        {
            'slug': 'royal-pure-brass-masala-dabba-7-katori',
            'name': 'Royal Pure Brass Masala Dabba (7 Katori)',
            'category': 'storage-and-tiffin',
            'category_name': 'Storage & Tiffin Dabbas',
            'material': '100% Pure Virgin Brass',
            'material_badge': '100% PURE BRASS',
            'retail_price': 1849.0,
            'mrp': 2499.0,
            'discount_percent': 26,
            'stock': 18,
            'rating': 4.9,
            'review_count': 420,
            'units_sold': 1240,
            'is_featured': 1,
            'is_bestseller': 1,
            'is_flash_deal': 0,
            'lead_description': 'Authentic heavy gauge brass spice container with airtight glass top and custom brass spice measuring spoon.',
            'detailed_description': 'Handcrafted by Moradabad artisans using 100% pure virgin brass. Contains 7 removable brass katoris and an engraved central spice spoon. Glass-embossed top lid preserves spice aromas and prevents moisture entry.',
            'specs': json.dumps({
                "Material": "Pure Heavy Gauge Brass (Pital)",
                "Compartments": "7 Individual Removable Katoris",
                "Accessories": "1 Engraved Brass Spoon Included",
                "Lid": "See-through Glass Center with Brass Rim",
                "Diameter": "20.5 cm",
                "Weight": "1.15 kg"
            }),
            'variants': json.dumps([
                {"size": "Standard 7-Katori (20cm)", "price": 1849, "mrp": 2499, "save": 650},
                {"size": "Jumbo 7-Katori (24cm)", "price": 2249, "mrp": 2999, "save": 750}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuBtuXEr9CE6j-J8I5MVLVroSFvBVPHm-luaeK6maf_5hGCUTchHMYhrrIzT9a6qRl5AvbDdEq82RhILo6s5sEnyr2AXcPfxxbtCdfuwcxWr8udb-2mxR1rSXMf8nX_nQ8zv-crmhAwH4QOiC_jmjhHHAS6dB7-JfaD5RbUKrr_6kbhl4DLhhXzg9WP9qZlLzWU_WnxOnJvIeaQFWhmYmXir_vsaSQAGj4YKht3fhkc',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuBtuXEr9CE6j-J8I5MVLVroSFvBVPHm-luaeK6maf_5hGCUTchHMYhrrIzT9a6qRl5AvbDdEq82RhILo6s5sEnyr2AXcPfxxbtCdfuwcxWr8udb-2mxR1rSXMf8nX_nQ8zv-crmhAwH4QOiC_jmjhHHAS6dB7-JfaD5RbUKrr_6kbhl4DLhhXzg9WP9qZlLzWU_WnxOnJvIeaQFWhmYmXir_vsaSQAGj4YKht3fhkc'
            ]),
            'heat_sources': 'Pantry / Countertop storage',
            'warranty': 'Lifetime Craftsmanship Guarantee'
        },
        {
            'slug': 'tri-ply-milk-and-tea-saucepan-18l',
            'name': 'Tri-Ply Milk & Tea Saucepan 1.8L with Pour Spout',
            'category': 'cookware-and-kadhai',
            'category_name': 'Cookware & Kadhai',
            'material': 'Stainless Steel 304 Tri-Ply',
            'material_badge': 'SS 304 TRI-PLY',
            'retail_price': 1149.0,
            'mrp': 1599.0,
            'discount_percent': 28,
            'stock': 42,
            'rating': 4.8,
            'review_count': 890,
            'units_sold': 2100,
            'is_featured': 0,
            'is_bestseller': 1,
            'is_flash_deal': 0,
            'lead_description': 'Even flame heat dispersion prevents milk burning. Induction compatible base with easy-pour drip-free spout.',
            'detailed_description': 'Say goodbye to scorched milk and burnt chai bottoms. The encapsulated aluminum core diffuses heat across base and sidewalls uniformly. Comes with internal volume measurement laser markings.',
            'specs': json.dumps({
                "Capacity": "1.8 Litres",
                "Diameter": "16 cm",
                "Handle": "Cast Stainless Steel Stay-Cool Riveted",
                "Spout": "Precision Dual Drip-Free Spouts",
                "Internal Markings": "500ml, 1000ml, 1500ml",
                "Weight": "0.95 kg"
            }),
            'variants': json.dumps([
                {"size": "1.2 Litre (14cm)", "price": 949, "mrp": 1299, "save": 350},
                {"size": "1.8 Litre (16cm)", "price": 1149, "mrp": 1599, "save": 450},
                {"size": "2.4 Litre (18cm)", "price": 1399, "mrp": 1899, "save": 500}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuCRJV7yg4QdeMa7yvwAhgVQkDvzEOuxngEyruHCXqgVpXOo3tWrJAf9a7BFj1uqyN2N_rGAznDLJs4nv8ggw324R0FsYCQyepCJUcH6dVvRCVMPH53WdMKPwMOxbjYacUF7m2Egb3_anRR72A1QYcrCskUrEupl7_0B_EEA3-5y8AjOqsIZ66OdhwDN6JrDM9kUoFeKuUtJf4d6GFIc6hsgtDI3hSfXgHQQp-T_FFM',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuCRJV7yg4QdeMa7yvwAhgVQkDvzEOuxngEyruHCXqgVpXOo3tWrJAf9a7BFj1uqyN2N_rGAznDLJs4nv8ggw324R0FsYCQyepCJUcH6dVvRCVMPH53WdMKPwMOxbjYacUF7m2Egb3_anRR72A1QYcrCskUrEupl7_0B_EEA3-5y8AjOqsIZ66OdhwDN6JrDM9kUoFeKuUtJf4d6GFIc6hsgtDI3hSfXgHQQp-T_FFM'
            ]),
            'heat_sources': 'Induction, Gas, Ceramic, Electric',
            'warranty': '10-Year Warranty'
        },
        {
            'slug': 'maharaja-heavy-ss-51-pc-dinner-set',
            'name': 'Maharaja Heavy SS 51-Pc Family Dinner Set',
            'category': 'dinner-sets',
            'category_name': 'Heavy Steel Dinner Sets',
            'material': 'Food-Grade 18/8 Stainless Steel',
            'material_badge': '51 PIECE SET',
            'retail_price': 3799.0,
            'mrp': 5499.0,
            'discount_percent': 31,
            'stock': 8,
            'rating': 4.9,
            'review_count': 1630,
            'units_sold': 3450,
            'is_featured': 1,
            'is_bestseller': 1,
            'is_flash_deal': 0,
            'lead_description': 'Full family dining setup in 18/8 food-grade high luster steel with lifetime rust warranty. Mirror polished.',
            'detailed_description': 'Includes 6 Full Thali Dinner Plates, 6 Quarter Plates, 12 Curry Katoris, 6 Halwa Dessert Bowls, 6 Drinking Tumblers, 6 Spoons, 6 Forks, 2 Serving Handis with Lids, and 1 Rice Platter with Serving Spoon.',
            'specs': json.dumps({
                "Pieces": "51 Complete Pieces",
                "Material": "AISI 304 18/8 Gauge Steel",
                "Finish": "Permanent Mirror Polish Finish",
                "Dishwasher Safe": "Yes, 100% Rust-proof",
                "Weight": "6.8 kg Boxed Weight"
            }),
            'variants': json.dumps([
                {"size": "24-Pc Couple Dining Set", "price": 2199, "mrp": 3199, "save": 1000},
                {"size": "51-Pc Maharaja Family Set", "price": 3799, "mrp": 5499, "save": 1700},
                {"size": "68-Pc Grand Royal Banquet Set", "price": 4999, "mrp": 6999, "save": 2000}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuD7QjEbp092pvhEn7x2Z0p4pXB0zU62OGPZ7CzwHAmgGFZa_sflXu7tkxrUd4eMKWB7dBGhuvLpDcFUUitsguUT3XGowQ9GB_ZyF3SYiwAeeX67w8kP3BscLFdvxnz538LXMwlP5UxdYxhMpEgC4TVgiakp5tK4r4DdTQ4acCXORr3D12vwrv3Ajy3QqxJb98IZEk_PEwSny596CUTQC9bYU4UoaepYEk-DnMogE1s',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuD7QjEbp092pvhEn7x2Z0p4pXB0zU62OGPZ7CzwHAmgGFZa_sflXu7tkxrUd4eMKWB7dBGhuvLpDcFUUitsguUT3XGowQ9GB_ZyF3SYiwAeeX67w8kP3BscLFdvxnz538LXMwlP5UxdYxhMpEgC4TVgiakp5tK4r4DdTQ4acCXORr3D12vwrv3Ajy3QqxJb98IZEk_PEwSny596CUTQC9bYU4UoaepYEk-DnMogE1s'
            ]),
            'heat_sources': 'Serveware & Dining',
            'warranty': 'Lifetime Anti-Rust Guarantee'
        },
        {
            'slug': 'hand-hammered-copper-water-matka-5l',
            'name': 'Hand-Hammered Pure Copper Water Matka 5L with Brass Tap',
            'category': 'festive-brass-and-copper',
            'category_name': 'Festive Brass & Copper',
            'material': '99.2% Pure Certified Copper',
            'material_badge': '99.2% PURE COPPER',
            'retail_price': 2199.0,
            'mrp': 2999.0,
            'discount_percent': 27,
            'stock': 21,
            'rating': 4.9,
            'review_count': 780,
            'units_sold': 1580,
            'is_featured': 1,
            'is_bestseller': 1,
            'is_flash_deal': 0,
            'lead_description': 'Ayurvedic water balancing properties with leakproof brass tap and wooden tabletop stand. Hand-hammered sheen.',
            'detailed_description': 'Infuses drinking water with natural copper trace ions (Tamra Jal). Features a leak-proof forged brass spigot tap and includes a solid Sheesham wood tabletop stand.',
            'specs': json.dumps({
                "Capacity": "5.0 Litres",
                "Purity": "99.2% Lab-Tested Pure Copper",
                "Tap": "Heavy Pure Brass Dispenser Tap",
                "Stand": "Included Solid Wooden Base",
                "Maintenance": "Clean with Lemon & Pitambari Powder"
            }),
            'variants': json.dumps([
                {"size": "3.5 Litre Tabletop", "price": 1799, "mrp": 2399, "save": 600},
                {"size": "5.0 Litre Family Size", "price": 2199, "mrp": 2999, "save": 800},
                {"size": "8.0 Litre Party Dispenser", "price": 2899, "mrp": 3899, "save": 1000}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuB7PTOj5E4wrjTUviKAePDASrQykXWtQBj_ITnDpvLRtpjkiEaJQJQJi8Cu4L-sulC7O3sSN-gY1jAjAw_lzL0s0OKWjJc7WQhOjyPrE5xoIj10QLJevlUlwc4OeLaiBfMswd9cS43e81WqF6C6fgPBn0r-N4u-vVVUWImkoO4XFmKulduFEtokG0Uax1ZkpmLdSWESlG1Y4L9BrjIZDqFGCjHeTWAjCkOstP2OPeU',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuB7PTOj5E4wrjTUviKAePDASrQykXWtQBj_ITnDpvLRtpjkiEaJQJQJi8Cu4L-sulC7O3sSN-gY1jAjAw_lzL0s0OKWjJc7WQhOjyPrE5xoIj10QLJevlUlwc4OeLaiBfMswd9cS43e81WqF6C6fgPBn0r-N4u-vVVUWImkoO4XFmKulduFEtokG0Uax1ZkpmLdSWESlG1Y4L9BrjIZDqFGCjHeTWAjCkOstP2OPeU'
            ]),
            'heat_sources': 'Water Storage / Hydration',
            'warranty': '5-Year Purity Guarantee'
        },
        {
            'slug': 'traditional-heavy-pure-brass-handi-32l',
            'name': 'Traditional Pure Brass Lagan & Biryani Handi 3.2L',
            'category': 'festive-brass-and-copper',
            'category_name': 'Festive Brass & Copper',
            'material': 'Heavy Forged Brass with Kalai Lining',
            'material_badge': 'KALAI CERTIFIED',
            'retail_price': 2499.0,
            'mrp': 3499.0,
            'discount_percent': 29,
            'stock': 12,
            'rating': 4.95,
            'review_count': 310,
            'units_sold': 920,
            'is_featured': 1,
            'is_bestseller': 0,
            'is_flash_deal': 0,
            'lead_description': 'Authentic Moradabad forged brass handi with interior tin-lining (Kalai) for slow dum cooking and rich curries.',
            'detailed_description': 'The secret behind authentic Awadhi biryani and dal makhani. Heavy brass distributes heat gently and preserves moisture under dum sealing.',
            'specs': json.dumps({
                "Capacity": "3.2 Litres",
                "Weight": "2.4 kg Extra Heavy",
                "Interior": "Genuine Artisanal Tin (Kalai) Lined",
                "Lid": "Cast Brass Heavy Aroma-Lock Lid"
            }),
            'variants': json.dumps([
                {"size": "2.0 Litre Handi", "price": 1899, "mrp": 2599, "save": 700},
                {"size": "3.2 Litre Handi", "price": 2499, "mrp": 3499, "save": 1000},
                {"size": "5.5 Litre Feast Handi", "price": 3699, "mrp": 4999, "save": 1300}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuCiREzE1XNkTlgUcmUo7B5CszEmXXFtOuQ3jR_RbxeotmnKiQjXQ9b5nFEF8MnZFNbVt0oP1S3uYYLIndqzuZUQzebO76cjAMMrrqQbdIhd2bvzaJ2qxwEA5-r3XPetu1_dq43CqCHuNOqFV5ew2V-ByDs_HG3cHzCM9FdDC2YQHYJy5Rm5EJ-fyIk5_QjFjgVz-dRGTR-4PfrfkdF_sZ2y5XsSETKKu4PC-IkXOEE',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuCiREzE1XNkTlgUcmUo7B5CszEmXXFtOuQ3jR_RbxeotmnKiQjXQ9b5nFEF8MnZFNbVt0oP1S3uYYLIndqzuZUQzebO76cjAMMrrqQbdIhd2bvzaJ2qxwEA5-r3XPetu1_dq43CqCHuNOqFV5ew2V-ByDs_HG3cHzCM9FdDC2YQHYJy5Rm5EJ-fyIk5_QjFjgVz-dRGTR-4PfrfkdF_sZ2y5XsSETKKu4PC-IkXOEE'
            ]),
            'heat_sources': 'Gas Flame, Charcoal, Woodfire',
            'warranty': 'Lifetime Alloy Quality Assurance'
        },
        {
            'slug': 'complete-11-piece-brass-puja-thali-set',
            'name': 'Complete 11-Piece Pure Brass Mandir Puja Thali Set',
            'category': 'festive-brass-and-copper',
            'category_name': 'Festive Brass & Copper',
            'material': 'Embossed Pure Brass',
            'material_badge': 'PUJA SPECIAL',
            'retail_price': 1299.0,
            'mrp': 1799.0,
            'discount_percent': 28,
            'stock': 26,
            'rating': 4.9,
            'review_count': 540,
            'units_sold': 1950,
            'is_featured': 0,
            'is_bestseller': 1,
            'is_flash_deal': 0,
            'lead_description': 'With embossed Gayatri Mantra rim, Akhand Diya lamp, brass Ghanti bell, Kalash lota, and incense holder.',
            'detailed_description': 'Brings sacred radiance into your home altar. High-purity brass thali with intricate auspicious engravings, perfectly balanced for Diwali, Navratri, and daily morning aarti.',
            'specs': json.dumps({
                "Components": "Thali, Diya, Ghanti, Lota, Spoon, Agarbatti stand, Kapoor aarti, 2 Chandan katoris, Bell",
                "Diameter": "25 cm Thali",
                "Weight": "0.85 kg"
            }),
            'variants': json.dumps([
                {"size": "9-Piece Compact Set (21cm)", "price": 999, "mrp": 1399, "save": 400},
                {"size": "11-Piece Complete Mandir Set (25cm)", "price": 1299, "mrp": 1799, "save": 500}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuB9Z1hfcJywbSI1Nrt0J-pdTHEoIBg5NCXsP3cD2-30OAcrQxKT6tmnL9uEZk3ymp4YE7Egw50LPF1q0-A7UgDnxoiUlo6Rd8EkQgXQT1gIjMSiOjFbihbMaiOPVSZAk8TB87RHD9_eWQIDPCVK5iWJxl6ayBnFmUr3JfuUjJ91HnOHQx_PT9tVbSF431hojLW-f6seOmmOgZmEtZ5-P_7GXShKpQgCUVqqz6cJlmk',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuB9Z1hfcJywbSI1Nrt0J-pdTHEoIBg5NCXsP3cD2-30OAcrQxKT6tmnL9uEZk3ymp4YE7Egw50LPF1q0-A7UgDnxoiUlo6Rd8EkQgXQT1gIjMSiOjFbihbMaiOPVSZAk8TB87RHD9_eWQIDPCVK5iWJxl6ayBnFmUr3JfuUjJ91HnOHQx_PT9tVbSF431hojLW-f6seOmmOgZmEtZ5-P_7GXShKpQgCUVqqz6cJlmk'
            ]),
            'heat_sources': 'Puja & Rituals',
            'warranty': 'Lifetime Craftsmanship Guarantee'
        },
        {
            'slug': 'hard-anodised-outer-lid-pressure-cooker-5l',
            'name': 'Hard Anodised Heavy Base Pressure Cooker 5L',
            'category': 'pressure-cookers',
            'category_name': 'Pressure Cookers',
            'material': 'Hard Anodised Aluminium 3.25mm',
            'material_badge': 'ISI CERTIFIED',
            'retail_price': 1699.0,
            'mrp': 2299.0,
            'discount_percent': 26,
            'stock': 19,
            'rating': 4.85,
            'review_count': 670,
            'units_sold': 1480,
            'is_featured': 1,
            'is_bestseller': 1,
            'is_flash_deal': 0,
            'lead_description': 'Heavy 3.25mm body with non-reactive black anodised surface, precision whistle, and metallic safety plug.',
            'detailed_description': 'Thermal-efficient hard anodized body absorbs heat rapidly and cooks 30% faster than standard aluminium cookers. Acidic foods like tomatoes and tamarind do not pit or corrode.',
            'specs': json.dumps({
                "Capacity": "5.0 Litres",
                "Thickness": "3.25 mm Base & Walls",
                "Safety": "Dual Safety Valve & Gasket Release System",
                "Standards": "ISI Certified IS 2347",
                "Handles": "Heat-Resistant Bakelite"
            }),
            'variants': json.dumps([
                {"size": "3.0 Litre (Compact Family)", "price": 1399, "mrp": 1899, "save": 500},
                {"size": "5.0 Litre (Standard Family)", "price": 1699, "mrp": 2299, "save": 600},
                {"size": "7.5 Litre (Large Family)", "price": 2199, "mrp": 2899, "save": 700}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuCDKfEDpnjYsqlja7ssbgmkGkwbji9vqizbAZHKu4JEKRVjUZTv_1ngp9mb_SCFV0VVSW9D-j1v0-LCddYnlvyb4XrZoCYOxAPvG9GeTVlVZIvjcR4o9FrN822nzJyW0zSIUKPzMSC8OGH1MvOwX4t4Sz2TxHLzg8T-AyBAxrN-XX00QwjBT1OR-UF2wt3BVwS5_0ruGnkCXHlonFonfB6DziPtfghYMZh5scV7g6Y',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuCDKfEDpnjYsqlja7ssbgmkGkwbji9vqizbAZHKu4JEKRVjUZTv_1ngp9mb_SCFV0VVSW9D-j1v0-LCddYnlvyb4XrZoCYOxAPvG9GeTVlVZIvjcR4o9FrN822nzJyW0zSIUKPzMSC8OGH1MvOwX4t4Sz2TxHLzg8T-AyBAxrN-XX00QwjBT1OR-UF2wt3BVwS5_0ruGnkCXHlonFonfB6DziPtfghYMZh5scV7g6Y'
            ]),
            'heat_sources': 'Induction & Gas Stove Compatible',
            'warranty': '5-Year Manufacturer Warranty'
        },
        {
            'slug': 'airtight-stainless-steel-pantry-storage-containers-set-of-6',
            'name': 'Airtight Stainless Steel Grain & Dal Storage Bins (Set of 6)',
            'category': 'storage-and-tiffin',
            'category_name': 'Storage & Tiffin Dabbas',
            'material': 'Food Grade SS 304',
            'material_badge': 'AIRTIGHT SEAL',
            'retail_price': 1599.0,
            'mrp': 2199.0,
            'discount_percent': 27,
            'stock': 35,
            'rating': 4.88,
            'review_count': 390,
            'units_sold': 1100,
            'is_featured': 0,
            'is_bestseller': 0,
            'is_flash_deal': 0,
            'lead_description': 'Food-safe 304 steel with see-through silicone-gasket lids. 100% insect and moisture-proof storage.',
            'detailed_description': 'Protect your precious lentils, rice, wheat, and snacks from pantry weevils and monsoon dampness. Includes 6 nesting jars from 500ml to 2.5L capacity.',
            'specs': json.dumps({
                "Quantity": "Set of 6 Graduated Canisters",
                "Lids": "Shatter-Proof Acrylic with Food-grade Silicone Ring",
                "Sizes": "500ml, 750ml, 1000ml, 1500ml, 2000ml, 2500ml",
                "Weight": "2.2 kg Total Set"
            }),
            'variants': json.dumps([
                {"size": "Set of 4 (500ml - 1.5L)", "price": 1199, "mrp": 1599, "save": 400},
                {"size": "Set of 6 (500ml - 2.5L)", "price": 1599, "mrp": 2199, "save": 600}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuBztyfZh39QlbIhfu65nXp-pEa43XTxszgmq8IxsdoDSLFVuaGJOPYbAtLUURbak9a_cUaJh_Lda6A_znjjpjF51krgwuE8QfO_eF95rJOEKY4lxV2MtPI-JF1MjUuBB6bcJFKwoyVmBN8guFcKYQOsGC30R1EkLMXFSXe9j_uOMDDdMvf09OdAJLRYU0BuSkAA_4Rhktd9rv2KGzmVMfTwnmTIg0y3vSguG5mr_g0',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuBztyfZh39QlbIhfu65nXp-pEa43XTxszgmq8IxsdoDSLFVuaGJOPYbAtLUURbak9a_cUaJh_Lda6A_znjjpjF51krgwuE8QfO_eF95rJOEKY4lxV2MtPI-JF1MjUuBB6bcJFKwoyVmBN8guFcKYQOsGC30R1EkLMXFSXe9j_uOMDDdMvf09OdAJLRYU0BuSkAA_4Rhktd9rv2KGzmVMfTwnmTIg0y3vSguG5mr_g0'
            ]),
            'heat_sources': 'Pantry Storage',
            'warranty': 'Lifetime Rust Resistance'
        },
        {
            'slug': 'commercial-heavy-biryani-handi-40l',
            'name': 'Commercial 16-Gauge Catering Biryani Handi 40L',
            'category': 'commercial-bulk-hotelware',
            'category_name': 'Commercial Hotel & Catering',
            'material': 'Industrial 16-Gauge SS 304',
            'material_badge': 'HOTEL GRADE 16G',
            'retail_price': 5499.0,
            'mrp': 7500.0,
            'discount_percent': 26,
            'stock': 15,
            'rating': 4.95,
            'review_count': 180,
            'units_sold': 580,
            'is_featured': 1,
            'is_bestseller': 0,
            'is_flash_deal': 0,
            'lead_description': 'Extra heavy 16-gauge industrial cookware with reinforced welded handles for catering and cloud kitchens.',
            'detailed_description': 'Built to withstand intense commercial gas burners and high-volume catering demands. Thick base prevents rice burning at the bottom during dum cooking.',
            'specs': json.dumps({
                "Capacity": "40 Litres (Serves 80-100 portions)",
                "Gauge": "Heavy 16-Gauge (1.6mm solid thickness)",
                "Handles": "Heavy Tubular Solid Welded Handles",
                "Weight": "7.5 kg Dry Weight",
                "GST Input Eligible": "Yes, HSN 7323"
            }),
            'variants': json.dumps([
                {"size": "25 Litre (Serves 50)", "price": 3899, "mrp": 5200, "save": 1301},
                {"size": "40 Litre (Serves 80)", "price": 5499, "mrp": 7500, "save": 2001},
                {"size": "70 Litre (Serves 150)", "price": 8999, "mrp": 11999, "save": 3000}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuD8VZKL5zsMiNQdqA-_Ldl040Lh7HR1vkmvpjSYSDvwx0WYO4JpPbubplhYccVhXLK9K9EVmkfQRen6Z1lEktHwgIoZSmmoMnlISmaK5jHrdwjc00yEn3rRhVVRiSX_vwlwxrlFlAyT2b031oyrTftfHJJxrciA-xv6n3TDANpJW7M4Fc62SSHC_WGVn-dofP1nHWvldxFUGxWisrPgdIJEaimVl2zphJir0l1dAiM',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuD8VZKL5zsMiNQdqA-_Ldl040Lh7HR1vkmvpjSYSDvwx0WYO4JpPbubplhYccVhXLK9K9EVmkfQRen6Z1lEktHwgIoZSmmoMnlISmaK5jHrdwjc00yEn3rRhVVRiSX_vwlwxrlFlAyT2b031oyrTftfHJJxrciA-xv6n3TDANpJW7M4Fc62SSHC_WGVn-dofP1nHWvldxFUGxWisrPgdIJEaimVl2zphJir0l1dAiM'
            ]),
            'heat_sources': 'High-Pressure Commercial Burners & Gas',
            'warranty': '5-Year Commercial Heavy Duty Warranty'
        },
        {
            'slug': 'mirror-polish-stainless-steel-ladle-and-jhara-set-of-5',
            'name': 'Mirror Polish Stainless Steel Ladle & Jhara Skimmer Set (5 Pcs)',
            'category': 'stainless-steel-utensils',
            'category_name': 'Ladles, Skimmers & Cutlery',
            'material': 'Single-Sheet Pressed SS 304',
            'material_badge': 'SINGLE-PIECE DIE',
            'retail_price': 699.0,
            'mrp': 999.0,
            'discount_percent': 30,
            'stock': 60,
            'rating': 4.9,
            'review_count': 320,
            'units_sold': 1750,
            'is_featured': 0,
            'is_bestseller': 1,
            'is_flash_deal': 0,
            'lead_description': 'Seamless single-sheet pressing, zero joint stains. Includes deep dal karchhi, puri jhara, palta spatula, and skimmer.',
            'detailed_description': 'Heavy gauge single-piece construction without weak rivets or welds where food grease accumulates. Ergonomic handles with hanging loop hooks.',
            'specs': json.dumps({
                "Pieces": "Deep Dal Karchhi, Puri Jhara, Dosa Palta, Rice Server, Soup Ladle",
                "Construction": "Monobloc Seamless Stamping",
                "Length": "34 cm each for heat protection"
            }),
            'variants': json.dumps([
                {"size": "Standard 5-Piece Culinary Set", "price": 699, "mrp": 999, "save": 300}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuBs0__Bt86UxHbTUcIa8pqZ2_zu8m-1f-e4l89pLVDvoLGMp-dtUav38htufKI-CLag0xthpUa51h6hSVI4noTMhMZTkae_lEX1rM0yW87IYxb6Aqc2dTVhva8aEPayBsDx4dysILKpWs4S8KgEqpUW8dBp8d21H0vdVr8VD3Qi-k2PayxjB0YcJo0XZiVDayxAgCcuX9Ry4c2vZ05-JabPl0MBLHm_W1KhNwMOtwA',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuBs0__Bt86UxHbTUcIa8pqZ2_zu8m-1f-e4l89pLVDvoLGMp-dtUav38htufKI-CLag0xthpUa51h6hSVI4noTMhMZTkae_lEX1rM0yW87IYxb6Aqc2dTVhva8aEPayBsDx4dysILKpWs4S8KgEqpUW8dBp8d21H0vdVr8VD3Qi-k2PayxjB0YcJo0XZiVDayxAgCcuX9Ry4c2vZ05-JabPl0MBLHm_W1KhNwMOtwA'
            ]),
            'heat_sources': 'Everyday Cooking',
            'warranty': 'Lifetime Durability Guarantee'
        },
        {
            'slug': 'pre-seasoned-cast-iron-and-tri-ply-roti-tawa-28cm',
            'name': 'Heavy Pre-Seasoned Roti Tawa & Dosa Pan 28cm',
            'category': 'roti-tawa-and-dosa',
            'category_name': 'Roti Tawa & Dosa Pans',
            'material': 'Pre-Seasoned Pure Cast Iron',
            'material_badge': 'CHEMICAL-FREE',
            'retail_price': 1099.0,
            'mrp': 1599.0,
            'discount_percent': 31,
            'stock': 22,
            'rating': 4.88,
            'review_count': 510,
            'units_sold': 1630,
            'is_featured': 0,
            'is_bestseller': 1,
            'is_flash_deal': 0,
            'lead_description': 'Even-heat distribution for crisp golden dosas & ballooning soft phulkas. Naturally non-stick with gingelly oil seasoning.',
            'detailed_description': 'Zero Teflon, zero toxic synthetic PFAS chemicals. Naturally seasoned with 100% natural vegetable oil for 3 cycles in the foundry before shipping. Enriches food with natural iron.',
            'specs': json.dumps({
                "Diameter": "28 cm (11 inches)",
                "Thickness": "4.5 mm Heavy Base",
                "Weight": "2.1 kg",
                "Pre-Seasoning": "Pre-seasoned with cold-pressed oil"
            }),
            'variants': json.dumps([
                {"size": "25 cm Phulka Tawa", "price": 899, "mrp": 1299, "save": 400},
                {"size": "28 cm Dosa & Paratha Tawa", "price": 1099, "mrp": 1599, "save": 500}
            ]),
            'image_url': 'https://lh3.googleusercontent.com/aida-public/AB6AXuBNGSur6nFGrCqAmoCdcxdhiPPhMnEn10E_6pKIDZRNUej9doq9s5kErt1ioKD_PlPI0PRXJLqfcI6j-YLBpO65NxzdOKCRyiVAp9LWfUCJXWO_Gevo5Ylow2OgWrLhkrRHQWm_CaGqWrqiYC1vNxONXV6hj5Cl4euiCUVKxwQ0-8n-we8c6aP3gu_bXOLA5cxcfkj8GgReJJDKw9S4qdA3fzLdr8GIKQUkTQjqnwQ',
            'gallery': json.dumps([
                'https://lh3.googleusercontent.com/aida-public/AB6AXuBNGSur6nFGrCqAmoCdcxdhiPPhMnEn10E_6pKIDZRNUej9doq9s5kErt1ioKD_PlPI0PRXJLqfcI6j-YLBpO65NxzdOKCRyiVAp9LWfUCJXWO_Gevo5Ylow2OgWrLhkrRHQWm_CaGqWrqiYC1vNxONXV6hj5Cl4euiCUVKxwQ0-8n-we8c6aP3gu_bXOLA5cxcfkj8GgReJJDKw9S4qdA3fzLdr8GIKQUkTQjqnwQ'
            ]),
            'heat_sources': 'Induction, Gas, Campfire, Oven',
            'warranty': 'Lifetime Unbreakable Cast Iron Guarantee'
        }
    ]

    for p in products:
        cursor.execute('''
        INSERT INTO products (
            slug, name, category, category_name, material, material_badge,
            retail_price, mrp, discount_percent, stock, rating, review_count,
            units_sold, is_featured, is_bestseller, is_flash_deal,
            lead_description, detailed_description, specs, variants,
            image_url, gallery, heat_sources, warranty
        ) VALUES (
            :slug, :name, :category, :category_name, :material, :material_badge,
            :retail_price, :mrp, :discount_percent, :stock, :rating, :review_count,
            :units_sold, :is_featured, :is_bestseller, :is_flash_deal,
            :lead_description, :detailed_description, :specs, :variants,
            :image_url, :gallery, :heat_sources, :warranty
        )
        ''', p)

    # Seed Sample Active Order for Rajesh Kumar (matching the tracking design!)
    cursor.execute('''
    INSERT INTO orders (
        order_number, customer_name, email, phone, address, city, state, pincode,
        gstin, business_name, payment_method, payment_status, payment_id,
        subtotal, discount, shipping_fee, tax_amount, total_amount,
        order_status, tracking_partner, tracking_awb, expected_delivery
    ) VALUES (
        'KALASH-ORD-20261008-00125', 'Rajesh Kumar', 'rajesh.k@gmail.com', '+91 98200 54321',
        'Flat 402, Sea View Heights, Marine Drive', 'Kota', 'Maharashtra', '400002',
        '', 'Kalash Corp Hospitality', 'UPI', 'Paid', 'pay_Oc78129d',
        2478.0, 372.0, 0.0, 378.0, 2484.0,
        'Out for Delivery', 'BlueDart Express Air', 'BLUEDT982187319', 'Today, 2:00 PM – 5:00 PM'
    )
    ''')
    order_id = cursor.lastrowid

    # Seed Order Items
    cursor.execute('''
    INSERT INTO order_items (order_id, product_id, product_name, variant_name, unit_price, quantity, subtotal, image_url)
    VALUES (
        ?, 1, 'Signature Tri-Ply Stainless Steel Heavy Kadhai 2.8L', '2.8 Litre (24cm)', 1499.0, 1, 1499.0,
        'https://lh3.googleusercontent.com/aida-public/AB6AXuDNozLCsLKAUgTzqJ7UiQNU7-6wzIHK5apa2SXcUbWz8G9MC78I20PN4GRKnNtXCGW3nb_dwlLDqjiMqk2SGG-__AbUbfcIiUsrB-hCwDvs5g-aKCkeWqLxmYyiHcT2g_UngqWKSgZp4sT3Xfb-byxNpXWRw1ZQACII2JiTCDkwKo964bwqbnZZ3-QlyxtKdv3oAIKrBOBGKBpwJoxvfuam9qUI06bvc74nt4xRT7c'
    )
    ''', (order_id,))

    cursor.execute('''
    INSERT INTO order_items (order_id, product_id, product_name, variant_name, unit_price, quantity, subtotal, image_url)
    VALUES (
        ?, 11, 'Mirror Polish Stainless Steel Ladle & Jhara Skimmer Set (5 Pcs)', '5-Piece Set', 699.0, 1, 699.0,
        'https://lh3.googleusercontent.com/aida-public/AB6AXuBs0__Bt86UxHbTUcIa8pqZ2_zu8m-1f-e4l89pLVDvoLGMp-dtUav38htufKI-CLag0xthpUa51h6hSVI4noTMhMZTkae_lEX1rM0yW87IYxb6Aqc2dTVhva8aEPayBsDx4dysILKpWs4S8KgEqpUW8dBp8d21H0vdVr8VD3Qi-k2PayxjB0YcJo0XZiVDayxAgCcuX9Ry4c2vZ05-JabPl0MBLHm_W1KhNwMOtwA'
    )
    ''', (order_id,))

    # Seed Delivered Past Order
    cursor.execute('''
    INSERT INTO orders (
        order_number, customer_name, email, phone, address, city, state, pincode,
        gstin, business_name, payment_method, payment_status, payment_id,
        subtotal, discount, shipping_fee, tax_amount, total_amount,
        order_status, tracking_partner, tracking_awb, expected_delivery
    ) VALUES (
        'KALASH-ORD-20260915-00084', 'Rajesh Kumar', 'rajesh.k@gmail.com', '+91 98200 54321',
        'Flat 402, Sea View Heights, Marine Drive', 'Kota', 'Maharashtra', '400002',
        '', 'Kalash Corp Hospitality', 'Credit Card', 'Paid', 'pay_Nb44192a',
        3799.0, 0.0, 0.0, 683.82, 4482.82,
        'Delivered', 'Delhivery Express', 'DELHIVERY440912', 'Delivered on 18 Sep 2026'
    )
    ''')
    past_order_id = cursor.lastrowid
    cursor.execute('''
    INSERT INTO order_items (order_id, product_id, product_name, variant_name, unit_price, quantity, subtotal, image_url)
    VALUES (
        ?, 4, 'Maharaja Heavy SS 51-Pc Family Dinner Set', '51-Pc Set', 3799.0, 1, 3799.0,
        'https://lh3.googleusercontent.com/aida-public/AB6AXuD7QjEbp092pvhEn7x2Z0p4pXB0zU62OGPZ7CzwHAmgGFZa_sflXu7tkxrUd4eMKWB7dBGhuvLpDcFUUitsguUT3XGowQ9GB_ZyF3SYiwAeeX67w8kP3BscLFdvxnz538LXMwlP5UxdYxhMpEgC4TVgiakp5tK4r4DdTQ4acCXORr3D12vwrv3Ajy3QqxJb98IZEk_PEwSny596CUTQC9bYU4UoaepYEk-DnMogE1s'
    )
    ''', (past_order_id,))

    # Seed B2B Wholesale Leads
    b2b_samples = [
        ('Swad Sagar Catering', '+91 98201 98765', 'swadsagar@gmail.com', 'Commercial Heavy Biryani Handis (20L - 100L)', 65000.0, '12% OFF Commercial Tier', 57200.0, 'In Review'),
        ('Hotel Orchid Banquet', '+91 98111 23456', 'procure@orchidmumbai.com', 'Restaurant Thali & Tableware Bulk Sets (500 sets)', 180000.0, '20% OFF Wholesale Partner', 144000.0, 'Quote Dispatched')
    ]
    for b in b2b_samples:
        cursor.execute('''
        INSERT INTO b2b_inquiries (business_name, contact_phone, email, product_requirement, estimated_value, discount_tier, net_billing_price, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', b)

    # Seed Reviews for Tri-Ply Kadhai
    reviews = [
        (1, 'Shalini Sharma', 'New Delhi', 'Verified Buyer', 5, 'The 2.8L Tri-ply Kadhai completely changed my evening cooking. Deep frying puris uses far less oil, and sweet halwa does not stick at all. The heavy bottom stays stable even on high burner flames!'),
        (1, 'Vikram Raghavan', 'Bengaluru', 'B2B Client', 5, 'We ordered commercial stainless steel thali sets and handis for our South Indian restaurant in Indiranagar. The mirror polish is pristine, gauge thickness is top-notch, and GST invoice was instant.'),
        (1, 'Nandita Mehta', 'Kota', 'Verified Buyer', 5, 'Purchased the Brass Masala Dabba and Copper Water Dispenser for Diwali gifting. Stunning craftsmanship! Reminded my mother of the heritage bartan from ancestral times in Rajasthan.')
    ]
    for r in reviews:
        cursor.execute('''
        INSERT INTO reviews (product_id, author_name, location, user_type, rating, comment)
        VALUES (?, ?, ?, ?, ?, ?)
        ''', r)

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    seed_db()
    print("Kalash Enterprises database initialized and seeded successfully.")
