"""
Kalash Enterprises - Production Multi-Threaded WSGI Server (Waitress)
High-performance production server suitable for Windows, Linux, and Cloud VMs.
Binds to port 80/443 or custom port for www.kalashenterprises.co.in
"""

import os
import sys
from waitress import serve
from wsgi import app

def run_server():
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '0.0.0.0')
    threads = int(os.environ.get('THREADS', 16))

    print("=" * 70)
    print(" KALASH ENTERPRISES - PRODUCTION WEB SERVER (WAITRESS WSGI)")
    print(" Estd. 2011 | Kota, Rajasthan, India | Pincode: 324001")
    print(" Target Domain: https://www.kalashenterprises.co.in")
    print(f" Listening on: http://{host}:{port}")
    print(f" Worker Threads: {threads}")
    print("=" * 70)

    try:
        serve(
            app,
            host=host,
            port=port,
            threads=threads,
            channel_timeout=60,
            cleanup_interval=30,
            ident="Kalash-Enterprises-WSGI/1.0"
        )
    except Exception as e:
        print(f"[FATAL SERVER ERROR] {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    run_server()
