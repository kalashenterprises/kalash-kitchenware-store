"""
Kalash Enterprises - Kitchenware & Utensils Store
Main Application Server in Python (Flask)
Estd. 2011, Shop Number3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan, India, Pincode: 324001
"""

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, Response
import sqlite3
import json
import random
from datetime import datetime
import urllib.parse
import os
import database
import sms_gateway
import customer_sheets
from upi_payment import generate_upi_payment_qr, send_whatsapp_order_details, DEFAULT_OWNER_VPA, DEFAULT_BUSINESS_NAME

app = Flask(__name__)
app.secret_key = 'kalash_secret_artisan_brass_key_2011'

# Ensure Database and Customer Ledger are initialized on startup
database.init_db()
database.seed_db()
customer_sheets.seed_initial_customers_if_empty()

def get_db():
    conn = database.get_db()
    return conn

# Helper to calculate cart summary
def get_cart_summary():
    cart = session.get('cart', [])
    coupon = session.get('coupon', None)
    
    count = 0
    subtotal = 0.0
    for item in cart:
        count += item['quantity']
        subtotal += item['unit_price'] * item['quantity']
        
    discount = 0.0
    discount_rate = 0.0
    if coupon == 'UTSAV15':
        discount_rate = 0.15
        discount = subtotal * 0.15
    elif coupon == 'KALASH250':
        discount = min(250.0, subtotal)
    elif coupon == 'BULK10':
        discount_rate = 0.10
        discount = subtotal * 0.10

    # Free delivery on orders over ₹999
    shipping = 0.0 if (subtotal >= 999 or count == 0) else 149.0
    
    # GST calculation (18% inclusive)
    net_after_discount = max(0.0, subtotal - discount)
    tax = round(net_after_discount * 0.18 / 1.18, 2)
    total = net_after_discount + shipping

    return {
        'count': count,
        'subtotal': subtotal,
        'discount': discount,
        'discount_rate': discount_rate,
        'shipping': shipping,
        'tax': tax,
        'total': total,
        'coupon_code': coupon
    }

@app.context_processor
def inject_cart():
    summary = get_cart_summary()
    try:
        upi_qr = generate_upi_payment_qr(
            vpa=DEFAULT_OWNER_VPA,
            business_name=DEFAULT_BUSINESS_NAME,
            order_id="KLSH-CART",
            amount=summary['total']
        )
    except Exception:
        upi_qr = {
            "upi_uri": f"upi://pay?pa={DEFAULT_OWNER_VPA}&pn={DEFAULT_BUSINESS_NAME}&am={summary['total']:.2f}&cu=INR&tn=Order_Cart",
            "base64_image": "",
            "vpa": DEFAULT_OWNER_VPA,
            "amount": summary['total']
        }
    return {'cart_summary': summary, 'upi_qr': upi_qr}

# ==================== STOREFRONT ROUTES ====================

@app.route('/')
@app.route('/home')
def home():
    conn = get_db()
    cursor = conn.cursor()
    
    # Categories
    cursor.execute('SELECT * FROM categories')
    categories = cursor.fetchall()
    
    # Bestsellers
    cursor.execute('SELECT * FROM products WHERE is_bestseller = 1 LIMIT 8')
    bestsellers = cursor.fetchall()
    
    # Flash deal product
    cursor.execute('SELECT * FROM products WHERE is_flash_deal = 1 LIMIT 1')
    flash_product = cursor.fetchone()
    
    conn.close()
    return render_template(
        'home.html',
        categories=categories,
        bestsellers=bestsellers,
        flash_product=flash_product
    )

@app.route('/catalog')
@app.route('/shop')
def catalog():
    conn = get_db()
    cursor = conn.cursor()
    
    # Read query parameters
    category_slug = request.args.get('category', '').strip()
    search_q = request.args.get('q', '').strip()
    sort_by = request.args.get('sort', 'featured').strip()
    discount_min = request.args.get('discount', type=int)
    
    # Fetch all categories for sidebar
    cursor.execute('SELECT * FROM categories')
    categories = cursor.fetchall()
    
    # Build query
    query = 'SELECT * FROM products WHERE 1=1'
    params = []
    
    if category_slug:
        query += ' AND category = ?'
        params.append(category_slug)
        
    if search_q:
        query += ' AND (name LIKE ? OR lead_description LIKE ? OR material LIKE ?)'
        wildcard = f'%{search_q}%'
        params.extend([wildcard, wildcard, wildcard])
        
    if discount_min:
        query += ' AND discount_percent >= ?'
        params.append(discount_min)
        
    # Sorting
    if sort_by == 'price_low':
        query += ' ORDER BY retail_price ASC'
    elif sort_by == 'price_high':
        query += ' ORDER BY retail_price DESC'
    elif sort_by == 'bestseller':
        query += ' ORDER BY is_bestseller DESC, units_sold DESC'
    elif sort_by == 'rating':
        query += ' ORDER BY rating DESC'
    elif sort_by == 'newest':
        query += ' ORDER BY id DESC'
    else: # featured
        query += ' ORDER BY is_featured DESC, units_sold DESC'
        
    cursor.execute(query, params)
    products = cursor.fetchall()
    
    active_category_name = None
    if category_slug:
        for c in categories:
            if c['slug'] == category_slug:
                active_category_name = c['name']
                break
                
    conn.close()
    return render_template(
        'catalog.html',
        products=products,
        categories=categories,
        active_category=category_slug,
        active_category_name=active_category_name,
        search_query=search_q,
        sort_by=sort_by,
        discount_filter=discount_min
    )

@app.route('/product/<slug>')
def product_detail(slug):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM products WHERE slug = ?', (slug,))
    product = cursor.fetchone()
    if not product and slug.isdigit():
        cursor.execute('SELECT * FROM products WHERE id = ?', (int(slug),))
        product = cursor.fetchone()
    
    if not product:
        conn.close()
        return redirect(url_for('catalog'))
        
    # Parse json specs, variants, gallery
    specs = json.loads(product['specs']) if product['specs'] else {}
    variants = json.loads(product['variants']) if product['variants'] else []
    gallery = json.loads(product['gallery']) if product['gallery'] else [product['image_url']]
    
    # Reviews
    cursor.execute('SELECT * FROM reviews WHERE product_id = ? ORDER BY id DESC', (product['id'],))
    reviews = cursor.fetchall()
    
    conn.close()
    return render_template(
        'product_detail.html',
        product=product,
        specs=specs,
        variants=variants,
        gallery=gallery,
        reviews=reviews
    )

@app.route('/cart')
@app.route('/checkout')
@app.route('/cart/checkout')
def cart():
    # If cart is empty in session, seed a default starter item for Rajesh Kumar (matching the Figma/HTML design)
    if 'cart' not in session:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM products WHERE id IN (1, 11)')
        init_prods = cursor.fetchall()
        default_cart = []
        for p in init_prods:
            default_cart.append({
                'product_id': p['id'],
                'slug': p['slug'],
                'name': p['name'],
                'variant_name': '2.8 Litre (24cm)' if p['id'] == 1 else '5-Piece Set',
                'unit_price': p['retail_price'],
                'mrp': p['mrp'],
                'discount_percent': p['discount_percent'],
                'quantity': 1,
                'subtotal': p['retail_price'],
                'image_url': p['image_url']
            })
        session['cart'] = default_cart
        session['coupon'] = 'UTSAV15'
        conn.close()

    cart_items = session.get('cart', [])
    return render_template('cart_checkout.html', cart_items=cart_items)

@app.route('/orders')
def orders():
    conn = get_db()
    cursor = conn.cursor()
    
    status_filter = request.args.get('status', '').strip()
    query_search = request.args.get('q', '').strip()
    
    sql = 'SELECT * FROM orders WHERE 1=1'
    params = []
    
    if status_filter == 'active':
        sql += " AND order_status != 'Delivered'"
    elif status_filter == 'delivered':
        sql += " AND order_status = 'Delivered'"
        
    if query_search:
        sql += " AND (order_number LIKE ? OR customer_name LIKE ?)"
        wildcard = f'%{query_search}%'
        params.extend([wildcard, wildcard])
        
    sql += ' ORDER BY id DESC'
    cursor.execute(sql, params)
    orders_data = cursor.fetchall()
    
    full_orders = []
    for o in orders_data:
        cursor.execute('SELECT * FROM order_items WHERE order_id = ?', (o['id'],))
        items = cursor.fetchall()
        full_orders.append({
            **dict(o),
            'items': items
        })
        
    conn.close()
    return render_template(
        'orders.html',
        orders=full_orders,
        filter_status=status_filter
    )

@app.route('/orders/<order_number>')
def order_single(order_number):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM orders WHERE order_number = ?', (order_number,))
    order = cursor.fetchone()
    if not order:
        conn.close()
        return redirect(url_for('orders'))
        
    cursor.execute('SELECT * FROM order_items WHERE order_id = ?', (order['id'],))
    items = cursor.fetchall()
    full_order = {**dict(order), 'items': items}
    conn.close()
    
    order_upi_qr = generate_upi_payment_qr(
        vpa=DEFAULT_OWNER_VPA,
        business_name=DEFAULT_BUSINESS_NAME,
        order_id=order['order_number'],
        amount=order['total_amount']
    )
    return render_template('orders.html', orders=[full_order], filter_status=None, order_upi_qr=order_upi_qr)

@app.route('/invoice/<order_number>')
def invoice(order_number):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM orders WHERE order_number = ?', (order_number,))
    order = cursor.fetchone()
    if not order:
        conn.close()
        return "Invoice not found", 404
        
    cursor.execute('SELECT * FROM order_items WHERE order_id = ?', (order['id'],))
    items = cursor.fetchall()
    full_order = {**dict(order), 'items': items}
    conn.close()
    
    order_upi_qr = generate_upi_payment_qr(
        vpa=DEFAULT_OWNER_VPA,
        business_name=DEFAULT_BUSINESS_NAME,
        order_id=order['order_number'],
        amount=order['total_amount']
    )
    return render_template('invoice.html', order=full_order, order_upi_qr=order_upi_qr)

# ==================== ADMIN PORTAL ====================

@app.route('/admin_login', methods=['GET', 'POST'])
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    error_msg = None
    if request.method == 'POST':
        password = request.form.get('password')
        if password == 'Sehgal6897@':
            session['admin_logged_in'] = True
            session['admin_portal_locked'] = False
            return redirect(url_for('admin'))
        else:
            error_msg = "Incorrect master password. Please verify and try again."
            
    return render_template('admin_login.html', error_msg=error_msg)

@app.route('/api/admin/lock', methods=['POST'])
def api_admin_lock():
    session['admin_logged_in'] = False
    session['admin_portal_locked'] = True
    return jsonify({'success': True, 'locked': True})

@app.route('/api/admin/unlock', methods=['POST'])
def api_admin_unlock():
    data = request.get_json(silent=True) or request.form or {}
    password = data.get('password', '')
    if password == 'Sehgal6897@':
        session['admin_logged_in'] = True
        session['admin_portal_locked'] = False
        return jsonify({'success': True, 'unlocked': True})
    return jsonify({'success': False, 'error': 'Incorrect master password'}), 401

@app.route('/admin_logout')
@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_logged_in', None)
    session.pop('admin_portal_locked', None)
    return redirect(url_for('admin_login'))

@app.route('/admin')
def admin():
    if not session.get('admin_logged_in') or session.get('admin_portal_locked'):
        return redirect(url_for('admin_login'))
    conn = get_db()
    cursor = conn.cursor()
    
    # Financial KPI
    cursor.execute('SELECT SUM(total_amount) FROM orders')
    total_rev = cursor.fetchone()[0] or 0.0
    
    cursor.execute("SELECT COUNT(*) FROM orders WHERE order_status != 'Delivered'")
    active_count = cursor.fetchone()[0] or 0
    
    cursor.execute("SELECT COUNT(*) FROM products WHERE stock < 15")
    low_stock = cursor.fetchone()[0] or 0
    
    # Orders
    cursor.execute('SELECT * FROM orders ORDER BY id DESC')
    orders = cursor.fetchall()
    
    # Products
    cursor.execute('SELECT * FROM products ORDER BY id DESC')
    products = cursor.fetchall()
    
    # Inquiries
    cursor.execute('SELECT * FROM b2b_inquiries ORDER BY id DESC')
    inquiries = cursor.fetchall()
    
    # Categories
    cursor.execute('SELECT * FROM categories ORDER BY name ASC')
    categories = cursor.fetchall()
    
    conn.close()

    # Registered Customers & Statistics (Google Sheets / Excel Connected)
    registered_customers = customer_sheets.get_all_registered_customers()
    total_customers_count = len(registered_customers)
    sms_verified_count = sum(1 for c in registered_customers if 'SMS' in str(c.get('auth_provider', '')))

    return render_template(
        'admin.html',
        total_revenue=total_rev,
        active_orders_count=active_count,
        low_stock_count=low_stock,
        orders=orders,
        products=products,
        inquiries=inquiries,
        categories=categories,
        registered_customers=registered_customers,
        total_customers_count=total_customers_count,
        sms_verified_count=sms_verified_count
    )

# ==================== COMPANY PORTAL EXCLUSIVE CUSTOMER EXPORTS ====================

@app.route('/api/admin/customers/export.csv')
@app.route('/admin/customers/export.csv')
def admin_customers_export_csv():
    """Download customer directory as Google Sheets compatible CSV. Strictly restricted to Company Portal account."""
    if not session.get('admin_logged_in') or session.get('admin_portal_locked'):
        return redirect(url_for('admin_login'))
    csv_content = customer_sheets.generate_csv_export()
    date_tag = datetime.now().strftime('%Y%m%d')
    filename = f"Kalash_Registered_Customers_GoogleSheet_{date_tag}.csv"
    return Response(
        csv_content,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

@app.route('/api/admin/customers/export.xlsx')
@app.route('/admin/customers/export.xlsx')
def admin_customers_export_xlsx():
    """Download customer directory as Microsoft Excel workbook (.xlsx). Strictly restricted to Company Portal account."""
    if not session.get('admin_logged_in') or session.get('admin_portal_locked'):
        return redirect(url_for('admin_login'))
    xlsx_bytes = customer_sheets.generate_excel_export_bytes()
    date_tag = datetime.now().strftime('%Y%m%d')
    filename = f"Kalash_Registered_Customers_Excel_{date_tag}.xlsx"
    return Response(
        xlsx_bytes,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

# ==================== REST APIS ====================

@app.route('/api/cart/add', methods=['POST'])
def api_cart_add():
    data = request.get_json() or {}
    product_id = data.get('product_id')
    variant_name = data.get('variant_name')
    quantity = int(data.get('quantity', 1))
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM products WHERE id = ?', (product_id,))
    product = cursor.fetchone()
    conn.close()
    
    if not product:
        return jsonify({'success': False, 'error': 'Product not found'}), 404
        
    cart = session.get('cart', [])
    
    # Calculate price based on variant if available
    price = product['retail_price']
    mrp = product['mrp']
    if variant_name and product['variants']:
        try:
            var_list = json.loads(product['variants'])
            for v in var_list:
                if v['size'] == variant_name:
                    price = float(v['price'])
                    mrp = float(v['mrp'])
                    break
        except Exception:
            pass

    found = False
    for item in cart:
        if item['product_id'] == product['id'] and item.get('variant_name') == variant_name:
            item['quantity'] += quantity
            item['subtotal'] = item['unit_price'] * item['quantity']
            found = True
            break
            
    if not found:
        cart.append({
            'product_id': product['id'],
            'slug': product['slug'],
            'name': product['name'],
            'variant_name': variant_name or 'Standard',
            'unit_price': price,
            'mrp': mrp,
            'discount_percent': product['discount_percent'],
            'quantity': quantity,
            'subtotal': price * quantity,
            'image_url': product['image_url']
        })
        
    session['cart'] = cart
    summary = get_cart_summary()
    return jsonify({
        'success': True,
        'message': f"Added {product['name']} to shopping bag!",
        'cart_count': summary['count'],
        'cart_total': summary['subtotal']
    })

@app.route('/api/cart/update', methods=['POST'])
def api_cart_update():
    data = request.get_json() or {}
    product_id = data.get('product_id')
    variant_name = data.get('variant_name')
    quantity = int(data.get('quantity', 1))
    
    cart = session.get('cart', [])
    if quantity <= 0:
        cart = [item for item in cart if not (item['product_id'] == product_id and item.get('variant_name') == variant_name)]
    else:
        for item in cart:
            if item['product_id'] == product_id and item.get('variant_name') == variant_name:
                item['quantity'] = quantity
                item['subtotal'] = item['unit_price'] * quantity
                break
                
    session['cart'] = cart
    return jsonify({'success': True, 'cart': cart})

@app.route('/api/cart/remove', methods=['POST'])
def api_cart_remove():
    data = request.get_json() or {}
    product_id = data.get('product_id')
    variant_name = data.get('variant_name')
    
    cart = session.get('cart', [])
    cart = [item for item in cart if not (item['product_id'] == product_id and item.get('variant_name') == variant_name)]
    session['cart'] = cart
    return jsonify({'success': True})

@app.route('/api/cart/coupon', methods=['POST'])
def api_cart_coupon():
    data = request.get_json() or {}
    code = (data.get('coupon_code') or '').strip().upper()
    
    valid_coupons = {
        'UTSAV15': '15% Festive Discount Applied!',
        'KALASH250': '₹250 Welcome Voucher Applied!',
        'BULK10': '10% Commercial Partner Discount Applied!'
    }
    
    if code in valid_coupons:
        session['coupon'] = code
        return jsonify({'success': True, 'message': valid_coupons[code]})
    else:
        return jsonify({'success': False, 'error': 'Invalid voucher code. Try UTSAV15'}), 400

@app.route('/login')
def login():
    redirect_target = request.args.get('next', '/')
    return render_template('login.html', next=redirect_target)

# ==================== SMS GATEWAY OTP AUTHENTICATION ====================

@app.route('/api/auth/sms/send_otp', methods=['POST'])
def api_auth_sms_send_otp():
    """
    Connects to SMS Gateway to generate and dispatch dynamic OTP code.
    Generates different codes for different phone numbers and logs transaction.
    """
    data = request.get_json(silent=True) or request.form or {}
    phone = data.get('phone', '').strip()
    purpose = data.get('purpose', 'login')
    name = data.get('name', '').strip()

    if not phone:
        return jsonify({'success': False, 'error': 'Please provide a 10-digit mobile number.'}), 400

    result = sms_gateway.send_sms_otp(phone, purpose=purpose, customer_name=name)
    if not result.get('success'):
        return jsonify(result), 400
    return jsonify(result)

@app.route('/api/auth/sms/verify_otp', methods=['POST'])
def api_auth_sms_verify_otp():
    """
    Checks the entered OTP against the SMS Gateway record.
    Only allows login/signup if code matches the exact OTP sent by SMS Gateway.
    Records customer details [Name, Number, Email] by date in Google Sheet / Excel.
    """
    data = request.get_json(silent=True) or request.form or {}
    phone = data.get('phone', '').strip()
    otp_code = data.get('otp', '').strip()
    name = data.get('name', '').strip()
    email = data.get('email', '').strip()
    purpose = data.get('purpose', 'login')

    is_valid, error_msg = sms_gateway.verify_sms_otp(phone, otp_code)
    if not is_valid:
        return jsonify({'success': False, 'error': error_msg}), 400

    clean_phone = sms_gateway.normalize_phone(phone)

    # If name/email not provided, check if customer already exists in registry
    if not name or not email:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT name, email FROM registered_customers WHERE phone = ? LIMIT 1", (clean_phone,))
        existing = cur.fetchone()
        conn.close()
        if existing:
            if not name:
                name = existing['name']
            if not email:
                email = existing['email']
        else:
            if not name:
                name = f"Customer {clean_phone[-4:]}"
            if not email:
                email = f"customer.{clean_phone[-4:]}@kalashcorp.in"

    # Record in database and auto-sync to Google Sheet & Excel
    customer = customer_sheets.record_registered_customer(
        name=name,
        phone=clean_phone,
        email=email,
        auth_provider="SMS Gateway Verified"
    )

    session['user_logged_in'] = True
    session['user_name'] = customer['name']
    session['user_phone'] = customer['phone']
    session['user_email'] = customer['email']
    session['user_avatar'] = f"https://api.dicebear.com/7.x/initials/svg?seed={urllib.parse.quote(name)}&backgroundColor=7b4e00"
    session['auth_method'] = 'sms_gateway_otp'

    redirect_url = data.get('redirect_url') or url_for('home')
    return jsonify({
        'success': True,
        'message': 'SMS Gateway OTP verified successfully.',
        'user': customer,
        'redirect_url': redirect_url
    })

@app.route('/api/auth/google/simulate', methods=['POST'])
def api_auth_google_simulate():
    data = request.get_json(silent=True) or request.form or {}
    email = (data.get('email') or '').strip().lower()
    name = (data.get('name') or '').strip()
    avatar = (data.get('avatar') or '').strip()
    phone = data.get('phone', '8107183725').strip()
    
    if not email:
        return jsonify({'success': False, 'error': 'Google email is required'}), 400
        
    if '@' not in email:
        email = f"{email}@gmail.com"
        
    if not name:
        handle = email.split('@')[0]
        cleaned_handle = handle.replace('.', ' ').replace('_', ' ').replace('-', ' ')
        name = cleaned_handle.title()
        
    if not avatar:
        avatar = f"https://api.dicebear.com/7.x/initials/svg?seed={urllib.parse.quote(name)}&backgroundColor=7b4e00,996515,ab3600"
        
    # Record customer in Google Sheet / Excel registry
    customer = customer_sheets.record_registered_customer(
        name=name,
        phone=phone,
        email=email,
        auth_provider="Google Account Verified"
    )

    session['user_logged_in'] = True
    session['user_name'] = name
    session['user_email'] = email
    session['user_phone'] = customer['phone']
    session['user_avatar'] = avatar
    session['auth_method'] = 'google'
    
    redirect_url = data.get('redirect_url') or url_for('home')
    return jsonify({
        'success': True,
        'user': {
            'name': name,
            'email': email,
            'phone': customer['phone'],
            'avatar': avatar,
            'provider': 'Google'
        },
        'redirect_url': redirect_url
    })

@app.route('/login/google', methods=['GET', 'POST'])
def login_google():
    email = request.args.get('email') or request.form.get('email') or 'customer@gmail.com'
    name = request.args.get('name') or request.form.get('name') or email.split('@')[0].replace('.', ' ').title()
    avatar = request.args.get('avatar') or request.form.get('avatar') or f"https://api.dicebear.com/7.x/initials/svg?seed={urllib.parse.quote(name)}&backgroundColor=7b4e00"
    phone = request.args.get('phone') or request.form.get('phone') or '8107183725'

    customer = customer_sheets.record_registered_customer(
        name=name,
        phone=phone,
        email=email,
        auth_provider="Google Account Verified"
    )

    session['user_logged_in'] = True
    session['user_name'] = name
    session['user_email'] = email
    session['user_phone'] = customer['phone']
    session['user_avatar'] = avatar
    session['auth_method'] = 'google'
    return redirect(url_for('home'))

@app.route('/login_submit', methods=['POST'])
def login_submit():
    # Direct Form POST handler with SMS Gateway check
    otp = request.form.get('otp', '').strip()
    phone = request.form.get('phone', '').strip()
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip()

    is_valid, error_msg = sms_gateway.verify_sms_otp(phone, otp)
    if not is_valid:
        return render_template('login.html', error_msg=error_msg, input_phone=phone)

    clean_phone = sms_gateway.normalize_phone(phone)
    if not name:
        name = f'Customer {clean_phone[-4:]}'
    if not email:
        email = f'customer.{clean_phone[-4:]}@kalashcorp.in'

    customer = customer_sheets.record_registered_customer(
        name=name,
        phone=clean_phone,
        email=email,
        auth_provider="SMS Gateway Verified"
    )

    session['user_logged_in'] = True
    session['user_name'] = customer['name']
    session['user_email'] = customer['email']
    session['user_phone'] = customer['phone']
    session['user_avatar'] = f"https://api.dicebear.com/7.x/initials/svg?seed={urllib.parse.quote(name)}&backgroundColor=7b4e00"
    session['auth_method'] = 'sms_gateway_otp'
    return redirect(url_for('home'))

@app.route('/logout')
def logout():
    session.pop('user_logged_in', None)
    session.pop('user_name', None)
    session.pop('user_email', None)
    session.pop('user_phone', None)
    session.pop('user_avatar', None)
    session.pop('auth_method', None)
    return redirect(url_for('home'))

# ==================== WHATSAPP ORDER ALGORITHM ====================

def generate_whatsapp_order_data(cart, summary, customer_details, order_number, base_url):
    """
    Constructs the formatted WhatsApp message and wa.me URL for owner account +918107183725.
    Algorithm requirements:
    1. WhatsApp destination: +918107183725
    2. Clickable link of each product the customer is ordering
    3. Amount of each product and total payable amount
    4. Explicit directive: Payment must be done through the owner's WhatsApp payment only
    """
    owner_phone = "918107183725"
    
    conn = get_db()
    cursor = conn.cursor()
    
    name = customer_details.get('customer_name', 'Rajesh Kumar').strip()
    phone = customer_details.get('phone', '+91 98200 54321').strip()
    email = customer_details.get('email', 'rajesh.k@gmail.com').strip()
    address = customer_details.get('address', 'Kota Merchant Quarter').strip()
    city = customer_details.get('city', 'Kota').strip()
    state = customer_details.get('state', 'Rajasthan').strip()
    pincode = customer_details.get('pincode', '324001').strip()
    gstin = customer_details.get('gstin', '').strip()
    business_name = customer_details.get('business_name', '').strip()
    
    lines = [
        "🛍️ *NEW ORDER - KALASH ENTERPRISES*",
        "Estd. 2011 | Kota, Rajasthan",
        f"Order Ref: *#{order_number}*",
        f"Date: {datetime.now().strftime('%d %b %Y, %I:%M %p')}",
        "────────────────────────",
        "👤 *CUSTOMER & DELIVERY DETAILS:*",
        f"• Name: {name}",
        f"• Mobile: {phone}",
        f"• Email: {email}",
        f"• Address: {address}, {city}, {state} - {pincode}",
    ]
    if gstin:
        lines.append(f"• Business: {business_name} (GSTIN: {gstin})")

    lines.extend([
        "────────────────────────",
        "📦 *ORDERED PRODUCT(S) & AMOUNTS:*"
    ])

    for idx, item in enumerate(cart, 1):
        slug = item.get('slug')
        if not slug:
            cursor.execute('SELECT slug FROM products WHERE id = ?', (item['product_id'],))
            row = cursor.fetchone()
            slug = row['slug'] if row else str(item['product_id'])
            
        prod_link = f"{base_url}/product/{slug}"
        var_text = f" ({item.get('variant_name')})" if item.get('variant_name') and item.get('variant_name') != 'Standard' else ""
        qty = item['quantity']
        price = item['unit_price']
        subtotal = item['subtotal']
        
        lines.append(
            f"{idx}. *{item['name']}*{var_text}\n"
            f"   • Qty: {qty} × ₹{price:,.0f} = ₹{subtotal:,.0f}\n"
            f"   🔗 *Product Link:* {prod_link}"
        )
        
    conn.close()

    lines.extend([
        "────────────────────────",
        "💰 *PAYMENT SUMMARY:*",
        f"• Items Total: ₹{summary['subtotal']:,.0f}",
    ])
    if summary.get('discount', 0) > 0:
        lines.append(f"• Festival Discount ({summary.get('coupon_code', 'Offer')}): -₹{summary['discount']:,.0f}")
        
    shipping_val = summary.get('shipping', 0)
    shipping_str = 'FREE' if shipping_val == 0 else f"₹{shipping_val:,.0f}"

    # Generate Dynamic UPI QR Code for this order total
    upi_qr = generate_upi_payment_qr(
        vpa=DEFAULT_OWNER_VPA,
        business_name=DEFAULT_BUSINESS_NAME,
        order_id=order_number,
        amount=summary['total']
    )

    lines.extend([
        f"• Pan-India Delivery: {shipping_str}",
        f"• GST (18% inclusive): ₹{summary['tax']:,.0f}",
        f"• *TOTAL AMOUNT PAYABLE: ₹{summary['total']:,.0f}*",
        "────────────────────────",
        "💳 *PAYMENT INSTRUCTIONS:*",
        "⚡ *THE PAYMENT MUST BE DONE THROUGH THE OWNER'S WHATSAPP PAYMENT ONLY (+91 8107183725)*.",
        f"• Payee VPA / UPI ID: *{DEFAULT_OWNER_VPA}*",
        f"• Instant UPI Pay App Link: {upi_qr['upi_uri']}",
        f"Please send your WhatsApp Payment request / UPI prompt for *₹{summary['total']:,.0f}* to this chat so I can complete payment and confirm this order."
    ])

    message_text = "\n".join(lines)
    encoded_text = urllib.parse.quote(message_text)
    whatsapp_url = f"https://wa.me/{owner_phone}?text={encoded_text}"
    
    return {
        'order_number': order_number,
        'message_text': message_text,
        'whatsapp_url': whatsapp_url,
        'owner_number': '+91 8107183725',
        'raw_number': owner_phone,
        'upi_uri': upi_qr['upi_uri'],
        'qr_image_data': upi_qr['base64_image'],
        'vpa': DEFAULT_OWNER_VPA
    }

def process_and_save_order(form_dict, custom_payment_method="Owner's WhatsApp Payment (+91 8107183725)"):
    cart = session.get('cart', [])
    if not cart:
        return None, None, None
        
    summary = get_cart_summary()
    
    customer_name = form_dict.get('customer_name', 'Rajesh Kumar')
    phone = form_dict.get('phone', '+91 98200 54321')
    email = form_dict.get('email', 'rajesh.k@gmail.com')
    address = form_dict.get('address', 'Kota Merchant Quarter')
    city = form_dict.get('city', 'Kota')
    state = form_dict.get('state', 'Rajasthan')
    pincode = form_dict.get('pincode', '324001')
    gstin = form_dict.get('gstin', '')
    business_name = form_dict.get('business_name', '')
    
    date_str = datetime.now().strftime('%Y%m%d')
    random_suffix = random.randint(1000, 9999)
    order_number = f"KALASH-ORD-{date_str}-{random_suffix}"
    tracking_awb = f"BLUEDT{random.randint(100000000, 999999999)}"
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
    INSERT INTO orders (
        order_number, customer_name, email, phone, address, city, state, pincode,
        gstin, business_name, payment_method, payment_status, payment_id,
        subtotal, discount, shipping_fee, tax_amount, total_amount,
        order_status, tracking_partner, tracking_awb, expected_delivery
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        order_number, customer_name, email, phone, address, city, state, pincode,
        gstin, business_name, custom_payment_method, 'Pending Owner WhatsApp Payment',
        f"wapay_{random.randint(1000000, 9999999)}",
        summary['subtotal'], summary['discount'], summary['shipping'], summary['tax'], summary['total'],
        'Order Placed (WhatsApp Payment Pending)', 'BlueDart Express Air', tracking_awb, 'Expected in 2 business days'
    ))
    order_id = cursor.lastrowid
    
    for item in cart:
        cursor.execute('''
        INSERT INTO order_items (
            order_id, product_id, product_name, variant_name, unit_price, quantity, subtotal, image_url
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            order_id, item['product_id'], item['name'], item.get('variant_name', 'Standard'),
            item['unit_price'], item['quantity'], item['subtotal'], item['image_url']
        ))
        cursor.execute('UPDATE products SET stock = MAX(0, stock - ?), units_sold = units_sold + ? WHERE id = ?',
                       (item['quantity'], item['quantity'], item['product_id']))
                       
    conn.commit()
    conn.close()
    
    # Generate WhatsApp URL and QR
    base_url = request.host_url.rstrip('/')
    wa_data = generate_whatsapp_order_data(cart, summary, form_dict, order_number, base_url)
    
    # Clear cart
    session['cart'] = []
    session.pop('coupon', None)
    
    return order_number, wa_data, summary

@app.route('/checkout_whatsapp', methods=['POST'])
def checkout_whatsapp():
    """Direct form action for Place Order & Complete Checkout button that locates immediately to WhatsApp."""
    order_number, wa_data, _ = process_and_save_order(request.form)
    if not wa_data:
        return redirect(url_for('cart'))
    return redirect(wa_data['whatsapp_url'])

@app.route('/api/orders/whatsapp_checkout', methods=['POST'])
@app.route('/api/checkout/place_order', methods=['POST'])
def api_orders_whatsapp_checkout():
    """Async endpoint for Place Order button allowing immediate location to WhatsApp chat."""
    order_number, wa_data, summary = process_and_save_order(request.form)
    if not wa_data:
        return jsonify({'success': False, 'error': 'Cart is empty'}), 400
    return jsonify({
        'success': True,
        'order_number': order_number,
        'whatsapp_url': wa_data['whatsapp_url'],
        'message_text': wa_data['message_text'],
        'owner_number': wa_data['owner_number'],
        'qr_image_data': wa_data.get('qr_image_data'),
        'upi_intent_url': wa_data.get('upi_uri'),
        'vpa': wa_data.get('vpa')
    })

@app.route('/confirm_order', methods=['POST'])
def confirm_order():
    """Confirms order from the Company Payment Gateway, saves order and redirects to invoice."""
    order_number, wa_data, _ = process_and_save_order(request.form)
    if not order_number:
        return redirect(url_for('cart'))
    return redirect(url_for('invoice', order_number=order_number))

@app.route('/payment_gateway', methods=['GET', 'POST'])
def payment_gateway():
    cart = session.get('cart', [])
    summary = get_cart_summary()
    if request.method == 'POST':
        form_data = request.form.to_dict()
        session['checkout_form'] = form_data
    else:
        form_data = session.get('checkout_form', {})
    base_url = request.host_url.rstrip('/')
    wa_preview = generate_whatsapp_order_data(cart, summary, form_data, "PENDING-CHECKOUT", base_url) if cart else None
    return render_template('payment_gateway.html', form_data=form_data, cart_summary=summary, wa_preview=wa_preview)

@app.route('/api/checkout/upi', methods=['POST', 'GET'])
def api_checkout_upi():
    """
    Dynamic UPI Payment QR Code Generator endpoint (Option 1).
    Returns locked UPI URI and Base64 image data URI.
    """
    data = {}
    if request.is_json:
        data = request.get_json() or {}
    elif request.form:
        data = request.form.to_dict()
    elif request.args:
        data = request.args.to_dict()
        
    summary = get_cart_summary()
    order_id = data.get('order_id') or f"ORD_{random.randint(1000, 9999)}"
    try:
        amount = float(data.get('amount') or summary['total'])
    except (ValueError, TypeError):
        amount = float(summary['total'])
        
    vpa = data.get('vpa') or DEFAULT_OWNER_VPA
    business_name = data.get('business_name') or DEFAULT_BUSINESS_NAME
    
    qr_data = generate_upi_payment_qr(
        vpa=vpa,
        business_name=business_name,
        order_id=order_id,
        amount=amount,
    )
    return jsonify({
        "status": "success",
        "order_id": order_id,
        "amount": amount,
        "vpa": vpa,
        "business_name": business_name,
        "qr_image_data": qr_data["base64_image"],
        "upi_intent_url": qr_data["upi_uri"],
    })

@app.route('/api/whatsapp/send_order_details', methods=['POST'])
def api_whatsapp_send_order_details():
    """
    WhatsApp Cloud API Interactive Payment Flow endpoint (Option 2).
    Dispatches native review_and_pay order interactive card via Meta Graph API.
    """
    data = request.get_json() or {}
    access_token = data.get('access_token') or os.environ.get('META_ACCESS_TOKEN', '')
    phone_number_id = data.get('phone_number_id') or os.environ.get('META_PHONE_NUMBER_ID', '')
    customer_phone = data.get('customer_phone', '')
    order_id = data.get('order_id', '')
    total_amount = float(data.get('total_amount', 0.0))
    cart_items = data.get('cart_items', [])
    
    result = send_whatsapp_order_details(
        access_token=access_token,
        phone_number_id=phone_number_id,
        customer_phone=customer_phone,
        order_id=order_id,
        total_amount=total_amount,
        cart_items=cart_items
    )
    return jsonify(result)

@app.route('/api/orders/place', methods=['POST'])
def api_orders_place():
    order_number, wa_data, _ = process_and_save_order(request.form)
    if not wa_data:
        return redirect(url_for('cart'))
    
    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.args.get('format') == 'json':
        return jsonify({
            'success': True,
            'order_number': order_number,
            'whatsapp_url': wa_data['whatsapp_url'],
            'qr_image_data': wa_data.get('qr_image_data'),
            'upi_intent_url': wa_data.get('upi_uri')
        })
    # Locate directly to WhatsApp chat
    return redirect(wa_data['whatsapp_url'])

@app.route('/api/inquiry/b2b', methods=['POST'])
@app.route('/api/b2b/inquiry', methods=['POST'])
def api_inquiry_b2b():
    data = request.get_json(silent=True) or request.form or {}
    business_name = (data.get('business_name') or '').strip()
    contact_phone = (data.get('contact_phone') or '').strip()
    email = (data.get('email') or '').strip()
    requirement = data.get('requirement') or data.get('product_requirement') or 'Commercial Kitchenware'
    try:
        estimated_val = float(data.get('estimated_value', 65000.0))
    except (ValueError, TypeError):
        estimated_val = 65000.0
    
    if not business_name or not contact_phone:
        return jsonify({'success': False, 'error': 'Business Name and Phone are required'}), 400
        
    discount_tier = "5% Standard Tier"
    discount_pct = 0.05
    if estimated_val >= 150000:
        discount_tier = "20% Wholesale Partner"
        discount_pct = 0.20
    elif estimated_val >= 50000:
        discount_tier = "12% Commercial Tier"
        discount_pct = 0.12
        
    net_price = round(estimated_val * (1 - discount_pct), 2)
    inquiry_no = f"B2B-{datetime.now().strftime('%y%m%d')}-{random.randint(100, 999)}"
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO b2b_inquiries (
        inquiry_number, business_name, contact_phone, email, product_requirement,
        estimated_value, discount_tier, net_billing_price, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        inquiry_no, business_name, contact_phone, email, requirement,
        estimated_val, discount_tier, net_price, 'In Review'
    ))
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'inquiry_number': inquiry_no,
        'net_price': net_price,
        'discount_tier': discount_tier
    })

@app.route('/api/newsletter', methods=['POST'])
def api_newsletter():
    data = request.get_json() or {}
    email = data.get('email', '').strip()
    if not email:
        return jsonify({'success': False, 'error': 'Email is required'}), 400
        
    conn = get_db()
    cursor = conn.cursor()
    try:
        cursor.execute('INSERT INTO newsletter_subscribers (email, coupon_issued) VALUES (?, ?)', (email, 'UTSAV15'))
        conn.commit()
    except database.IntegrityError:
        pass
    conn.close()
    
    return jsonify({
        'success': True,
        'message': 'Welcome to Kalash Culinary Circle!',
        'coupon': 'UTSAV15'
    })

@app.route('/api/reviews/add', methods=['POST'])
def api_reviews_add():
    product_id = request.form.get('product_id')
    author = request.form.get('author_name', 'Verified Buyer')
    location = request.form.get('location', 'India')
    rating = int(request.form.get('rating', 5))
    comment = request.form.get('comment', '').strip()
    
    if product_id and comment:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
        INSERT INTO reviews (product_id, author_name, location, rating, comment)
        VALUES (?, ?, ?, ?, ?)
        ''', (product_id, author, location, rating, comment))
        
        # Update product review count
        cursor.execute('''
        UPDATE products 
        SET review_count = review_count + 1 
        WHERE id = ?
        ''', (product_id,))
        
        conn.commit()
        
        cursor.execute('SELECT slug FROM products WHERE id = ?', (product_id,))
        prod = cursor.fetchone()
        conn.close()
        
        if prod:
            return redirect(f"/product/{prod['slug']}#reviewsSection")
            
    return redirect(url_for('home'))

@app.route('/api/products/<int:prod_id>')
def api_product_get(prod_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM products WHERE id = ?', (prod_id,))
    p = cursor.fetchone()
    conn.close()
    if not p:
        return jsonify(None), 404
    return jsonify(dict(p))

@app.route('/api/admin/orders/status', methods=['POST'])
def api_admin_order_status():
    order_id = request.form.get('order_id')
    status = request.form.get('status')
    if order_id and status:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('UPDATE orders SET order_status = ? WHERE id = ?', (status, order_id))
        conn.commit()
        conn.close()
    return redirect(url_for('admin') + '#orders')

@app.route('/api/admin/products/stock', methods=['POST'])
def api_admin_product_stock():
    prod_id = request.form.get('product_id')
    stock = int(request.form.get('stock', 0))
    if prod_id:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('UPDATE products SET stock = ? WHERE id = ?', (stock, prod_id))
        conn.commit()
        conn.close()
    return redirect(url_for('admin') + '#products')

@app.route('/api/admin/products/delete', methods=['POST'])
def api_admin_product_delete():
    if not session.get('admin_logged_in'): return redirect(url_for('admin_login'))
    prod_id = request.form.get('product_id')
    if prod_id:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM products WHERE id = ?', (prod_id,))
        conn.commit()
        conn.close()
    return redirect(url_for('admin') + '#products')

import os
from werkzeug.utils import secure_filename

@app.route('/api/admin/products/add', methods=['POST'])
def api_admin_product_add():
    if not session.get('admin_logged_in'): return redirect(url_for('admin_login'))
    name = request.form.get('name', '').strip()
    category = request.form.get('category', 'cookware-and-kadhai')
    material_badge = request.form.get('material_badge', 'SS 304').strip()
    price = float(request.form.get('price', 999))
    mrp = float(request.form.get('mrp', 1499))
    stock = int(request.form.get('stock', 20))
    lead_description = request.form.get('lead_description', 'Authentic heavy gauge Indian kitchenware.').strip()
    
    image_url = 'https://lh3.googleusercontent.com/aida-public/AB6AXuAq2MJPADRLzZkHKnw41o8owuctNUFj3B2_pUXGv3Lb7HT8cu6L_mPpoFYxlAAnCjOEOfBWs-SP_1KhkHN8f_sYntWxvfzZUh2vdGz9HOvZcKCryz4ryGq7e0ThKn_EbD3rGL2Qs38LXVs3tDy_RnI9EU5iznrZNfZ6nf3QJIkvOqCKzAREQJRuCghnRPz70i18ZxDmMe3whZ6h0FI-Hvpec_PEQtnlw5WIliAYaGI'
    
    file = request.files.get('image')
    if file and file.filename != '':
        filename = secure_filename(file.filename)
        upload_folder = os.path.join(app.root_path, 'static', 'uploads')
        os.makedirs(upload_folder, exist_ok=True)
        file_path = os.path.join(upload_folder, filename)
        file.save(file_path)
        image_url = f'/static/uploads/{filename}'
        
    slug = name.lower().replace(' ', '-').replace('&', 'and') + f"-{random.randint(100, 999)}"
    discount_pct = int(round((mrp - price) / mrp * 100)) if mrp > price else 0
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT name FROM categories WHERE slug = ?', (category,))
    cat_row = cursor.fetchone()
    category_name = cat_row['name'] if cat_row else category.replace('-', ' ').upper()

    cursor.execute('''
    INSERT INTO products (
        slug, name, category, category_name, material, material_badge,
        retail_price, mrp, discount_percent, stock, rating, review_count,
        units_sold, is_featured, is_bestseller, is_flash_deal,
        lead_description, detailed_description, specs, variants,
        image_url, gallery, heat_sources, warranty
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )
    ''', (
        slug, name, category, category_name, material_badge, material_badge,
        price, mrp, discount_pct, stock, 4.9, 0, 0, 0, 0, 0,
        lead_description, lead_description, json.dumps({"Material": material_badge}),
        json.dumps([{"size": "Standard Size", "price": price, "mrp": mrp, "save": int(mrp - price)}]),
        image_url, json.dumps([image_url]), 'Induction & Gas', '5-Year Quality Warranty'
    ))
    conn.commit()
    conn.close()
    
    return redirect(url_for('admin') + '#products')

@app.route('/api/admin/categories/add', methods=['POST'])
def api_admin_category_add():
    if not session.get('admin_logged_in'): return redirect(url_for('admin_login'))
    name = request.form.get('name', '').strip()
    slug = request.form.get('slug', '').strip()
    if name and slug:
        conn = get_db()
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO categories (slug, name, description, product_count, image_url) VALUES (?, ?, ?, ?, ?)',
                           (slug, name, f"{name} collection", 0, ""))
            conn.commit()
        except database.IntegrityError:
            pass # already exists
        conn.close()
    return redirect(url_for('admin') + '#products')

@app.route('/api/admin/b2b/export')
def api_admin_b2b_export():
    if not session.get('admin_logged_in'): return redirect(url_for('admin_login'))
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM b2b_inquiries ORDER BY id DESC')
    inquiries = cursor.fetchall()
    conn.close()
    
    import io
    import csv
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'Inquiry Number', 'Business Name', 'Phone', 'Requirement', 'Estimated Value', 'Status', 'Date'])
    for inq in inquiries:
        writer.writerow([inq['id'], inq['inquiry_number'], inq['business_name'], inq['contact_phone'], inq['product_requirement'], inq['estimated_value'], inq['status'], inq['created_at']])
        
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment;filename=b2b_inquiries.csv"})

if __name__ == '__main__':
    print("Starting Kalash Enterprises Website Server on http://127.0.0.1:5000 ...")
    app.run(host='0.0.0.0', port=5000, debug=True)
