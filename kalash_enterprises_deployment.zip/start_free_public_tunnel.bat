@echo off
title Kalash Enterprises - Free Instant Cloudflare Public Tunnel
echo =========================================================================
echo KALASH ENTERPRISES - FREE INSTANT PUBLIC ACCESS & SSL
echo Estd. 2011, Shop Number 3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan
echo =========================================================================
echo.
echo Starting secure encrypted Cloudflare tunnel to your local server...
echo (Allows immediate worldwide access with 100%% Free SSL)
echo.

cloudflared.exe tunnel --url http://127.0.0.1:5000
pause
