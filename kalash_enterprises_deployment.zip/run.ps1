Write-Host "Starting Kalash Enterprises Kitchenware Store Server..." -ForegroundColor Cyan
& "C:\Users\Dr Miit Sehgal\AppData\Local\Programs\Python\Python312\python.exe" app.py
