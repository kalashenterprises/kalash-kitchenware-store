"""
Kalash Enterprises - Production WSGI Application Entrypoint
Configured for www.kalashenterprises.co.in
Handles reverse proxy headers, HTTPS detection, and domain forwarding.
Estd. 2011, Shop Number 3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan, India, Pincode: 324001
"""

import os
from werkzeug.middleware.proxy_fix import ProxyFix
from app import app

# Apply ProxyFix middleware so Flask correctly detects HTTPS scheme,
# client IP, and domain name (www.kalashenterprises.co.in) behind Nginx/Cloudflare/AWS/Render
app.wsgi_app = ProxyFix(
    app.wsgi_app,
    x_for=1,
    x_proto=1,
    x_host=1,
    x_port=1,
    x_prefix=1
)

# Production domain and scheme configuration
app.config['PREFERRED_URL_SCHEME'] = os.environ.get('PREFERRED_URL_SCHEME', 'https')
app.config['SERVER_NAME'] = os.environ.get('SERVER_NAME', None)  # Optional strict domain binding

# For direct execution
if __name__ == "__main__":
    from waitress import serve
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '0.0.0.0')
    print(f"Starting Kalash Enterprises Production WSGI Server on http://{host}:{port}")
    print(f"Domain: www.kalashenterprises.co.in")
    serve(app, host=host, port=port, threads=8)
