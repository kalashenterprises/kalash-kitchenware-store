"""
Kalash Enterprises - Account-Connected Persistent Cart & 24-Hour Expiration Manager
Estd. 2011, Kota, Rajasthan, India

Responsibilities:
1. Associates each shopping cart with the customer's logged-in account (email or phone).
2. Guarantees cart isolation: each account has its own independent saved items.
3. Automatically empties the cart if the customer does not complete payment within 24 hours.
4. Seamlessly merges guest cart items into the account upon login.
5. Clears the cart permanently upon order placement and payment completion.
"""

import os
import json
import uuid
from datetime import datetime, timedelta
import database

# 24 hours expiration threshold in seconds (24 * 60 * 60 = 86,400 seconds)
CART_EXPIRATION_SECONDS = 24 * 3600

def ensure_cart_table():
    """Initializes user_carts table in MySQL and SQLite."""
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        
        # Check connection type
        is_mysql = isinstance(conn, database.MySQLConnectionWrapper)
        
        if is_mysql:
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_carts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_key VARCHAR(255) NOT NULL UNIQUE,
                cart_data LONGTEXT NOT NULL,
                coupon_code VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_user_key (user_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)
        else:
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_carts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_key TEXT NOT NULL UNIQUE,
                cart_data TEXT NOT NULL,
                coupon_code TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
        conn.commit()
        conn.close()
    except Exception as ex:
        print(f"[CART_MANAGER DB INIT WARNING] {ex}")

def get_session_user_key(session_obj) -> str:
    """Returns the unique user identifier key for the current session."""
    if session_obj.get('user_logged_in'):
        ident = session_obj.get('user_email') or session_obj.get('user_phone') or session_obj.get('user_name')
        if ident:
            return f"user:{str(ident).strip().lower()}"
            
    # For guest sessions, maintain a persistent unique guest identifier
    if 'guest_id' not in session_obj or not session_obj.get('guest_id'):
        session_obj['guest_id'] = f"guest_{uuid.uuid4().hex[:12]}"
        
    return f"guest:{session_obj['guest_id']}"

def parse_db_timestamp(ts_val) -> datetime:
    """Safely converts string or datetime DB timestamp to datetime object."""
    if isinstance(ts_val, datetime):
        return ts_val
    if not ts_val:
        return datetime.now()
    try:
        clean_str = str(ts_val).strip()
        # Handle ISO formats and standard MySQL/SQLite formats
        if 'T' in clean_str:
            clean_str = clean_str.replace('T', ' ')
        clean_str = clean_str[:19]
        return datetime.strptime(clean_str, '%Y-%m-%d %H:%M:%S')
    except Exception:
        return datetime.now()

def get_user_cart(session_obj, user_key: str = None) -> tuple[list, str | None, bool]:
    """
    Loads cart items and coupon for the current user or guest.
    Enforces 24-hour expiration policy:
    If last activity was > 24 hours ago and order was not completed, cart is automatically emptied.
    Returns (cart_items, coupon_code, was_expired_boolean).
    """
    ensure_cart_table()
    if not user_key:
        user_key = get_session_user_key(session_obj)
        
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM user_carts WHERE user_key = ?", (user_key,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            # If no DB entry exists, fallback to session cart (also check session timestamp)
            session_cart = session_obj.get('cart', [])
            session_time_str = session_obj.get('cart_updated_at')
            if session_cart and session_time_str:
                sess_time = parse_db_timestamp(session_time_str)
                if (datetime.now() - sess_time).total_seconds() > CART_EXPIRATION_SECONDS:
                    session_obj['cart'] = []
                    session_obj.pop('coupon', None)
                    session_obj.pop('cart_updated_at', None)
                    return [], None, True
            return session_cart, session_obj.get('coupon'), False
            
        row_dict = dict(row) if not isinstance(row, dict) else row
        cart_data_str = row_dict.get('cart_data', '[]')
        coupon = row_dict.get('coupon_code')
        updated_at = parse_db_timestamp(row_dict.get('updated_at'))
        
        # 24-HOUR EXPIRATION CHECK:
        elapsed_seconds = (datetime.now() - updated_at).total_seconds()
        if elapsed_seconds > CART_EXPIRATION_SECONDS:
            # Cart has been inactive for more than 24 hours without purchase -> empty it
            empty_user_cart(session_obj, user_key=user_key)
            return [], None, True
            
        try:
            cart_items = json.loads(cart_data_str) if cart_data_str else []
        except Exception:
            cart_items = []
            
        # Synchronize with active Flask session
        session_obj['cart'] = cart_items
        session_obj['coupon'] = coupon
        session_obj['cart_updated_at'] = updated_at.strftime('%Y-%m-%d %H:%M:%S')
        
        return cart_items, coupon, False
        
    except Exception as ex:
        print(f"[CART_MANAGER GET ERROR] {ex}")
        return session_obj.get('cart', []), session_obj.get('coupon'), False

def save_user_cart(session_obj, cart_items: list, coupon_code: str = None, user_key: str = None):
    """
    Persists cart items to the database associated with user_key.
    Updates last modified timestamp so the 24-hour timer starts from latest activity.
    """
    ensure_cart_table()
    if not user_key:
        user_key = get_session_user_key(session_obj)
        
    now = datetime.now()
    now_str = now.strftime('%Y-%m-%d %H:%M:%S')
    cart_json = json.dumps(cart_items or [])
    coupon = coupon_code or session_obj.get('coupon')
    
    # Update Flask session
    session_obj['cart'] = cart_items or []
    session_obj['coupon'] = coupon
    session_obj['cart_updated_at'] = now_str
    
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        
        # Upsert in user_carts
        cursor.execute("SELECT id FROM user_carts WHERE user_key = ?", (user_key,))
        existing = cursor.fetchone()
        
        if existing:
            cursor.execute("""
            UPDATE user_carts 
            SET cart_data = ?, coupon_code = ?, updated_at = ? 
            WHERE user_key = ?
            """, (cart_json, coupon, now_str, user_key))
        else:
            cursor.execute("""
            INSERT INTO user_carts (user_key, cart_data, coupon_code, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?)
            """, (user_key, cart_json, coupon, now_str, now_str))
            
        conn.commit()
        conn.close()
    except Exception as ex:
        print(f"[CART_MANAGER SAVE ERROR] {ex}")

def empty_user_cart(session_obj, user_key: str = None):
    """
    Permanently clears the cart in both database and Flask session.
    Invoked when an order is completed, or when 24 hours elapse.
    """
    ensure_cart_table()
    if not user_key:
        user_key = get_session_user_key(session_obj)
        
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    # Clear session
    session_obj['cart'] = []
    session_obj.pop('coupon', None)
    session_obj.pop('cart_updated_at', None)
    
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        cursor.execute("""
        UPDATE user_carts 
        SET cart_data = '[]', coupon_code = NULL, updated_at = ? 
        WHERE user_key = ?
        """, (now_str, user_key))
        conn.commit()
        conn.close()
    except Exception as ex:
        print(f"[CART_MANAGER EMPTY ERROR] {ex}")

def migrate_guest_cart_to_account(session_obj, new_user_identifier: str):
    """
    Transfers products added while browsing as guest into the customer's permanent account cart upon login.
    If the account already had saved items, intelligently merges them without duplicating product IDs.
    """
    ensure_cart_table()
    if not new_user_identifier:
        return
        
    guest_key = f"guest:{session_obj.get('guest_id')}" if session_obj.get('guest_id') else None
    user_key = f"user:{str(new_user_identifier).strip().lower()}"
    
    # 1. Load existing account cart (and check 24-hr expiry)
    account_cart, account_coupon, _ = get_user_cart(session_obj, user_key=user_key)
    
    # 2. Load guest cart if any
    guest_cart = []
    guest_coupon = None
    if guest_key:
        guest_cart, guest_coupon, _ = get_user_cart(session_obj, user_key=guest_key)
        
    # If guest cart is empty, check session['cart']
    if not guest_cart and session_obj.get('cart'):
        guest_cart = session_obj.get('cart', [])
        
    # 3. Merge guest items into account cart
    merged_cart = list(account_cart)
    for g_item in guest_cart:
        p_id = g_item.get('product_id')
        v_name = g_item.get('variant_name', 'Standard')
        
        found = False
        for acc_item in merged_cart:
            if acc_item.get('product_id') == p_id and acc_item.get('variant_name') == v_name:
                acc_item['quantity'] = acc_item.get('quantity', 1) + g_item.get('quantity', 1)
                acc_item['subtotal'] = acc_item.get('unit_price', 0) * acc_item['quantity']
                found = True
                break
                
        if not found:
            merged_cart.append(dict(g_item))
            
    # 4. Save merged cart for user_key
    final_coupon = account_coupon or guest_coupon or session_obj.get('coupon')
    save_user_cart(session_obj, merged_cart, coupon_code=final_coupon, user_key=user_key)
    
    # 5. Clean up guest cart in DB
    if guest_key:
        try:
            conn = database.get_db()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM user_carts WHERE user_key = ?", (guest_key,))
            conn.commit()
            conn.close()
        except Exception:
            pass
