import os
import glob

replacements = {
    "Shop no.3, Near Paani ki tanki, Borkheda, Kota, Rajasthan, 324001": "Shop Number3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan, India, Pincode: 324001",
    "Shop no.3, Near Paani ki tanki, Borkheda": "Shop Number3, Near Paani ki Tanki, Borkheda",
    "42, Bartan Bazaar, Kota, Kota - 400002, Maharashtra, India": "Shop Number3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan, India, Pincode: 324001",
    "42, Bartan Bazaar, Kota, Kota - 400002, Maharashtra": "Shop Number3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan, India, Pincode: 324001"
}

files_to_check = glob.glob("**/*.html", recursive=True) + glob.glob("**/*.py", recursive=True)

for file in files_to_check:
    if file.endswith("update_address.py") or file.endswith("update_text.py"):
        continue
    try:
        with open(file, "r", encoding="utf-8") as f:
            content = f.read()
        
        updated = False
        for old_text, new_text in replacements.items():
            if old_text in content:
                content = content.replace(old_text, new_text)
                updated = True
                
        if updated:
            with open(file, "w", encoding="utf-8") as f:
                f.write(content)
            print(f"Updated {file}")
    except Exception as e:
        print(f"Error processing {file}: {e}")
