@echo off
title Kalash Enterprises - Production Server (www.kalashenterprises.co.in)
echo =========================================================================
echo Starting Kalash Enterprises Production Server for www.kalashenterprises.co.in
echo Running on Waitress Multi-Threaded Production WSGI Server
echo =========================================================================

REM Set production environment variables
set FLASK_ENV=production
set USE_MYSQL=true
set MYSQL_HOST=127.0.0.1
set MYSQL_PORT=3306
set MYSQL_USER=root
set MYSQL_PASSWORD=Sehgal6897@
set MYSQL_DB=kalash_kitchenware
set PORT=5000

"C:\Users\Dr Miit Sehgal\AppData\Local\Programs\Python\Python312\python.exe" waitress_server.py
pause
