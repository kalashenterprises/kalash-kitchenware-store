# Domain Connection & Production Deployment Guide
## Kalash Enterprises Kitchenware Store
**Official Production Domain**: `www.kalashenterprises.co.in` (and `kalashenterprises.co.in`)  
**Store Establishment**: Estd. 2011, Shop Number 3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan, India (Pincode: 324001)

---

## 1. Domain DNS Configuration (Registrar Settings)

Log into your Domain Registrar DNS Management Panel (e.g., **BigRock, GoDaddy, Namecheap, Hostinger, or Cloudflare**) and configure the following DNS records:

| Record Type | Name / Host | Target / Destination | TTL | Description |
|---|---|---|---|---|
| **CNAME** | `www` | Your Server IP / Cloud Target (e.g. `kalash-enterprises-web.onrender.com` or `kalashenterprises.co.in`) | `300` / Automatic | Primary canonical domain for `www.kalashenterprises.co.in` |
| **A** | `@` (or blank) | Server Public IPv4 (e.g. `YOUR_SERVER_IP`) | `300` / Automatic | Root apex domain redirect |
| **TXT** | `@` | (Provided by SSL / Registrar if requested) | `300` | Domain ownership verification |

> [!TIP]
> **Cloudflare Free DNS & SSL (Recommended)**: If you route your domain through Cloudflare nameservers, you get automatic enterprise DDoS protection, global CDN edge caching, and free auto-renewing SSL certificates for `www.kalashenterprises.co.in`.

---

## 2. Deployment Options

### Option A: 1-Click Managed Cloud Deployment (Render.com / Railway) — *Recommended*
This option requires zero server maintenance, includes automated Let's Encrypt SSL, and provides a managed MySQL database.

1. **Connect Repository**:
   - Push this workspace to your GitHub/GitLab account.
2. **Deploy on Render**:
   - Go to [dashboard.render.com](https://dashboard.render.com) and click **New > Blueprint**.
   - Select your repository. The included [`render.yaml`](./render.yaml) automatically provisions:
     - The Flask WSGI Web Service running Gunicorn.
     - The managed MySQL 8.0 database.
     - Production environment variables.
3. **Bind Custom Domain**:
   - In Render Web Service settings, navigate to **Custom Domains**.
   - Add `www.kalashenterprises.co.in` and `kalashenterprises.co.in`.
   - Copy the CNAME and A record targets provided by Render into your domain registrar DNS table.
   - Render automatically provisions and renews SSL for `www.kalashenterprises.co.in`.

---

### Option B: Cloudflare Zero-Trust Tunnel (Deploy Directly from this PC)
You can deploy the website live on `www.kalashenterprises.co.in` directly from this local machine without needing a public static IP or opening router ports:

1. Download `cloudflared` for Windows:
   ```powershell
   winget install Cloudflare.cloudflared
   ```
2. Authenticate with your Cloudflare account containing `kalashenterprises.co.in`:
   ```powershell
   cloudflared tunnel login
   ```
3. Create your production tunnel:
   ```powershell
   cloudflared tunnel create kalash-production
   ```
4. Route your domain:
   ```powershell
   cloudflared tunnel route dns kalash-production www.kalashenterprises.co.in
   cloudflared tunnel route dns kalash-production kalashenterprises.co.in
   ```
5. Run the tunnel pointing to your local production server:
   ```powershell
   cloudflared tunnel run --url http://127.0.0.1:5000 kalash-production
   ```
   *Your site is now instantly live worldwide at `https://www.kalashenterprises.co.in` with full Cloudflare SSL!*

---

### Option C: Cloud VPS (Hostinger / DigitalOcean / AWS EC2 / Google Cloud Compute)
For a dedicated Linux VPS (Ubuntu 22.04 / 24.04 LTS):

1. **Upload Project to VPS**:
   ```bash
   git clone <YOUR_REPO_URL> /var/www/kalash
   cd /var/www/kalash
   ```
2. **Launch with Docker Compose**:
   ```bash
   docker compose up -d --build
   ```
3. **Configure Nginx & Free SSL with Certbot**:
   - Copy [`nginx.conf`](./nginx.conf) to `/etc/nginx/sites-available/kalashenterprises.conf`
   - Enable the site:
     ```bash
     ln -s /etc/nginx/sites-available/kalashenterprises.conf /etc/nginx/sites-enabled/
     nginx -t && systemctl reload nginx
     ```
   - Generate free SSL certificates via Certbot:
     ```bash
     apt update && apt install -y certbot python3-certbot-nginx
     certbot --nginx -d www.kalashenterprises.co.in -d kalashenterprises.co.in
     ```

---

### Option D: Local / On-Premises Windows Production Server
To run production directly on this Windows machine:

1. Double-click [`run_production.bat`](./run_production.bat) (or run [`run_production.ps1`](./run_production.ps1)).
2. This launches the multi-threaded **Waitress Production WSGI Server** connected to your local MySQL 8.0 database.
3. Configure your router's port forwarding:
   - External Port 80 $\rightarrow$ Local IP Port 5000
   - External Port 443 $\rightarrow$ Local IP Port 5000

---

## 3. Production Verification Checklist

- [x] **Production WSGI Entrypoint**: [`wsgi.py`](./wsgi.py) configured with `ProxyFix` for HTTPS reverse proxy headers.
- [x] **Production WSGI Server**: Multi-threaded [`waitress_server.py`](./waitress_server.py) tested and operational.
- [x] **Docker Container Support**: [`Dockerfile`](./Dockerfile) and [`docker-compose.yml`](./docker-compose.yml) configured.
- [x] **Cloud PaaS Support**: [`Procfile`](./Procfile) and [`render.yaml`](./render.yaml) created.
- [x] **Reverse Proxy Config**: [`nginx.conf`](./nginx.conf) optimized for `www.kalashenterprises.co.in` with Gzip, SSL, and asset caching.
- [x] **Database Connectivity**: MySQL 8.0 `kalash_kitchenware` connected with graceful SQLite fallback.
