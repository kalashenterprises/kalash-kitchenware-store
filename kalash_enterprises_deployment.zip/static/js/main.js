/**
 * Kalash Enterprises - Frontend Engine
 * Handles Cart, B2B Quote Calculator, Modals, Toasts & Live Interactions
 */

// Global Toast System
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  const bgClass = type === 'success' ? 'bg-[#171c23] text-[#ffffff] border-l-4 border-[#ab3600]' : 'bg-[#ba1a1a] text-white';
  const icon = type === 'success' ? 'check_circle' : 'error';

  toast.className = `flex items-center gap-3 px-4 py-3 rounded-lg shadow-xl text-sm font-medium z-50 mb-2 transform transition-all duration-300 translate-y-4 opacity-0 ${bgClass}`;
  toast.innerHTML = `
    <span class="material-symbols-outlined text-[20px] text-[#fcba64]">${icon}</span>
    <span>${message}</span>
    <button onclick="this.parentElement.remove()" class="ml-auto text-gray-400 hover:text-white">
      <span class="material-symbols-outlined text-[16px]">close</span>
    </button>
  `;

  container.appendChild(toast);
  requestAnimationFrame(() => {
    toast.classList.remove('translate-y-4', 'opacity-0');
    toast.classList.add('translate-y-0', 'opacity-100');
  });

  setTimeout(() => {
    toast.classList.add('opacity-0', 'translate-y-2');
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// Add to Cart Function
async function addToCart(productId, variantName = null, quantity = 1) {
  try {
    const response = await fetch('/api/cart/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        product_id: productId,
        variant_name: variantName,
        quantity: quantity
      })
    });
    const data = await response.json();
    if (data.success) {
      updateCartBadge(data.cart_count, data.cart_total);
      showToast(data.message || 'Added to shopping bag!');
    } else {
      showToast(data.error || 'Could not add to cart', 'error');
    }
  } catch (err) {
    console.error('Error adding to cart:', err);
    showToast('Failed to update cart', 'error');
  }
}

// Instant Buy
async function instantBuy(productId, variantName = null) {
  await addToCart(productId, variantName, 1);
  window.location.href = '/cart';
}

// Update Cart Badge
function updateCartBadge(count, total) {
  const badgeCount = document.querySelectorAll('.cart-badge-count');
  badgeCount.forEach(el => {
    el.innerText = `${count} Items`;
  });
  const badgeTotal = document.querySelectorAll('.cart-badge-total');
  badgeTotal.forEach(el => {
    el.innerText = `₹${total.toLocaleString('en-IN')}`;
  });
  const floatingCount = document.querySelectorAll('.cart-item-count-pill');
  floatingCount.forEach(el => {
    el.innerText = count;
  });
}

// Cart Quantity Management
async function updateCartItem(productId, variantName, quantity) {
  try {
    const response = await fetch('/api/cart/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        product_id: productId,
        variant_name: variantName,
        quantity: quantity
      })
    });
    const data = await response.json();
    if (data.success) {
      window.location.reload();
    }
  } catch (err) {
    console.error(err);
  }
}

// Remove from Cart
async function removeCartItem(productId, variantName) {
  try {
    const response = await fetch('/api/cart/remove', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        product_id: productId,
        variant_name: variantName
      })
    });
    const data = await response.json();
    if (data.success) {
      window.location.reload();
    }
  } catch (err) {
    console.error(err);
  }
}

// Apply Coupon Code
async function applyCoupon() {
  const codeInput = document.getElementById('couponCodeInput');
  if (!codeInput) return;
  const code = codeInput.value.trim();
  if (!code) {
    showToast('Please enter a coupon code', 'error');
    return;
  }

  try {
    const response = await fetch('/api/cart/coupon', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ coupon_code: code })
    });
    const data = await response.json();
    if (data.success) {
      showToast(data.message);
      setTimeout(() => window.location.reload(), 800);
    } else {
      showToast(data.error, 'error');
    }
  } catch (err) {
    showToast('Failed to apply coupon', 'error');
  }
}

// B2B Wholesale Tier Calculator
function calculateB2BDiscount() {
  const select = document.getElementById('bulkValueSelect');
  if (!select) return;
  const val = parseInt(select.value, 10);
  const tierText = document.getElementById('discountTierText');
  const priceText = document.getElementById('estimatedPriceText');

  let discountPercent = 5;
  if (val >= 150000) {
    discountPercent = 20;
  } else if (val >= 50000) {
    discountPercent = 12;
  }

  const discounted = Math.round(val * (1 - discountPercent / 100));
  if (tierText) tierText.innerText = `${discountPercent}% OFF Instant Discount`;
  if (priceText) priceText.innerText = `₹${discounted.toLocaleString('en-IN')} + GST`;
}

// Submit B2B Inquiry Form
async function submitB2BInquiry(event) {
  event.preventDefault();
  const form = event.target;
  const formData = new FormData(form);

  const payload = {
    business_name: formData.get('business_name'),
    contact_phone: formData.get('contact_phone'),
    email: formData.get('email') || '',
    product_requirement: formData.get('product_requirement'),
    estimated_value: parseFloat(formData.get('estimated_value') || 65000)
  };

  try {
    const response = await fetch('/api/inquiry/b2b', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (data.success) {
      const successEl = document.getElementById('b2b-success');
      if (successEl) {
        successEl.innerHTML = `✓ Official Quote #${data.inquiry_number} Generated! Our Kota B2B desk will connect on WhatsApp (${payload.contact_phone}) within 30 minutes.`;
        successEl.classList.remove('hidden');
      }
      form.reset();
      showToast('B2B Inquiry dispatched successfully!');
    } else {
      showToast(data.error || 'Failed to submit inquiry', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Network error submitting quote', 'error');
  }
}

// Newsletter Subscription
async function submitNewsletter(event) {
  event.preventDefault();
  const form = event.target;
  const emailInput = form.querySelector('input[type="email"]');
  if (!emailInput) return;

  try {
    const response = await fetch('/api/newsletter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: emailInput.value })
    });
    const data = await response.json();
    if (data.success) {
      const msg = document.getElementById('newsletter-msg');
      if (msg) {
        msg.innerText = `🎉 ${data.message} Voucher: ${data.coupon}`;
        msg.classList.remove('hidden');
      }
      form.reset();
      showToast('Voucher code unlocked: ' + data.coupon);
    }
  } catch (err) {
    console.error(err);
  }
}

// Product Details: Gallery Image Switcher
function selectGalleryThumb(imgUrl, caption = '', btnElement = null) {
  const mainImg = document.getElementById('mainProductImg');
  if (mainImg) {
    mainImg.src = imgUrl;
  }
  if (btnElement) {
    document.querySelectorAll('.thumb-btn').forEach(btn => {
      btn.classList.remove('ring-2', 'ring-primary', 'opacity-100');
      btn.classList.add('opacity-70');
    });
    btnElement.classList.add('ring-2', 'ring-primary', 'opacity-100');
    btnElement.classList.remove('opacity-70');
  }
}

// Product Details: Variant Selector
function selectVariant(element, price, mrp, variantName) {
  document.querySelectorAll('.variant-chip').forEach(chip => {
    chip.classList.remove('border-[#996515]', 'bg-[#f0f4fd]', 'text-[#7b4e00]', 'font-bold');
    chip.classList.add('border-slate-200', 'bg-white', 'text-slate-700');
  });
  element.classList.remove('border-slate-200', 'bg-white', 'text-slate-700');
  element.classList.add('border-[#996515]', 'bg-[#f0f4fd]', 'text-[#7b4e00]', 'font-bold');

  const priceEl = document.getElementById('currentPrice');
  const mrpEl = document.getElementById('currentMrp');
  const saveEl = document.getElementById('saveAmount');
  const selectedVariantInput = document.getElementById('selectedVariantName');

  if (priceEl) priceEl.innerText = `₹${price.toLocaleString('en-IN')}`;
  if (mrpEl) mrpEl.innerText = `₹${mrp.toLocaleString('en-IN')}`;
  if (saveEl) saveEl.innerText = `SAVE ₹${(mrp - price).toLocaleString('en-IN')}`;
  if (selectedVariantInput) selectedVariantInput.value = variantName;
}

// Catalog View Switcher
function setCatalogView(mode) {
  const grid = document.getElementById('productCatalogGrid');
  if (!grid) return;

  const buttons = document.querySelectorAll('.view-btn');
  buttons.forEach(btn => {
    btn.classList.remove('bg-surface-container-lowest', 'text-primary', 'shadow-xs');
    btn.classList.add('text-tertiary');
  });

  const activeBtn = document.querySelector(`.view-btn[data-view="${mode}"]`);
  if (activeBtn) {
    activeBtn.classList.add('bg-surface-container-lowest', 'text-primary', 'shadow-xs');
    activeBtn.classList.remove('text-tertiary');
  }

  if (mode === '4col') {
    grid.className = 'grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-space-md';
  } else if (mode === '3col') {
    grid.className = 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-space-lg';
  } else if (mode === 'list') {
    grid.className = 'grid grid-cols-1 gap-space-md';
  }
}

// Quick View Modal
async function openQuickView(productId) {
  try {
    const response = await fetch(`/api/products/${productId}`);
    const product = await response.json();
    if (!product) return;

    const modal = document.getElementById('quickViewModal');
    if (!modal) return;

    document.getElementById('qv-img').src = product.image_url;
    document.getElementById('qv-badge').innerText = product.material_badge;
    document.getElementById('qv-title').innerText = product.name;
    document.getElementById('qv-category').innerText = product.category_name;
    document.getElementById('qv-price').innerText = `₹${product.retail_price.toLocaleString('en-IN')}`;
    document.getElementById('qv-mrp').innerText = `₹${product.mrp.toLocaleString('en-IN')}`;
    document.getElementById('qv-save').innerText = `${product.discount_percent}% OFF`;
    document.getElementById('qv-desc').innerText = product.lead_description;
    document.getElementById('qv-stock').innerText = `${product.stock} units left in Kota stock`;
    document.getElementById('qv-link').href = `/product/${product.slug}`;

    const addBtn = document.getElementById('qv-add-btn');
    addBtn.onclick = () => {
      addToCart(product.id);
      closeQuickView();
    };

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  } catch (err) {
    console.error(err);
  }
}

function closeQuickView() {
  const modal = document.getElementById('quickViewModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
}
