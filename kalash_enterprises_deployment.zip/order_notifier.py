"""
Kalash Enterprises - Owner Email Order Notification Dispatcher
Sends detailed email notification to pavitram.kalash07@gmail.com on every order
mentioning all customer details and the specific product(s) ordered.
Estd. 2011, Shop Number 3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan, India, Pincode: 324001
"""

import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime
import re
import database

# Owner Notification Target
OWNER_NOTIFICATION_EMAIL = os.environ.get('ORDER_NOTIFICATION_EMAIL', 'pavitram.kalash07@gmail.com')

# SMTP Settings
SMTP_HOST = os.environ.get('SMTP_HOST', 'smtp.gmail.com')
SMTP_PORT = int(os.environ.get('SMTP_PORT', 587))
SMTP_USER = os.environ.get('SMTP_USER') or os.environ.get('MAIL_USERNAME', 'pavitram.kalash07@gmail.com')
SMTP_PASSWORD = os.environ.get('SMTP_PASSWORD') or os.environ.get('MAIL_PASSWORD') or os.environ.get('GMAIL_APP_PASSWORD', '')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
NOTIFICATIONS_LOG_PATH = os.path.join(DATA_DIR, 'order_notifications.log')

def ensure_notifications_table():
    """Creates order_notifications table in the database if it doesn't exist."""
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS order_notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_number VARCHAR(100) NOT NULL,
            recipient VARCHAR(255) NOT NULL,
            subject VARCHAR(255) NOT NULL,
            customer_name VARCHAR(255) NOT NULL,
            customer_phone VARCHAR(50) NOT NULL,
            total_amount DOUBLE NOT NULL,
            status VARCHAR(100) NOT NULL,
            log_message TEXT,
            sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """)
        conn.commit()
        conn.close()
    except Exception as ex:
        # SQLite fallback fallback syntax
        try:
            conn = database.get_db()
            cursor = conn.cursor()
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS order_notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_number TEXT NOT NULL,
                recipient TEXT NOT NULL,
                subject TEXT NOT NULL,
                customer_name TEXT NOT NULL,
                customer_phone TEXT NOT NULL,
                total_amount REAL NOT NULL,
                status TEXT NOT NULL,
                log_message TEXT,
                sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """)
            conn.commit()
            conn.close()
        except Exception:
            pass

def log_notification_to_disk(order_number: str, recipient: str, subject: str, status: str, message: str):
    """Appends order email notification transaction to persistent disk log."""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(NOTIFICATIONS_LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(f"[{now_str}] ORDER: {order_number} | TO: {recipient} | STATUS: {status} | {message}\n")
    except Exception as ex:
        print(f"[ORDER NOTIFIER LOG WARNING] {ex}")

def record_notification_in_db(order_number: str, recipient: str, subject: str,
                              customer_name: str, customer_phone: str, total_amount: float,
                              status: str, log_message: str):
    """Records notification in database for owner portal inspection."""
    ensure_notifications_table()
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        cursor.execute("""
        INSERT INTO order_notifications (
            order_number, recipient, subject, customer_name, customer_phone, total_amount, status, log_message
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            order_number, recipient, subject, customer_name, customer_phone,
            total_amount, status, log_message
        ))
        conn.commit()
        conn.close()
    except Exception as ex:
        print(f"[ORDER NOTIFIER DB RECORD WARNING] {ex}")

def get_recent_order_notifications(limit: int = 30) -> list:
    """Retrieves list of dispatched order notification events for owner portal."""
    ensure_notifications_table()
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        cursor.execute("""
        SELECT * FROM order_notifications ORDER BY id DESC LIMIT ?
        """, (limit,))
        rows = cursor.fetchall()
        conn.close()
        notifications = []
        for r_raw in rows:
            r = dict(r_raw) if not isinstance(r_raw, dict) else r_raw
            created = r.get('sent_at')
            created_str = created.strftime('%Y-%m-%d %H:%M') if isinstance(created, datetime) else str(created)[:16]
            notifications.append({
                'id': r.get('id'),
                'order_number': r.get('order_number'),
                'recipient': r.get('recipient'),
                'subject': r.get('subject'),
                'customer_name': r.get('customer_name'),
                'customer_phone': r.get('customer_phone'),
                'total_amount': r.get('total_amount'),
                'status': r.get('status'),
                'log_message': r.get('log_message'),
                'sent_at': created_str
            })
        return notifications
    except Exception as ex:
        print(f"[ORDER NOTIFICATIONS GET WARNING] {ex}")
        return []

def send_order_notification_email(order_number: str, customer_details: dict, cart_items: list,
                                  summary: dict, payment_method: str, tracking_awb: str = "",
                                  base_url: str = "https://www.kalashenterprises.co.in") -> dict:
    """
    Constructs and sends an email notification to pavitram.kalash07@gmail.com
    detailing:
    1. Every customer detail filled (Name, Mobile, Email, Full Address, GSTIN, Business Name, Notes)
    2. Every product ordered (Name, Variant, Quantity, Unit Price, Line Total)
    3. Order Financials (Subtotal, Discount, Shipping, GST, Total Payable)
    4. Delivery & Courier Details (BlueDart Express Air, AWB)
    """
    recipient = OWNER_NOTIFICATION_EMAIL
    customer_name = customer_details.get('customer_name', '').strip() or 'Valued Customer'
    customer_phone = customer_details.get('phone', '').strip()
    customer_email = customer_details.get('email', '').strip()
    address = customer_details.get('address', '').strip()
    city = customer_details.get('city', '').strip()
    state = customer_details.get('state', '').strip()
    pincode = customer_details.get('pincode', '').strip()
    gstin = customer_details.get('gstin', '').strip()
    business_name = customer_details.get('business_name', '').strip()
    notes = customer_details.get('notes', '').strip()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    total_amount = float(summary.get('total', 0.0))
    subtotal = float(summary.get('subtotal', 0.0))
    discount = float(summary.get('discount', 0.0))
    tax_amount = float(summary.get('tax', 0.0))
    shipping_fee = float(summary.get('shipping', 0.0))

    clean_digits = re.sub(r'\D', '', customer_phone)
    wa_customer_link = f"https://wa.me/91{clean_digits[-10:]}" if len(clean_digits) >= 10 else f"tel:{customer_phone}"

    subject = f"🛍️ New Order Received: #{order_number} - {customer_name} (₹{total_amount:,.0f})"

    # 1. Build Itemized HTML Table Rows
    item_rows_html = ""
    item_rows_text = ""
    for idx, item in enumerate(cart_items, start=1):
        name = item.get('name', 'Kitchenware Product')
        variant = item.get('variant_name', 'Standard')
        qty = item.get('quantity', 1)
        price = float(item.get('unit_price', 0.0))
        subtot = float(item.get('subtotal', price * qty))
        slug = item.get('slug', '')
        prod_link = f"{base_url}/product/{slug}" if slug else base_url

        item_rows_html += f"""
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="padding: 12px; font-weight: bold; color: #1e293b;">
            <a href="{prod_link}" style="color: #7b4e00; text-decoration: none;">{name}</a>
            <div style="font-size: 11px; color: #64748b; font-weight: normal; margin-top: 2px;">Variant: {variant}</div>
          </td>
          <td style="padding: 12px; text-align: center; color: #475569;">₹{price:,.0f}</td>
          <td style="padding: 12px; text-align: center; font-weight: bold; color: #1e293b;">{qty}</td>
          <td style="padding: 12px; text-align: right; font-weight: bold; color: #107c41;">₹{subtot:,.0f}</td>
        </tr>
        """
        item_rows_text += f"{idx}. {name} ({variant}) - Qty: {qty} @ ₹{price:,.0f} = ₹{subtot:,.0f}\n"

    # 2. Build Rich HTML Email
    html_body = f"""
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>{subject}</title>
    </head>
    <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; margin: 0; padding: 24px; color: #1e293b;">
      <div style="max-width: 680px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 16px rgba(0,0,0,0.06); border: 1px solid #e2e8f0;">

        <!-- Header -->
        <div style="background: linear-gradient(135deg, #7b4e00, #ab3600); padding: 24px 32px; color: #ffffff;">
          <table width="100%">
            <tr>
              <td>
                <h1 style="margin: 0; font-size: 22px; font-weight: bold; letter-spacing: -0.5px;">KALASH ENTERPRISES</h1>
                <p style="margin: 4px 0 0; font-size: 12px; opacity: 0.9;">Artisan Kitchenware & Utensils Store • Estd. 2011, Kota, Rajasthan</p>
              </td>
              <td style="text-align: right;">
                <span style="background-color: rgba(255,255,255,0.2); padding: 6px 12px; border-radius: 20px; font-size: 11px; font-weight: bold; text-transform: uppercase;">
                  Owner Alert
                </span>
              </td>
            </tr>
          </table>
        </div>

        <!-- Order Highlight Banner -->
        <div style="background-color: #ecfdf5; border-bottom: 2px solid #10b981; padding: 18px 32px;">
          <table width="100%">
            <tr>
              <td>
                <div style="font-size: 12px; font-weight: bold; color: #047857; text-transform: uppercase; letter-spacing: 0.5px;">🎉 New Order Received</div>
                <div style="font-size: 20px; font-weight: bold; color: #064e3b; margin-top: 2px;">Order #{order_number}</div>
                <div style="font-size: 12px; color: #047857; margin-top: 4px;">Time: {now_str} • Hub: Kota Central Depot</div>
              </td>
              <td style="text-align: right; vertical-align: middle;">
                <div style="font-size: 11px; color: #047857; font-weight: 600;">Total Payable</div>
                <div style="font-size: 26px; font-weight: 800; color: #047857;">₹{total_amount:,.0f}</div>
              </td>
            </tr>
          </table>
        </div>

        <div style="padding: 28px 32px;">

          <!-- Customer Filled Details Card -->
          <div style="background-color: #f8fafc; border-radius: 12px; border: 1px solid #e2e8f0; padding: 20px; margin-bottom: 24px;">
            <h3 style="margin: 0 0 14px; font-size: 14px; font-weight: bold; color: #7b4e00; text-transform: uppercase; letter-spacing: 0.5px;">
              👤 Customer Details Filled While Ordering
            </h3>
            <table width="100%" style="font-size: 13px; line-height: 1.6;">
              <tr>
                <td style="width: 35%; color: #64748b; font-weight: 600; padding: 4px 0;">Customer Name:</td>
                <td style="color: #0f172a; font-weight: bold; padding: 4px 0;">{customer_name}</td>
              </tr>
              <tr>
                <td style="color: #64748b; font-weight: 600; padding: 4px 0;">Mobile Phone:</td>
                <td style="color: #0f172a; font-weight: bold; padding: 4px 0;">
                  <a href="{wa_customer_link}" style="color: #25d366; text-decoration: none; font-weight: bold;">{customer_phone} 📲 (Chat on WhatsApp)</a>
                </td>
              </tr>
              <tr>
                <td style="color: #64748b; font-weight: 600; padding: 4px 0;">Email Address:</td>
                <td style="color: #0f172a; padding: 4px 0;"><a href="mailto:{customer_email}" style="color: #2563eb; text-decoration: none;">{customer_email or 'N/A'}</a></td>
              </tr>
              <tr>
                <td style="color: #64748b; font-weight: 600; padding: 4px 0; vertical-align: top;">Delivery Address:</td>
                <td style="color: #0f172a; font-weight: 500; padding: 4px 0;">
                  {address}<br>
                  {city}, {state} - <strong>{pincode}</strong>
                </td>
              </tr>
              {"<tr><td style='color: #64748b; font-weight: 600; padding: 4px 0;'>Business / Firm:</td><td style='color: #0f172a; font-weight: bold; padding: 4px 0;'>" + business_name + "</td></tr>" if business_name else ""}
              {"<tr><td style='color: #64748b; font-weight: 600; padding: 4px 0;'>GSTIN Number:</td><td style='color: #0f172a; font-family: monospace; font-weight: bold; padding: 4px 0;'>" + gstin + "</td></tr>" if gstin else ""}
              {"<tr><td style='color: #64748b; font-weight: 600; padding: 4px 0;'>Customer Notes:</td><td style='color: #b45309; font-weight: 500; padding: 4px 0;'>" + notes + "</td></tr>" if notes else ""}
            </table>
          </div>

          <!-- Product(s) Ordered Table -->
          <div style="margin-bottom: 24px;">
            <h3 style="margin: 0 0 12px; font-size: 14px; font-weight: bold; color: #7b4e00; text-transform: uppercase; letter-spacing: 0.5px;">
              🍳 Product(s) Ordered by Customer ({len(cart_items)} Item Types)
            </h3>
            <table width="100%" style="border-collapse: collapse; font-size: 13px;">
              <thead>
                <tr style="background-color: #f1f5f9; text-transform: uppercase; font-size: 11px; color: #64748b; font-weight: bold; text-align: left;">
                  <th style="padding: 10px 12px;">Product Details</th>
                  <th style="padding: 10px 12px; text-align: center;">Unit Price</th>
                  <th style="padding: 10px 12px; text-align: center;">Qty</th>
                  <th style="padding: 10px 12px; text-align: right;">Total</th>
                </tr>
              </thead>
              <tbody>
                {item_rows_html}
              </tbody>
            </table>
          </div>

          <!-- Financial Summary -->
          <div style="background-color: #f8fafc; border-radius: 12px; border: 1px solid #e2e8f0; padding: 18px 20px; margin-bottom: 24px;">
            <table width="100%" style="font-size: 13px; line-height: 1.8;">
              <tr>
                <td style="color: #64748b;">Items Subtotal:</td>
                <td style="text-align: right; font-weight: 600; color: #1e293b;">₹{subtotal:,.0f}</td>
              </tr>
              {"<tr><td style='color: #059669; font-weight: 600;'>Discount Applied:</td><td style='text-align: right; font-weight: 600; color: #059669;'>-₹" + f"{discount:,.0f}" + "</td></tr>" if discount > 0 else ""}
              <tr>
                <td style="color: #64748b;">Pan-India Courier Delivery:</td>
                <td style="text-align: right; font-weight: 600; color: #059669;">{"FREE" if shipping_fee == 0 else f"₹{shipping_fee:,.0f}"}</td>
              </tr>
              <tr>
                <td style="color: #64748b; font-size: 11px;">Estimated GST (18% included):</td>
                <td style="text-align: right; font-size: 11px; color: #64748b;">₹{tax_amount:,.0f}</td>
              </tr>
              <tr style="border-top: 1px solid #cbd5e1; font-size: 15px;">
                <td style="padding-top: 8px; font-weight: bold; color: #0f172a;">Grand Total Payable:</td>
                <td style="padding-top: 8px; text-align: right; font-weight: 800; color: #ab3600; font-size: 18px;">₹{total_amount:,.0f}</td>
              </tr>
            </table>
          </div>

          <!-- Payment & Logistics Info -->
          <div style="background-color: #fefce8; border-radius: 12px; border: 1px solid #fde047; padding: 16px 20px; margin-bottom: 24px; font-size: 12px; color: #713f12;">
            <table width="100%">
              <tr>
                <td style="width: 50%; vertical-align: top;">
                  <strong>Payment Method:</strong> {payment_method}<br>
                  <strong>Payment Status:</strong> Pending Verification
                </td>
                <td style="width: 50%; vertical-align: top;">
                  <strong>Courier Partner:</strong> BlueDart Express Air<br>
                  <strong>Tracking AWB:</strong> {tracking_awb}
                </td>
              </tr>
            </table>
          </div>

          <!-- Quick Owner Actions -->
          <div style="text-align: center; padding-top: 8px;">
            <a href="{base_url}/admin#orders" style="display: inline-block; background-color: #7b4e00; color: #ffffff; text-decoration: none; padding: 12px 24px; border-radius: 10px; font-size: 13px; font-weight: bold; margin: 4px 6px;">
              View in Owner Portal
            </a>
            <a href="{base_url}/invoice/{order_number}" style="display: inline-block; background-color: #ab3600; color: #ffffff; text-decoration: none; padding: 12px 24px; border-radius: 10px; font-size: 13px; font-weight: bold; margin: 4px 6px;">
              View Tax Invoice
            </a>
            <a href="{base_url}/api/admin/orders/export.xlsx" style="display: inline-block; background-color: #107c41; color: #ffffff; text-decoration: none; padding: 12px 24px; border-radius: 10px; font-size: 13px; font-weight: bold; margin: 4px 6px;">
              Download Orders Excel
            </a>
          </div>

        </div>

        <!-- Footer -->
        <div style="background-color: #f1f5f9; padding: 18px 32px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #64748b; text-align: center;">
          <p style="margin: 0 0 4px;"><strong>Kalash Enterprises</strong> • Estd. 2011</p>
          <p style="margin: 0 0 4px;">Shop Number 3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan, India, Pincode: 324001</p>
          <p style="margin: 0;">Owner Contact: +91 8107183725 | VPA: 8107183725@upi | Target: pavitram.kalash07@gmail.com</p>
        </div>

      </div>
    </body>
    </html>
    """

    # 3. Plain Text Alternative
    plain_text = f"""
========================================================================
NEW ORDER NOTIFICATION - KALASH ENTERPRISES
========================================================================
Order Number: {order_number}
Timestamp: {now_str}
Total Amount: Rs. {total_amount:,.0f}

--- CUSTOMER DETAILS FILLED WHILE ORDERING ---
Name: {customer_name}
Mobile Phone: {customer_phone}
Email: {customer_email}
Delivery Address: {address}, {city}, {state} - {pincode}
Business Name: {business_name or 'N/A'}
GSTIN: {gstin or 'N/A'}
Customer Notes: {notes or 'N/A'}

--- PRODUCT(S) ORDERED ---
{item_rows_text}

--- FINANCIAL BREAKDOWN ---
Items Subtotal: Rs. {subtotal:,.0f}
Discount Saved: -Rs. {discount:,.0f}
Pan-India Delivery: Rs. {shipping_fee:,.0f} (FREE)
GST (18% included): Rs. {tax_amount:,.0f}
Total Payable: Rs. {total_amount:,.0f}

--- PAYMENT & LOGISTICS ---
Payment Method: {payment_method}
Courier Partner: BlueDart Express Air (AWB: {tracking_awb})

View in Owner Portal: {base_url}/admin#orders
View Invoice: {base_url}/invoice/{order_number}
Download Orders Excel: {base_url}/api/admin/orders/export.xlsx
========================================================================
    """

    status = "Pending"
    log_msg = ""

    # Attempt to dispatch via SMTP if credentials or server available
    if SMTP_PASSWORD:
        try:
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = f"Kalash Enterprises Orders <{SMTP_USER}>"
            msg['To'] = recipient
            msg['Reply-To'] = customer_email or SMTP_USER

            msg.attach(MIMEText(plain_text, 'plain', 'utf-8'))
            msg.attach(MIMEText(html_body, 'html', 'utf-8'))

            server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=12)
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.sendmail(SMTP_USER, [recipient], msg.as_string())
            server.quit()

            status = "Sent via SMTP"
            log_msg = f"Email successfully delivered via {SMTP_HOST}:{SMTP_PORT} to {recipient}."
            print(f"[ORDER NOTIFIER SUCCESS] {log_msg}")
        except Exception as ex:
            status = "SMTP Failed / Logged"
            log_msg = f"SMTP dispatch error: {ex}. Notification logged to disk."
            print(f"[ORDER NOTIFIER WARNING] {log_msg}")
    else:
        status = "Logged & Queued (Awaiting SMTP_PASSWORD)"
        log_msg = f"Order notification prepared for {recipient}. Awaiting SMTP_PASSWORD env var; logged to disk & database."
        print(f"[ORDER NOTIFIER INFO] {log_msg}")

    # Always log to disk and database
    log_notification_to_disk(order_number, recipient, subject, status, log_msg)
    record_notification_in_db(order_number, recipient, subject, customer_name, customer_phone, total_amount, status, log_msg)

    return {
        'success': True,
        'status': status,
        'recipient': recipient,
        'order_number': order_number,
        'subject': subject,
        'message': log_msg
    }
