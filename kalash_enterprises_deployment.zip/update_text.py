import os

replacements = {
    "2011": "2011",
    "Shop no.3, Near Paani ki tanki, Borkheda, Kota, Rajasthan, 324001": "Shop no.3, Near Paani ki tanki, Borkheda, Kota, Rajasthan, 324001",
    "Shop no.3, Near Paani ki tanki, Borkheda": "Shop no.3, Near Paani ki tanki, Borkheda",
    "Kota": "Kota",
    "Kota": "Kota",
    "8107183725": "8107183725",
    "+91 8107183725": "+91 8107183725",
    "Company portal": "Company portal",
    "company portal": "company portal",
    "Company Portal": "Company Portal",
    "Company Admin": "Company Admin"
}

root_dir = r"c:\Kalash Enterprises\stitch_kalash_enterprises_kitchenware_store\stitch_kalash_enterprises_kitchenware_store"

for root, dirs, files in os.walk(root_dir):
    if '.git' in root or '__pycache__' in root:
        continue
    for f in files:
        if f.endswith('.py') or f.endswith('.html') or f.endswith('.js') or f.endswith('.txt'):
            path = os.path.join(root, f)
            try:
                with open(path, 'r', encoding='utf-8') as file:
                    content = file.read()
                original = content
                for k, v in replacements.items():
                    content = content.replace(k, v)
                if original != content:
                    with open(path, 'w', encoding='utf-8') as file:
                        file.write(content)
                    print(f"Updated {path}")
            except Exception as e:
                print(f"Error processing {path}: {e}")
