@echo off
echo Starting Kalash Enterprises Kitchenware Store Server...
"C:\Users\Dr Miit Sehgal\AppData\Local\Programs\Python\Python312\python.exe" app.py
pause
