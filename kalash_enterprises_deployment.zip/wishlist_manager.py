"""
Kalash Enterprises - Account-Connected Persistent Wishlist Manager
Estd. 2011, Kota, Rajasthan, India

Responsibilities:
1. Associates each wishlist with the customer's logged-in Google email.
2. Guarantees complete data isolation: each account has its own independent wishlist.
3. Allows guests to browse and save items to a temporary guest wishlist.
4. Seamlessly merges guest wishlist items into the customer's Google account upon login.
5. Returns full product metadata and live stock counts for saved items.
"""

import uuid
import json
import database

def ensure_wishlist_table():
    """Initializes user_wishlists table in MySQL and SQLite."""
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        
        is_mysql = isinstance(conn, database.MySQLConnectionWrapper)
        
        if is_mysql:
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_wishlists (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_key VARCHAR(255) NOT NULL,
                product_id INT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_user_product (user_key, product_id),
                INDEX idx_wishlist_user (user_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)
        else:
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_wishlists (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_key TEXT NOT NULL,
                product_id INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE (user_key, product_id)
            )
            """)
        conn.commit()
        conn.close()
    except Exception as ex:
        print(f"[WISHLIST_MANAGER DB INIT WARNING] {ex}")

def get_session_user_key(session_obj) -> str:
    """Returns the unique user identifier key for the current session."""
    if session_obj.get('user_logged_in'):
        ident = session_obj.get('user_email') or session_obj.get('user_phone') or session_obj.get('user_name')
        if ident:
            return f"user:{str(ident).strip().lower()}"
            
    # For guest sessions, maintain a persistent unique guest identifier
    if 'guest_id' not in session_obj or not session_obj.get('guest_id'):
        session_obj['guest_id'] = f"guest_{uuid.uuid4().hex[:12]}"
        
    return f"guest:{session_obj['guest_id']}"

def get_wishlist_product_ids(session_obj, user_key: str = None) -> list:
    """Returns list of product IDs saved in the user's wishlist."""
    ensure_wishlist_table()
    if not user_key:
        user_key = get_session_user_key(session_obj)
        
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT product_id FROM user_wishlists WHERE user_key = ? ORDER BY id DESC", (user_key,))
        rows = cursor.fetchall()
        conn.close()
        return [int(r['product_id']) for r in rows]
    except Exception as ex:
        print(f"[WISHLIST_MANAGER GET_IDS ERROR] {ex}")
        return []

def get_wishlist_items(session_obj, user_key: str = None) -> list:
    """
    Returns full product dictionaries for all items in the user's wishlist.
    Attaches images, variants, and stock status.
    """
    p_ids = get_wishlist_product_ids(session_obj, user_key)
    if not p_ids:
        return []
        
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        
        items = []
        for pid in p_ids:
            cursor.execute("SELECT * FROM products WHERE id = ?", (pid,))
            prod = cursor.fetchone()
            if not prod:
                continue
                
            p_dict = dict(prod)
            
            # Safely parse variants and gallery if json strings
            if isinstance(p_dict.get('variants'), str):
                try:
                    p_dict['variants'] = json.loads(p_dict['variants'])
                except Exception:
                    p_dict['variants'] = []
            elif not p_dict.get('variants'):
                p_dict['variants'] = []
                
            if isinstance(p_dict.get('gallery'), str):
                try:
                    p_dict['gallery'] = json.loads(p_dict['gallery'])
                except Exception:
                    p_dict['gallery'] = [p_dict.get('image_url')]
            elif not p_dict.get('gallery'):
                p_dict['gallery'] = [p_dict.get('image_url')] if p_dict.get('image_url') else []
                
            items.append(p_dict)
            
        conn.close()
        return items
    except Exception as ex:
        print(f"[WISHLIST_MANAGER GET_ITEMS ERROR] {ex}")
        return []

def get_wishlist_count(session_obj, user_key: str = None) -> int:
    """Returns count of saved items in the user's wishlist."""
    ensure_wishlist_table()
    if not user_key:
        user_key = get_session_user_key(session_obj)
        
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as cnt FROM user_wishlists WHERE user_key = ?", (user_key,))
        row = cursor.fetchone()
        conn.close()
        if row:
            return int(row['cnt'])
        return 0
    except Exception as ex:
        print(f"[WISHLIST_MANAGER COUNT ERROR] {ex}")
        return 0

def is_product_in_wishlist(session_obj, product_id: int) -> bool:
    """Checks whether a given product is currently saved in the user's wishlist."""
    p_ids = get_wishlist_product_ids(session_obj)
    return int(product_id) in p_ids

def toggle_wishlist(session_obj, product_id: int, user_key: str = None) -> dict:
    """
    Toggles a product in the user's wishlist.
    If product is in wishlist -> removes it.
    If product is not in wishlist -> adds it.
    Returns: {'success': True, 'action': 'added'|'removed', 'is_wishlisted': bool, 'count': int}
    """
    ensure_wishlist_table()
    if not user_key:
        user_key = get_session_user_key(session_obj)
    p_id = int(product_id)
    
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM user_wishlists WHERE user_key = ? AND product_id = ?", (user_key, p_id))
        existing = cursor.fetchone()
        
        if existing:
            cursor.execute("DELETE FROM user_wishlists WHERE user_key = ? AND product_id = ?", (user_key, p_id))
            action = 'removed'
            is_wishlisted = False
        else:
            is_mysql = isinstance(conn, database.MySQLConnectionWrapper)
            if is_mysql:
                cursor.execute("""
                INSERT INTO user_wishlists (user_key, product_id)
                VALUES (?, ?)
                ON DUPLICATE KEY UPDATE created_at = CURRENT_TIMESTAMP
                """, (user_key, p_id))
            else:
                cursor.execute("""
                INSERT OR IGNORE INTO user_wishlists (user_key, product_id)
                VALUES (?, ?)
                """, (user_key, p_id))
            action = 'added'
            is_wishlisted = True
            
        conn.commit()
        
        # Get updated count
        cursor.execute("SELECT COUNT(*) as cnt FROM user_wishlists WHERE user_key = ?", (user_key,))
        cnt_row = cursor.fetchone()
        count = int(cnt_row['cnt']) if cnt_row else 0
        conn.close()
        
        return {
            'success': True,
            'action': action,
            'is_wishlisted': is_wishlisted,
            'count': count
        }
    except Exception as ex:
        print(f"[WISHLIST_MANAGER TOGGLE ERROR] {ex}")
        return {
            'success': False,
            'error': str(ex),
            'action': 'none',
            'is_wishlisted': False,
            'count': get_wishlist_count(session_obj)
        }

def remove_from_wishlist(session_obj, product_id: int, user_key: str = None) -> bool:
    """Explicitly removes a product from the user's wishlist."""
    ensure_wishlist_table()
    if not user_key:
        user_key = get_session_user_key(session_obj)
    p_id = int(product_id)
    
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM user_wishlists WHERE user_key = ? AND product_id = ?", (user_key, p_id))
        conn.commit()
        conn.close()
        return True
    except Exception as ex:
        print(f"[WISHLIST_MANAGER REMOVE ERROR] {ex}")
        return False

def migrate_guest_wishlist_to_account(session_obj, user_ident: str):
    """
    Transfers any items in the guest wishlist to the customer's Google email account upon login.
    De-duplicates entries and removes temporary guest entries.
    """
    if not user_ident:
        return
        
    clean_ident = str(user_ident).strip().lower()
    guest_key = f"guest:{session_obj.get('guest_id', '')}"
    user_key = f"user:{clean_ident}"
    
    if guest_key == user_key or not session_obj.get('guest_id'):
        return
        
    ensure_wishlist_table()
    try:
        conn = database.get_db()
        cursor = conn.cursor()
        
        # Fetch guest items
        cursor.execute("SELECT product_id FROM user_wishlists WHERE user_key = ?", (guest_key,))
        guest_rows = cursor.fetchall()
        guest_pids = [int(r['product_id']) for r in guest_rows]
        
        is_mysql = isinstance(conn, database.MySQLConnectionWrapper)
        for pid in guest_pids:
            if is_mysql:
                cursor.execute("""
                INSERT INTO user_wishlists (user_key, product_id)
                VALUES (?, ?)
                ON DUPLICATE KEY UPDATE created_at = CURRENT_TIMESTAMP
                """, (user_key, pid))
            else:
                cursor.execute("""
                INSERT OR IGNORE INTO user_wishlists (user_key, product_id)
                VALUES (?, ?)
                """, (user_key, pid))
                
        # Clean up guest records
        cursor.execute("DELETE FROM user_wishlists WHERE user_key = ?", (guest_key,))
        conn.commit()
        conn.close()
        print(f"[WISHLIST_MANAGER] Successfully migrated {len(guest_pids)} wishlist item(s) from {guest_key} to {user_key}")
    except Exception as ex:
        print(f"[WISHLIST_MANAGER MIGRATION WARNING] {ex}")
