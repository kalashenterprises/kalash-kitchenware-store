"""
Kalash Enterprises - Orders Master Google Sheets & Microsoft Excel Synchronization Module
Records every detail filled by the customer along with the products ordered.
Available exclusively to the Owner / Company Portal for live viewing and downloading.
Estd. 2011, Shop Number 3, Near Paani ki Tanki, Borkheda, Kota, Rajasthan, India, Pincode: 324001
"""

import os
import csv
import io
import re
from datetime import datetime
import database

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
ORDERS_CSV_PATH = os.path.join(DATA_DIR, 'kalash_orders_master_sheet.csv')
ORDERS_XLSX_PATH = os.path.join(DATA_DIR, 'kalash_orders_master_sheet.xlsx')
ITEMS_CSV_PATH = os.path.join(DATA_DIR, 'kalash_order_items_sheet.csv')

GOOGLE_SHEET_ORDER_WEBHOOK_URL = os.environ.get('GOOGLE_SHEET_ORDER_WEBHOOK_URL', '')

ORDERS_MASTER_HEADERS = [
    'Order Date & Time',
    'Order Number',
    'Customer Name',
    'Mobile Number',
    'Email Address',
    'Delivery Address',
    'City',
    'State',
    'Pincode',
    'GSTIN',
    'Business Name',
    'Customer Notes',
    'Products Ordered (Summary)',
    'Total Items Count',
    'Items Subtotal (₹)',
    'Discount Saved (₹)',
    'Estimated GST 18% (₹)',
    'Delivery Shipping (₹)',
    'Total Payable Amount (₹)',
    'Payment Method',
    'Payment Status',
    'Courier Partner',
    'BlueDart AWB Tracking',
    'Kota Fulfillment Hub'
]

ORDER_ITEMS_HEADERS = [
    'Order Date & Time',
    'Order Number',
    'Customer Name',
    'Customer Phone',
    'Product ID',
    'Product Name',
    'Variant / Size',
    'Unit Price (₹)',
    'Quantity',
    'Line Subtotal (₹)',
    'Product Image URL'
]

def ensure_data_directory():
    os.makedirs(DATA_DIR, exist_ok=True)

def normalize_phone(phone: str) -> str:
    if not phone:
        return ""
    digits = re.sub(r'\D', '', str(phone))
    if len(digits) > 10 and digits.startswith('91'):
        digits = digits[2:]
    elif len(digits) > 10 and digits.startswith('0'):
        digits = digits[1:]
    return digits[-10:] if len(digits) >= 10 else digits

def get_all_orders_for_sheets() -> tuple[list, list]:
    """
    Fetches all orders and itemized products from the database.
    Returns (master_orders_list, itemized_products_list).
    """
    conn = database.get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM orders ORDER BY id DESC")
    orders_rows = cursor.fetchall()

    orders_list = []
    items_list = []

    for o_row in orders_rows:
        o = dict(o_row) if not isinstance(o_row, dict) else o_row
        order_id = o['id']
        cursor.execute("SELECT * FROM order_items WHERE order_id = ?", (order_id,))
        order_items_raw = cursor.fetchall()
        order_items = [dict(it) if not isinstance(it, dict) else it for it in order_items_raw]

        created_val = o.get('created_at')
        if isinstance(created_val, datetime):
            date_str = created_val.strftime('%Y-%m-%d %H:%M:%S')
        else:
            date_str = str(created_val)[:19] if created_val else datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # Build concatenated products summary
        products_summary_parts = []
        total_items_count = 0
        for item in order_items:
            p_name = item.get('product_name') or 'Kitchenware Item'
            v_name = item.get('variant_name') or 'Standard'
            qty = item.get('quantity') or 1
            price = item.get('unit_price') or 0.0
            subtot = item.get('subtotal') or (price * qty)
            total_items_count += qty

            variant_desc = f" ({v_name})" if v_name and v_name.lower() != 'standard' else ""
            products_summary_parts.append(f"{p_name}{variant_desc} [Qty: {qty} @ ₹{price:,.0f} = ₹{subtot:,.0f}]")

            items_list.append({
                'date_str': date_str,
                'order_number': o.get('order_number', ''),
                'customer_name': o.get('customer_name', ''),
                'phone': o.get('phone', ''),
                'product_id': item.get('product_id', ''),
                'product_name': p_name,
                'variant_name': v_name,
                'unit_price': price,
                'quantity': qty,
                'subtotal': subtot,
                'image_url': item.get('image_url', '')
            })

        products_summary = " | ".join(products_summary_parts) if products_summary_parts else "N/A"

        clean_p = normalize_phone(o.get('phone', ''))
        formatted_phone = f"+91 {clean_p}" if clean_p else o.get('phone', '')

        orders_list.append({
            'date_str': date_str,
            'order_number': o.get('order_number', ''),
            'customer_name': o.get('customer_name', ''),
            'phone': formatted_phone,
            'email': o.get('email', ''),
            'address': o.get('address', ''),
            'city': o.get('city', ''),
            'state': o.get('state', ''),
            'pincode': o.get('pincode', ''),
            'gstin': o.get('gstin', '') or 'N/A',
            'business_name': o.get('business_name', '') or 'N/A',
            'notes': o.get('notes', '') or o.get('expected_delivery', '') or '',
            'products_summary': products_summary,
            'total_items_count': total_items_count,
            'subtotal': float(o.get('subtotal') or 0.0),
            'discount': float(o.get('discount') or 0.0),
            'tax_amount': float(o.get('tax_amount') or 0.0),
            'shipping_fee': float(o.get('shipping_fee') or 0.0),
            'total_amount': float(o.get('total_amount') or 0.0),
            'payment_method': o.get('payment_method', ''),
            'payment_status': o.get('payment_status', ''),
            'courier_partner': o.get('tracking_partner', 'BlueDart Express Air'),
            'tracking_awb': o.get('tracking_awb', ''),
            'fulfillment_hub': 'Kota Central Artisan & Wholesale Hub (Rajasthan 324001)'
        })

    conn.close()
    return orders_list, items_list

def sync_full_orders_sheets():
    """
    Regenerates:
    1. kalash_orders_master_sheet.csv
    2. kalash_order_items_sheet.csv
    3. kalash_orders_master_sheet.xlsx (with 2 tabs: All Orders Master + Itemized Products)
    """
    ensure_data_directory()
    orders_list, items_list = get_all_orders_for_sheets()

    # 1. Master CSV
    with open(ORDERS_CSV_PATH, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(ORDERS_MASTER_HEADERS)
        for o in orders_list:
            writer.writerow([
                o['date_str'],
                o['order_number'],
                o['customer_name'],
                o['phone'],
                o['email'],
                o['address'],
                o['city'],
                o['state'],
                o['pincode'],
                o['gstin'],
                o['business_name'],
                o['notes'],
                o['products_summary'],
                o['total_items_count'],
                f"{o['subtotal']:.2f}",
                f"{o['discount']:.2f}",
                f"{o['tax_amount']:.2f}",
                f"{o['shipping_fee']:.2f}",
                f"{o['total_amount']:.2f}",
                o['payment_method'],
                o['payment_status'],
                o['courier_partner'],
                o['tracking_awb'],
                o['fulfillment_hub']
            ])

    # 2. Items CSV
    with open(ITEMS_CSV_PATH, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(ORDER_ITEMS_HEADERS)
        for it in items_list:
            writer.writerow([
                it['date_str'],
                it['order_number'],
                it['customer_name'],
                it['phone'],
                it['product_id'],
                it['product_name'],
                it['variant_name'],
                f"{it['unit_price']:.2f}",
                it['quantity'],
                f"{it['subtotal']:.2f}",
                it['image_url']
            ])

    # 3. Microsoft Excel Workbook via openpyxl
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter

        wb = openpyxl.Workbook()

        # Styles
        header_fill = PatternFill(start_color="107C41", end_color="107C41", fill_type="solid")
        header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
        sub_header_fill = PatternFill(start_color="0D5C30", end_color="0D5C30", fill_type="solid")
        thin_border = Border(
            left=Side(style='thin', color='E0E0E0'),
            right=Side(style='thin', color='E0E0E0'),
            top=Side(style='thin', color='E0E0E0'),
            bottom=Side(style='thin', color='E0E0E0')
        )
        currency_font = Font(name="Segoe UI", size=10, bold=True, color="107C41")

        # ---- Tab 1: Orders Master Ledger ----
        ws1 = wb.active
        ws1.title = "Orders Master Ledger"
        ws1.views.sheetView[0].showGridLines = True

        ws1.append(ORDERS_MASTER_HEADERS)
        for col_num in range(1, len(ORDERS_MASTER_HEADERS) + 1):
            cell = ws1.cell(row=1, column=col_num)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        for r_idx, o in enumerate(orders_list, start=2):
            row_data = [
                o['date_str'],
                o['order_number'],
                o['customer_name'],
                o['phone'],
                o['email'],
                o['address'],
                o['city'],
                o['state'],
                o['pincode'],
                o['gstin'],
                o['business_name'],
                o['notes'],
                o['products_summary'],
                o['total_items_count'],
                o['subtotal'],
                o['discount'],
                o['tax_amount'],
                o['shipping_fee'],
                o['total_amount'],
                o['payment_method'],
                o['payment_status'],
                o['courier_partner'],
                o['tracking_awb'],
                o['fulfillment_hub']
            ]
            ws1.append(row_data)
            row_fill = PatternFill(start_color="F9FAF8" if r_idx % 2 == 0 else "FFFFFF", fill_type="solid")
            for col_idx in range(1, len(row_data) + 1):
                cell = ws1.cell(row=r_idx, column=col_idx)
                cell.font = Font(name="Segoe UI", size=10)
                cell.border = thin_border
                cell.fill = row_fill
                # Format dates, numbers, alignment
                if col_idx in (1, 2, 4, 9, 14, 21, 22, 23):
                    cell.alignment = Alignment(horizontal="center")
                elif col_idx in (15, 16, 17, 18, 19):
                    cell.alignment = Alignment(horizontal="right")
                    cell.number_format = '₹#,##0.00'
                    if col_idx == 19:
                        cell.font = currency_font

        for col in ws1.columns:
            max_len = max(len(str(cell.value or '')) for cell in col)
            col_letter = get_column_letter(col[0].column)
            ws1.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 45)

        # ---- Tab 2: Itemized Products Breakdown ----
        ws2 = wb.create_sheet(title="Itemized Products")
        ws2.views.sheetView[0].showGridLines = True

        ws2.append(ORDER_ITEMS_HEADERS)
        for col_num in range(1, len(ORDER_ITEMS_HEADERS) + 1):
            cell = ws2.cell(row=1, column=col_num)
            cell.fill = sub_header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

        for r_idx, it in enumerate(items_list, start=2):
            row_data = [
                it['date_str'],
                it['order_number'],
                it['customer_name'],
                it['phone'],
                it['product_id'],
                it['product_name'],
                it['variant_name'],
                it['unit_price'],
                it['quantity'],
                it['subtotal'],
                it['image_url']
            ]
            ws2.append(row_data)
            row_fill = PatternFill(start_color="F9FAF8" if r_idx % 2 == 0 else "FFFFFF", fill_type="solid")
            for col_idx in range(1, len(row_data) + 1):
                cell = ws2.cell(row=r_idx, column=col_idx)
                cell.font = Font(name="Segoe UI", size=10)
                cell.border = thin_border
                cell.fill = row_fill
                if col_idx in (1, 2, 4, 5, 9):
                    cell.alignment = Alignment(horizontal="center")
                elif col_idx in (8, 10):
                    cell.alignment = Alignment(horizontal="right")
                    cell.number_format = '₹#,##0.00'

        for col in ws2.columns:
            max_len = max(len(str(cell.value or '')) for cell in col)
            col_letter = get_column_letter(col[0].column)
            ws2.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 40)

        wb.save(ORDERS_XLSX_PATH)
    except Exception as ex:
        print(f"[ORDERS EXCEL GENERATION WARNING] {ex}")

def record_order_to_sheets(order_number: str, form_dict: dict, cart_items: list, summary: dict,
                           payment_method: str, tracking_awb: str, base_url: str = ""):
    """
    Called every time an order is placed.
    Ensures that every detail filled by the customer along with the products ordered
    is stored and synchronized in Google Sheet / Excel files.
    """
    ensure_data_directory()
    sync_full_orders_sheets()

    # Optional Google Sheet Webhook Sync
    if GOOGLE_SHEET_ORDER_WEBHOOK_URL:
        try:
            import requests
            now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            payload = {
                'timestamp': now_str,
                'order_number': order_number,
                'customer_name': form_dict.get('customer_name', ''),
                'phone': form_dict.get('phone', ''),
                'email': form_dict.get('email', ''),
                'address': form_dict.get('address', ''),
                'city': form_dict.get('city', ''),
                'state': form_dict.get('state', ''),
                'pincode': form_dict.get('pincode', ''),
                'gstin': form_dict.get('gstin', ''),
                'business_name': form_dict.get('business_name', ''),
                'notes': form_dict.get('notes', ''),
                'payment_method': payment_method,
                'total_amount': summary.get('total', 0.0),
                'tracking_awb': tracking_awb,
                'items': [
                    {
                        'name': item.get('name'),
                        'variant': item.get('variant_name', 'Standard'),
                        'qty': item.get('quantity', 1),
                        'unit_price': item.get('unit_price', 0.0),
                        'subtotal': item.get('subtotal', 0.0)
                    }
                    for item in cart_items
                ]
            }
            requests.post(GOOGLE_SHEET_ORDER_WEBHOOK_URL, json=payload, timeout=3)
        except Exception as ex:
            print(f"[GOOGLE SHEETS ORDER WEBHOOK WARNING] {ex}")

def generate_orders_csv_export() -> str:
    """Returns the full Orders Master CSV content for Company Portal download."""
    sync_full_orders_sheets()
    if os.path.exists(ORDERS_CSV_PATH):
        with open(ORDERS_CSV_PATH, 'r', encoding='utf-8') as f:
            return f.read()
    return ""

def generate_order_items_csv_export() -> str:
    """Returns the itemized products CSV content for Company Portal download."""
    sync_full_orders_sheets()
    if os.path.exists(ITEMS_CSV_PATH):
        with open(ITEMS_CSV_PATH, 'r', encoding='utf-8') as f:
            return f.read()
    return ""

def generate_orders_excel_export_bytes() -> bytes:
    """Returns the full multi-tab XLSX binary content for Company Portal download."""
    sync_full_orders_sheets()
    if os.path.exists(ORDERS_XLSX_PATH):
        with open(ORDERS_XLSX_PATH, 'rb') as f:
            return f.read()
    return generate_orders_csv_export().encode('utf-8')
