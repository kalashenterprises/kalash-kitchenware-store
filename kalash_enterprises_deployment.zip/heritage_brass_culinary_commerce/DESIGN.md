---
name: Heritage Brass & Culinary Commerce
colors:
  surface: '#f8f9ff'
  surface-dim: '#d6dae4'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f4fd'
  surface-container: '#eaeef8'
  surface-container-high: '#e4e8f2'
  surface-container-highest: '#dee2ec'
  on-surface: '#171c23'
  on-surface-variant: '#514537'
  inverse-surface: '#2c3138'
  inverse-on-surface: '#edf1fb'
  outline: '#837566'
  outline-variant: '#d5c4b2'
  surface-tint: '#845400'
  primary: '#7b4e00'
  on-primary: '#ffffff'
  primary-container: '#996515'
  on-primary-container: '#fff3e8'
  inverse-primary: '#fcba64'
  secondary: '#ab3600'
  on-secondary: '#ffffff'
  secondary-container: '#ff6e38'
  on-secondary-container: '#611b00'
  tertiary: '#4b596d'
  on-tertiary: '#ffffff'
  tertiary-container: '#637186'
  on-tertiary-container: '#f1f5ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffddb6'
  primary-fixed-dim: '#fcba64'
  on-primary-fixed: '#2a1800'
  on-primary-fixed-variant: '#643f00'
  secondary-fixed: '#ffdbcf'
  secondary-fixed-dim: '#ffb59c'
  on-secondary-fixed: '#390c00'
  on-secondary-fixed-variant: '#822700'
  tertiary-fixed: '#d5e3fc'
  tertiary-fixed-dim: '#b9c7df'
  on-tertiary-fixed: '#0d1c2e'
  on-tertiary-fixed-variant: '#3a485b'
  background: '#f8f9ff'
  on-background: '#171c23'
  surface-variant: '#dee2ec'
typography:
  display:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.01em
  display-mobile:
    fontFamily: Playfair Display
    fontSize: 34px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  headline-md-mobile:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies a refined Indian culinary commerce aesthetic—blending the timeless prestige of traditional metalcraft with modern, friction-free transactional clarity. The tone bridges institutional wholesale reliability and premium direct-to-consumer domestic appeal. 

Visual style aligns with **Modern Merchant Editorial**:
- Generous, luminous ivory canvases that avoid the sterile coldness of pure white (#FFFFFF).
- Grounded, architectural layout balance evoking authentic brass, bronze, copper, and tri-ply stainless steel kitchenware.
- Rich metallic ochre and deep slate anchors with energetic terracotta accents reserved specifically for primary conversions, inventory alerts, and key interactions.
- Micro-details prioritize structural integrity: hairline dividers, whisper-light warm shadows, and dual-serif/grotesque typographic discipline.

## Colors

The palette balances traditional metalcraft warmth with utilitarian e-commerce clarity.

### Color Architecture
- **Primary Metalcraft (`#996515` / `#C59B27`)**: Antique brass and warm gold evoke pure metal quality, craftsmanship seals, badges, and high-tier product accents.
- **Secondary Saffron & Terracotta (`#D9531E` / `#C2410C`)**: High-contrast, warm interactive driver for key conversion paths, primary CTAs, sale tags, and dynamic order tracking.
- **Cool Metal Slate (`#475569` / `#64748B` / `#E2E8F0`)**: Stainless steel and aluminum representations used for secondary specifications, technical dimensions, tabs, and neutral borders.
- **Deep Slate Neutral (`#1E232A` / `#2C343F`)**: High-legibility base for typography and dense data tables, softening harsh black while maintaining AAA contrast.
- **Canvas & Surface Warmth (`#FAFAF7` / `#F5F3EF`)**: Unbleached ivory foundations provide depth, comfort, and an inviting domestic atmosphere.

## Typography

The type system implements a deliberate duality: **Playfair Display** introduces cultural authenticity, heritage stature, and merchant dignity across hero banners, collection titles, and editorial narratives. **Plus Jakarta Sans** manages high-density transactional interfaces, such as tier pricing, spec matrices, wholesale order minimums, and navigation.

- Product titles use `title-lg` or `headline-sm` to maintain balance inside commerce grids.
- Price tags, SKU identifiers, and cart calculations always utilize tabular figures (`font-variant-numeric: tabular-nums`) within `Plus Jakarta Sans`.
- Editorial uppercase kickers and trust seals (e.g., "PURE BRASS CERTIFIED") leverage `label-sm` with widened letter-spacing.

## Layout & Spacing

A structured 12-column grid system governs desktop interfaces, collapsing gracefully to an 8-column layout for tablets and a 4-column layout for mobile.

- **Desktop (min 1280px)**: 12 columns, max-width 1360px container, centered on warm ivory background (`#FAFAF7`). Gutters set at `1.5rem`.
- **Tablet (768px – 1279px)**: 8 columns with dynamic lateral margins scaling between `1.5rem` and `2rem`.
- **Mobile (< 767px)**: 4 columns with edge gutters fixed at `1rem` and compact vertical spacing rhythm to prioritize immediate product visibility and sticky conversion bars.
- Vertical layout spacing follows strict multiples of `0.5rem` (8px base cadence). Component internals utilize `space-sm` (8px) and `space-md` (16px), while catalog grid gaps rely on `space-lg` (24px).

## Elevation & Depth

Visual hierarchy is maintained through warm surface layering and diffused ambient shadows rather than stark digital drop-shadows.

- **Level 0 (Flat Ground)**: Baseline canvas in Warm Ivory (`#FAFAF7`).
- **Level 1 (Cards, Product Tiles, Inputs)**: Pure Surface (`#FFFFFF`) framed by a subtle stainless-steel stroke (`1px solid #E2E8F0`). Shadow: `0 1px 3px rgba(30, 35, 42, 0.04), 0 4px 12px rgba(153, 101, 21, 0.03)`.
- **Level 2 (Hover States, Quick-View Panels)**: Elevated surface with softened depth: `0 6px 16px -2px rgba(30, 35, 42, 0.06), 0 2px 6px -1px rgba(153, 101, 21, 0.05)`.
- **Level 3 (Sticky Cart, Popovers, Drawers)**: High float using warm-tinted diffusion: `0 12px 32px -4px rgba(30, 35, 42, 0.12), 0 4px 12px rgba(153, 101, 21, 0.06)`.
- Border accents favor low-opacity metallic borders (`rgba(153, 101, 21, 0.15)`) for premium featured tiers over aggressive shadow stacks.

## Shapes

The interface balances soft curved corners with structured geometric containment:

- **Inputs, Buttons, and Badges**: Standard `rounded` (0.5rem / 8px) gives an ergonomic, touch-friendly presence without appearing overly casual.
- **Product & Feature Cards**: `rounded-lg` (1rem / 16px) softens product imagery while keeping grid boundaries neat.
- **Modals, Drawers & Highlights**: `rounded-xl` (1.5rem / 24px) creates an editorial, presentation-grade silhouette.
- **Utility Indicators & Certifications**: Pill shapes (9999px) are strictly reserved for status indicators, tier badges (e.g., "Food Grade 304"), and quantity step controls.

## Components

### Buttons
- **Primary CTA**: Terracotta background (`#D9531E`), white text (`#FFFFFF`), `rounded` (8px), semi-bold type (`label-lg`). Hover shifts to `#C2410C` with a soft glow.
- **Secondary CTA (Inquire / Wholesale)**: Crisp white surface, antique brass outline (`1.5px solid #996515`), deep slate text (`#1E232A`). Hover triggers light brass wash (`#F5F3EF`).
- **Tertiary / Utility**: Ghost button with slate text (`#475569`) and subtle underline on hover.

### Product Cards
- Built on `#FFFFFF` surfaces with subtle border (`1px solid #E2E8F0`) and `rounded-lg` shape.
- Image area maintains a warm neutral tone (`#F5F3EF`) with a gentle 4:5 vertical aspect ratio.
- Features dual-tier pricing (Retail Price vs. Bulk/Wholesale Tier), brass certification tags, and quick-add sliding actions.

### Chips & Badges
- **Material Badge**: Metallic brass tint (`#F5F3EF` background, `#996515` text, hairline border).
- **Stock Alert**: Light terracotta wash (`#FEF2F2` background, `#C2410C` text).
- **Selection Chips**: Rounded (8px) with neutral slate stroke (`#E2E8F0`). Selected state applies `#996515` border with subtle brass fill tint.

### Form Inputs
- Background `#FFFFFF`, border `#E2E8F0`, corner radius `rounded` (8px).
- Focus state switches border to `#996515` with an ivory-brass focus ring (`0 0 0 3px rgba(197, 155, 39, 0.2)`).
- Floating labels employ `label-sm` in slate gray (`#64748B`).

### Checkboxes & Radios
- Crisp 18px boxes with soft `0.25rem` corners for checkboxes; circular for radios.
- Checked state uses `#996515` fill with clean white interior glyphs.

### Quantity Selector & Wholesale Tier Matrix
- Compact unified stepper with `#F5F3EF` fill, slate iconography, and tabular numeric display.
- Integrated minimum order quantity (MOQ) indicator displayed beneath in `body-sm`.